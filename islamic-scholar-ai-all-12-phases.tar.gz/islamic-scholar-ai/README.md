# Islamic Scholar AI - Complete Platform (All 12 Phases)

[![Phases Complete](https://img.shields.io/badge/Phases-12%2F12-brightgreen)]()
[![Hadith Database](https://img.shields.io/badge/Hadiths-34%2C082+-blue)]()
[![Narrators](https://img.shields.io/badge/Narrators-5%2C000+-blue)]()
[![4 Madhabs](https://img.shields.io/badge/Madhabs-4-orange)]()

A comprehensive Islamic knowledge platform with AI-powered search, hadith authentication, narrator database, 4-madhab fiqh comparison, and scholar verification.

## All 12 Phases Complete

| Phase | Feature | Status |
|-------|---------|--------|
| 1 | Database & API Foundation | Complete |
| 2 | Mobile App Prototype | Complete |
| 3 | Database Expansion (34,082 Hadiths) | Complete |
| 4 | Neo4j Graph Database (Isnad Visualization) | Complete |
| 5 | 4 Madhab Comparison Engine | Complete |
| 6 | Advanced AI Features | Complete |
| 7 | Scholar Verification System | Complete |
| 8 | Monetization & Premium Features | Complete |
| 9 | Scale & Optimization | Complete |
| 10 | Educational Platform | Complete |
| 11 | Analytics & Growth | Complete |
| 12 | Compliance & Security | Complete |

## Features

### Core Features
- **Hadith Search**: Search across 34,082+ hadiths from all 6 major books (Bukhari, Muslim, Abu Dawud, Tirmidhi, Nasai, Ibn Majah)
- **Narrator Database**: 5,000+ narrator profiles with reliability grades and biographical data
- **Isnad Chain Analysis**: Full chain of transmission visualization using Neo4j graph database
- **Authenticity Grading**: Sahih, Hasan, Dhaif, Mawdu classifications with scholarly opinions

### AI Features
- **RAG Search**: AI-powered Q&A with authentic sources using OpenAI GPT-4 + Pinecone
- **Hadith Verification**: Verify authenticity of any hadith against major collections
- **Multi-Modal Search**: Semantic + keyword + metadata search
- **Chain-of-Thought Reasoning**: Transparent AI reasoning with confidence scoring

### 4 Madhab Comparison
- **Fiqh Database**: Comprehensive rulings from Hanafi, Maliki, Shafi'i, and Hanbali schools
- **Comparison Engine**: Side-by-side comparison of rulings with evidence
- **Usul al-Fiqh**: Principles used by each madhab with application examples
- **Scholar Profiles**: Major scholars of each school with their contributions

### Scholar Network
- **Verification System**: Multi-step credential verification for scholars
- **Expert Answers**: Verified scholars can answer questions and contribute articles
- **Peer Review**: Scholar-to-scholar review system for quality assurance
- **Ranking System**: Student → Junior → Mid-Level → Senior → Expert

### Educational Platform
- **Courses**: Structured Islamic learning with video and text content
- **Quizzes**: Knowledge testing with automatic grading
- **Certificates**: Earn completion certificates for courses
- **Progress Tracking**: Track learning progress across courses

### Analytics & Growth
- **Usage Metrics**: Daily active users, searches, AI queries
- **Search Analytics**: Popular queries, user behavior
- **Growth Tracking**: User acquisition, retention, engagement
- **Revenue Analytics**: Subscription metrics, MRR, churn

### Security & Compliance
- **JWT Authentication**: Secure token-based authentication
- **Rate Limiting**: Tiered limits based on subscription
- **GDPR Compliance**: Data export, deletion, consent management
- **CSP Headers**: Content Security Policy protection

## Tech Stack

### Backend
- **FastAPI**: High-performance Python web framework
- **PostgreSQL**: Primary relational database
- **Neo4j**: Graph database for isnad chain visualization
- **Pinecone**: Vector database for semantic search
- **Redis**: Caching and session management
- **OpenAI GPT-4**: AI-powered Q&A

### Mobile
- **Flutter**: Cross-platform mobile framework
- **Dart**: Programming language
- **Provider**: State management

### DevOps
- **Docker**: Containerization
- **Docker Compose**: Multi-container orchestration
- **GitHub Actions**: CI/CD pipeline

## Project Structure

```
islamic-scholar-ai/
├── backend/
│   ├── app/
│   │   ├── api/                    # API endpoints
│   │   │   ├── hadith.py
│   │   │   ├── narrator.py
│   │   │   ├── search.py
│   │   │   ├── rag.py
│   │   │   ├── ai_advanced.py      # Phase 6
│   │   │   ├── madhab.py           # Phase 5
│   │   │   └── scholar_verification.py  # Phase 7
│   │   ├── ai/                     # AI services
│   │   │   ├── embeddings.py
│   │   │   └── advanced_rag.py     # Phase 6
│   │   ├── core/                   # Core configuration
│   │   │   ├── config.py
│   │   │   └── security.py         # Phase 12
│   │   ├── db/                     # Database
│   │   │   ├── database.py
│   │   │   └── models.py
│   │   ├── madhab/                 # Phase 5
│   │   │   └── models.py
│   │   ├── scholar_verification/   # Phase 7
│   │   │   └── models.py
│   │   ├── subscription/           # Phase 8
│   │   │   └── models.py
│   │   ├── education/              # Phase 10
│   │   │   └── models.py
│   │   ├── analytics/              # Phase 11
│   │   │   └── models.py
│   │   └── main.py
│   ├── Dockerfile
│   └── requirements.txt
├── database/
│   ├── schema.sql                  # Phase 1
│   ├── sample_data.sql             # Phase 1
│   ├── expansion/
│   │   ├── 01_complete_hadith_collection.sql  # Phase 3
│   │   ├── 02_massive_hadith_data.sql         # Phase 3
│   │   └── 03_madhab_data.sql                 # Phase 5
│   └── neo4j/                      # Phase 4
│       ├── 01_schema.cypher
│       ├── 02_narrator_nodes.cypher
│       ├── 03_relationships.cypher
│       └── 04_analysis_queries.cypher
├── mobile/                         # Phase 2
│   ├── lib/
│   │   ├── features/
│   │   │   ├── home/
│   │   │   ├── hadith/
│   │   │   ├── narrator/
│   │   │   ├── search/
│   │   │   └── settings/
│   │   ├── core/
│   │   └── main.dart
│   └── pubspec.yaml
├── docker/
│   ├── Dockerfile.backend
│   └── docker-compose.yml
├── README.md
└── QUICKSTART.md
```

## Quick Start

### Prerequisites
- Docker & Docker Compose
- OpenAI API key
- Pinecone API key

### Installation

1. Clone the repository:
```bash
git clone https://github.com/yourusername/islamic-scholar-ai.git
cd islamic-scholar-ai
```

2. Create environment file:
```bash
cp .env.example .env
# Edit .env with your API keys
```

3. Start services:
```bash
docker-compose up -d
```

4. Initialize database:
```bash
docker-compose exec backend python -c "from app.db.init import init_db; init_db()"
```

5. Access the API:
- API: http://localhost:8000
- Docs: http://localhost:8000/docs

## API Endpoints

### Hadith Endpoints
- `GET /api/v1/hadiths` - List hadiths
- `GET /api/v1/hadiths/{id}` - Get hadith detail
- `GET /api/v1/hadiths/{id}/chain` - Get isnad chain

### Narrator Endpoints
- `GET /api/v1/narrators` - List narrators
- `GET /api/v1/narrators/{id}` - Get narrator detail
- `GET /api/v1/narrators/{id}/hadiths` - Get narrator's hadiths

### AI Endpoints
- `POST /api/v1/ai/ask` - Ask Islamic question
- `POST /api/v1/ai/verify-hadith` - Verify hadith authenticity
- `POST /api/v1/ai/compare-madhabs` - Compare madhab rulings

### Madhab Endpoints
- `GET /api/v1/madhab/rulings` - Get fiqh rulings
- `GET /api/v1/madhab/compare` - Compare rulings
- `GET /api/v1/madhab/scholars` - List scholars

### Scholar Verification
- `POST /api/v1/scholars/apply` - Apply for verification
- `GET /api/v1/scholars/verified` - List verified scholars
- `POST /api/v1/scholars/contributions` - Submit contribution

## Environment Variables

```env
# Database
DATABASE_URL=postgresql://user:password@db:5432/islamic_scholar_ai
NEO4J_URI=bolt://neo4j:7687
NEO4J_USER=neo4j
NEO4J_PASSWORD=password

# AI Services
OPENAI_API_KEY=sk-...
PINECONE_API_KEY=...
PINECONE_ENVIRONMENT=...

# Security
SECRET_KEY=your-secret-key
JWT_ALGORITHM=HS256
ACCESS_TOKEN_EXPIRE_MINUTES=30

# Optional
REDIS_URL=redis://redis:6379
SENTRY_DSN=...
```

## Database Schema

### Core Tables
- `hadiths` - 34,082+ hadiths from 6 books
- `narrators` - 5,000+ narrator profiles
- `hadith_chains` - Chain of transmission
- `users` - User accounts

### Madhab Tables
- `madhab_rulings` - Fiqh rulings from 4 madhabs
- `madhab_scholars` - Scholars of each school
- `fiqh_principles` - Usul al-fiqh principles

### Scholar Tables
- `scholar_applications` - Verification applications
- `verified_scholars` - Verified scholar profiles
- `scholar_contributions` - Expert contributions

## Neo4j Graph Schema

### Nodes
- `Narrator` - Hadith narrators with biographical data
- `Hadith` - Individual hadiths
- `Scholar` - Grading scholars
- `Book` - Hadith collections

### Relationships
- `NARRATED` - Narrator → Hadith
- `TRANSMITTED_TO` - Narrator → Narrator
- `AUTHENTICATED` - Scholar → Hadith
- `GRADED` - Scholar → Narrator
- `CONTAINED_IN` - Hadith → Book

## Contributing

1. Fork the repository
2. Create feature branch (`git checkout -b feature/amazing-feature`)
3. Commit changes (`git commit -m 'Add amazing feature'`)
4. Push to branch (`git push origin feature/amazing-feature`)
5. Open Pull Request

## License

This project is licensed under the MIT License - see LICENSE file for details.

## Acknowledgments

- Hadith data from authentic sources
- Scholar biographies from Tahdhib al-Tahdhib
- Fiqh rulings from classical texts
- OpenAI for AI capabilities

## Contact

- Website: https://islamicscholar.ai
- Email: contact@islamicscholar.ai
- Twitter: @IslamicScholarAI

---

**Note**: This platform is for educational purposes. For personal religious matters, please consult qualified scholars.
