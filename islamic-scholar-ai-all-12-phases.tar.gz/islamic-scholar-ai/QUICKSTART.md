# Islamic Scholar AI - Quick Start Guide

## 🚀 Get Started in 5 Minutes

### Step 1: Setup Environment

```bash
cd islamic-scholar-ai

# Copy environment template
cp backend/.env.example backend/.env

# Edit with your API keys
nano backend/.env
```

Add your API keys to `backend/.env`:
```
OPENAI_API_KEY=sk-your-key-here
PINECONE_API_KEY=your-key-here  # Optional
```

### Step 2: Start Services

```bash
./start.sh
```

Or manually:
```bash
cd docker
docker-compose up -d
```

### Step 3: Verify Installation

```bash
# Check API is running
curl http://localhost:8000/health

# View API documentation
open http://localhost:8000/docs
```

### Step 4: Test API Endpoints

```bash
# Search hadiths
curl "http://localhost:8000/api/hadiths/search?q=intention"

# Get hadith details
curl "http://localhost:8000/api/hadiths/1"

# Search narrators
curl "http://localhost:8000/api/narrators/search?q=Abu%20Hurairah"

# AI Query
curl -X POST "http://localhost:8000/api/rag/query" \
  -H "Content-Type: application/json" \
  -d '{"query": "What did the Prophet say about intentions?"}'
```

### Step 5: Run Mobile App (Optional)

```bash
cd mobile

# Install dependencies
flutter pub get

# Generate code
flutter pub run build_runner build --delete-conflicting-outputs

# Run on device/emulator
flutter run
```

---

## 📁 Project Structure

```
islamic-scholar-ai/
├── backend/           # FastAPI Python backend
│   ├── app/
│   │   ├── api/      # REST API endpoints
│   │   ├── core/     # Configuration
│   │   ├── db/       # Database models
│   │   └── schemas/  # Pydantic schemas
│   └── requirements.txt
├── database/          # SQL files
│   ├── schema.sql     # Database schema
│   └── sample_data.sql # Sample data
├── mobile/            # Flutter app
│   └── lib/
│       ├── features/  # Feature modules
│       └── core/      # Theme, API, Router
├── docker/            # Docker configuration
│   ├── Dockerfile.backend
│   └── docker-compose.yml
└── README.md
```

---

## 🔌 API Endpoints

| Endpoint | Description |
|----------|-------------|
| `GET /api/hadiths/` | List hadiths with filters |
| `GET /api/hadiths/search?q={query}` | Search hadiths |
| `GET /api/hadiths/{id}` | Get hadith by ID |
| `GET /api/hadiths/{id}/authentication` | Get authentication |
| `GET /api/narrators/` | List narrators |
| `GET /api/narrators/search?q={query}` | Search narrators |
| `GET /api/narrators/{id}` | Get narrator details |
| `POST /api/rag/query` | AI-powered search |

---

## 🗄️ Database

### Tables Created
- `hadiths` - 50 sample hadiths
- `narrators` - 20 top narrators
- `hadith_chains` - Isnad chains
- `users` - User accounts

### Access Database
```bash
# Connect to PostgreSQL
docker exec -it islamic-scholar-db psql -U postgres -d islamic_scholar

# List tables
\dt

# View hadiths
SELECT * FROM hadiths LIMIT 5;

# View narrators
SELECT name_english, consensus_grade FROM narrators;
```

---

## 🛠️ Development

### Backend Development
```bash
cd backend

# Create virtual environment
python -m venv venv
source venv/bin/activate

# Install dependencies
pip install -r requirements.txt

# Run locally
uvicorn app.main:app --reload
```

### Mobile Development
```bash
cd mobile

# Get dependencies
flutter pub get

# Generate code
flutter pub run build_runner build

# Run
flutter run
```

---

## 🐛 Troubleshooting

### Port Already in Use
```bash
# Kill process on port 8000
lsof -ti:8000 | xargs kill -9
```

### Database Connection Failed
```bash
# Restart database
cd docker
docker-compose restart postgres
```

### Reset Everything
```bash
cd docker
docker-compose down -v
docker-compose up -d
```

---

## 📚 Next Steps

1. **Add More Data**: Import complete Sahih Bukhari & Muslim
2. **Setup Pinecone**: Enable semantic search
3. **Add Neo4j**: Visualize isnad chains
4. **Deploy**: Deploy to AWS/GCP

---

## 📞 Support

- API Docs: http://localhost:8000/docs
- Health: http://localhost:8000/health
- Email: contact@islamicscholar.ai
