-- ============================================================
-- ISLAMIC SCHOLAR AI - 4 MADHAB DATA
-- Sample Fiqh Rulings for Comparison Engine
-- Phase 5: 4 Madhab Comparison Engine
-- ============================================================

-- Insert Fiqh Topics
INSERT INTO fiqh_topics (name, name_arabic, description, parent_id) VALUES
('Purification (Taharah)', 'الطهارة', 'Rules related to cleanliness and purification', NULL),
('Prayer (Salah)', 'الصلاة', 'Rules related to the five daily prayers', NULL),
('Fasting (Sawm)', 'الصيام', 'Rules related to fasting in Ramadan', NULL),
('Zakat', 'الزكاة', 'Rules related to obligatory charity', NULL),
('Hajj', 'الحج', 'Rules related to pilgrimage', NULL),
('Marriage (Nikah)', 'النكاح', 'Rules related to marriage and family', NULL),
('Business Transactions', 'المعاملات المالية', 'Rules related to commerce and trade', NULL),
('Food and Drink', 'الأطعمة والأشربة', 'Rules related to permissible consumption', NULL),
('Clothing and Adornment', 'اللباس والزينة', 'Rules related to dress and appearance', NULL),
('Criminal Law', 'الحدود والجزاءات', 'Rules related to punishments', NULL);

-- Insert Subtopics for Prayer
INSERT INTO fiqh_topics (name, name_arabic, description, parent_id) VALUES
('Times of Prayer', 'أوقات الصلاة', 'When each prayer time begins and ends', 2),
('Ablution (Wudu)', 'الوضوء', 'How to perform ritual ablution', 2),
('Conditions of Prayer', 'شروط الصلاة', 'Prerequisites for valid prayer', 2),
('Pillars of Prayer', 'أركان الصلاة', 'Essential components of prayer', 2),
('Obligatory Acts of Prayer', 'واجبات الصلاة', 'Required elements of prayer', 2),
('Recommended Acts of Prayer', 'سنن الصلاة', 'Recommended elements of prayer', 2),
('Prostrations of Forgetfulness', 'سجود السهو', 'How to correct mistakes in prayer', 2),
('Invalidators of Prayer', 'مبطلات الصلاة', 'What breaks the prayer', 2);

-- Insert Madhab Biographies
INSERT INTO madhab_biographies (
    madhab, founder_name, founder_name_arabic, founder_death_year,
    origin_city, origin_city_arabic, history, key_characteristics, methodology, major_texts
) VALUES
(
    'hanafi',
    'Imam Abu Hanifa',
    'الإمام أبو حنيفة',
    150,
    'Kufa',
    'الكوفة',
    'The Hanafi school is the oldest and largest school of Islamic jurisprudence. Founded by Imam Abu Hanifa in Kufa, Iraq, it emphasizes the use of reason (ra\'y) and analogical reasoning (qiyas). The school spread widely through the Ottoman Empire and is now predominant in Turkey, the Balkans, Central Asia, the Indian subcontinent, and parts of the Arab world.',
    ARRAY['Emphasis on reason and analogy', 'Use of istihsan (juristic preference)', 'Consideration of public welfare', 'Flexibility in rulings', 'Extensive use of qiyas'],
    'The Hanafi methodology prioritizes the Quran, then the Sunnah, then consensus (ijma), then analogy (qiyas), and finally juristic preference (istihsan). It places significant emphasis on rational analysis and considers the objectives of Sharia (maqasid).',
    '[
        {"title": "Al-Mudawwana al-Kubra", "author": "Imam Malik (commentary by Hanafi scholars)", "description": "Major reference work"},
        {"title": "Al-Hidayah", "author": "Burhan al-Din al-Marghinani", "description": "Comprehensive fiqh manual"},
        {"title": "Fath al-Qadir", "author": "Ibn al-Humam", "description": "Commentary on Al-Hidayah"}
    ]'::jsonb
),
(
    'maliki',
    'Imam Malik ibn Anas',
    'الإمام مالك بن أنس',
    179,
    'Madinah',
    'المدينة المنورة',
    'The Maliki school was founded by Imam Malik ibn Anas in Madinah. It is based heavily on the practice of the people of Madinah (amal ahl al-Madinah) and emphasizes the living Sunnah. The school is predominant in North and West Africa, Egypt, Sudan, and parts of the Gulf.',
    ARRAY['Emphasis on practice of Madinah', 'Consideration of public interest (maslaha)', 'Caution in accepting hadiths', 'Use of sadd al-dharai (blocking means)', 'Respect for early generations'],
    'The Maliki methodology prioritizes the Quran, then the Sunnah as practiced in Madinah, then consensus of the people of Madinah, then analogy (qiyas), and finally public interest (maslaha mursala). It places great weight on the continuous practice of the Muslim community.',
    '[
        {"title": "Al-Mudawwana al-Kubra", "author": "Imam Malik", "description": "Primary text of the school"},
        {"title": "Al-Risala", "author": "Ibn Abi Zayd al-Qayrawani", "description": "Comprehensive manual"},
        {"title": "Mukhtasar Khalil", "author": "Khalil ibn Ishaq", "description": "Concise reference"}
    ]'::jsonb
),
(
    'shafii',
    'Imam Muhammad ibn Idris al-Shafi\'i',
    'الإمام محمد بن إدريس الشافعي',
    204,
    'Gaza',
    'غزة',
    'The Shafi\'i school was founded by Imam al-Shafi\'i, who was a student of Imam Malik. It represents a middle path between the heavy reliance on hadith of the Malikis and the emphasis on reason of the Hanafis. The school is predominant in Egypt, East Africa, Yemen, Syria, Jordan, Palestine, and Southeast Asia (Indonesia, Malaysia).',
    ARRAY['Balance between hadith and reason', 'Systematic methodology in usul', 'Emphasis on authentic hadith', 'Clear hierarchy of evidence', 'Comprehensive legal theory'],
    'The Shafi\'i methodology prioritizes the Quran, then the Mutawatir Sunnah, then the Ahad Sunnah, then consensus (ijma), then analogy (qiyas). Imam al-Shafi\'i established the principles of jurisprudence (usul al-fiqh) as a distinct science.',
    '[
        {"title": "Al-Risala", "author": "Imam al-Shafi\'i", "description": "Foundational work in usul al-fiqh"},
        {"title": "Mukhtasar al-Umm", "author": "Imam al-Muzani", "description": "Summary of al-Umm"},
        {"title": "Fath al-Bari", "author": "Ibn Hajar al-Asqalani", "description": "Commentary on Sahih al-Bukhari"}
    ]'::jsonb
),
(
    'hanbali',
    'Imam Ahmad ibn Hanbal',
    'الإمام أحمد بن حنبل',
    241,
    'Baghdad',
    'بغداد',
    'The Hanbali school was founded by Imam Ahmad ibn Hanbal in Baghdad. It is known for its strict adherence to the Sunnah and reliance on hadith. The school faced persecution during the Mihna (inquisition) but survived and is now predominant in Saudi Arabia and Qatar.',
    ARRAY['Strict adherence to Sunnah', 'Preference for hadith over analogy', 'Rejection of speculative reasoning', 'Emphasis on authentic narrations', 'Conservative approach'],
    'The Hanbali methodology prioritizes the Quran, then the Sunnah (with preference for sahih hadith), then consensus of the Sahaba, then analogy (qiyas) as a last resort. It is known for its textual approach and caution in departing from clear hadith.',
    '[
        {"title": "Musnad Ahmad", "author": "Imam Ahmad", "description": "Collection of hadiths"},
        {"title": "Mukhtasar al-Fiqh", "author": "Ibn Qudamah", "description": "Concise fiqh manual"},
        {"title": "Al-Mughni", "author": "Ibn Qudamah", "description": "Comprehensive reference"}
    ]'::jsonb
);

-- Insert Madhab Scholars
INSERT INTO madhab_scholars (
    name, name_arabic, kunya, nisba, birth_year, death_year, madhab,
    is_founder, is_major_student, generation, major_works, major_works_arabic, specializations, biography
) VALUES
-- Hanafi Scholars
('Imam Abu Hanifa', 'الإمام أبو حنيفة', 'Abu Hanifa', 'al-Nu\'man ibn Thabit al-Kufi', 80, 150, 'hanafi', true, false, 1, 
 ARRAY['Fiqh al-Akbar', 'Al-Alim wa al-Muta\'allim'], ARRAY['فقه الأكبر', 'العالم والمتعلم'],
 ARRAY['Fiqh', 'Usul', 'Kalam'], 
 'Founder of the Hanafi school. Known for his exceptional intelligence and mastery of fiqh.'),

('Imam Abu Yusuf', 'الإمام أبو يوسف', 'Abu Yusuf', 'Ya\'qub ibn Ibrahim al-Ansari', 113, 182, 'hanafi', false, true, 2,
 ARRAY['Kitab al-Kharaj', 'Kitab al-Athar'], ARRAY['كتاب الخراج', 'كتاب الآثار'],
 ARRAY['Fiqh', 'Judiciary'],
 'Chief judge under Harun al-Rashid. Most prominent student of Abu Hanifa.'),

('Imam Muhammad al-Shaybani', 'الإمام محمد الشيباني', 'Abu Abdullah', 'Muhammad ibn al-Hasan', 132, 189, 'hanafi', false, true, 2,
 ARRAY['Kitab al-Asl', 'Kitab al-Jami\' al-Saghir'], ARRAY['كتاب الأصل', 'كتاب الجامع الصغير'],
 ARRAY['Fiqh', 'Hadith'],
 'Student of Abu Hanifa and Malik. Known as the "Imam of the Earth".'),

-- Maliki Scholars
('Imam Malik ibn Anas', 'الإمام مالك بن أنس', 'Abu Abdullah', 'Malik ibn Anas al-Asbahi', 93, 179, 'maliki', true, false, 1,
 ARRAY['Al-Muwatta', 'Al-Mudawwana al-Kubra'], ARRAY['الموطأ', 'المدونة الكبرى'],
 ARRAY['Fiqh', 'Hadith'],
 'Founder of the Maliki school. Compiled the first written collection of hadith and fiqh.'),

('Ibn al-Qasim', 'ابن القاسم', 'Abu Abdullah', 'Abd al-Rahman ibn al-Qasim', 132, 191, 'maliki', false, true, 2,
 ARRAY['Mukhtasar Ibn al-Qasim'], ARRAY['مختصر ابن القاسم'],
 ARRAY['Fiqh'],
 'Most prominent student of Imam Malik. Transmitted the Mudawwana.'),

('Ibn Wahb', 'ابن وهب', 'Abu Muhammad', 'Abdullah ibn Wahb al-Misri', 125, 197, 'maliki', false, true, 2,
 ARRAY['Jami\' Ibn Wahb'], ARRAY['جامع ابن وهب'],
 ARRAY['Fiqh', 'Hadith'],
 'Major student of Imam Malik in Egypt. Transmitted many hadiths.'),

-- Shafi'i Scholars
('Imam al-Shafi\'i', 'الإمام الشافعي', 'Abu Abdullah', 'Muhammad ibn Idris al-Shafi\'i', 150, 204, 'shafii', true, false, 1,
 ARRAY['Al-Risala', 'Al-Umm'], ARRAY['الرسالة', 'الأم'],
 ARRAY['Fiqh', 'Usul al-Fiqh'],
 'Founder of the Shafi\'i school. Established usul al-fiqh as a distinct science.'),

('Imam al-Muzani', 'الإمام المزني', 'Abu Ibrahim', 'Ismail ibn Yahya al-Muzani', 175, 264, 'shafii', false, true, 2,
 ARRAY['Mukhtasar al-Umm'], ARRAY['مختصر الأم'],
 ARRAY['Fiqh'],
 'Prominent student of al-Shafi\'i. Known for his concise summaries.'),

('Imam al-Bayhaqi', 'الإمام البيهقي', 'Abu Bakr', 'Ahmad ibn al-Husayn al-Bayhaqi', 384, 458, 'shafii', false, false, 4,
 ARRAY['Sunan al-Bayhaqi', 'Shu\'ab al-Iman'], ARRAY['سنن البيهقي', 'شعب الإيمان'],
 ARRAY['Hadith', 'Fiqh'],
 'Renowned hadith scholar and jurist of the Shafi\'i school.'),

-- Hanbali Scholars
('Imam Ahmad ibn Hanbal', 'الإمام أحمد بن حنبل', 'Abu Abdullah', 'Ahmad ibn Muhammad ibn Hanbal', 164, 241, 'hanbali', true, false, 1,
 ARRAY['Musnad Ahmad', 'Fada\'il al-Sahaba'], ARRAY['مسند أحمد', 'فضائل الصحابة'],
 ARRAY['Hadith', 'Fiqh'],
 'Founder of the Hanbali school. Famous for his stance during the Mihna.'),

('Imam al-Khallal', 'الإمام الخلال', 'Abu Bakr', 'Ahmad ibn Muhammad al-Khallal', 311, 311, 'hanbali', false, true, 3,
 ARRAY['Al-Musnad', 'Al-Jami\''], ARRAY['المسند', 'الجامع'],
 ARRAY['Fiqh', 'Hadith'],
 'Collected the opinions of Imam Ahmad. Preserved the Hanbali school.'),

('Ibn Qudamah', 'ابن قدامة', 'Abu Muhammad', 'Muwaffaq al-Din ibn Qudamah', 541, 620, 'hanbali', false, false, 5,
 ARRAY['Al-Mughni', 'Al-Kafi'], ARRAY['المغني', 'الكافي'],
 ARRAY['Fiqh'],
 'One of the most comprehensive Hanbali scholars. Author of Al-Mughni.');

-- Insert Sample Fiqh Rulings - Wudu (Ablution)
INSERT INTO madhab_rulings (
    topic_id, madhab, question, question_arabic, ruling, ruling_arabic,
    ruling_category, explanation, explanation_arabic, conditions, exceptions,
    primary_source, issuing_imam, has_ijma, comparison_notes
) VALUES
-- Wudu Question 1: Touching private parts
(10, 'hanafi', 
 'Does touching one\'s own private parts break wudu?',
 'هل مس العورة يبطل الوضوء؟',
 'Touching one\'s own private parts does not break wudu, whether with or without desire.',
 'مس العورة لا يبطل الوضوء، سواء كان بشهوة أو بدونها',
 'mubah',
 'The Hanafi school holds that touching the private parts does not invalidate wudu because the hadith indicating otherwise is considered weak by Hanafi scholars. They argue that the default state is purity until proven otherwise.',
 'يرى الحنفية أن مس العورة لا يبطل الوضوء لأن الحديث الدال على البطلان ضعيف عندهم',
 ARRAY['The touching must be direct skin-to-skin contact', 'Applies to one\'s own private parts'],
 ARRAY['Touching someone else\'s private parts breaks wudu', 'Touching with desire may require ghusl'],
 'Al-Hidayah',
 'Imam Abu Hanifa',
 false,
 'The four madhabs differ on this issue. Hanafis say it does not break wudu, while Malikis, Shafi\'is, and Hanbalis generally hold that it does.'
),

(10, 'maliki',
 'Does touching one\'s own private parts break wudu?',
 'هل مس العورة يبطل الوضوء؟',
 'Touching the private parts breaks wudu, based on the hadith: "Whoever touches his private part, let him perform wudu."',
 'مس العورة يبطل الوضوء، استناداً إلى الحديث: "من مس ذكره فليتوضأ"',
 'haram',
 'The Maliki school follows the apparent meaning of the hadith. They consider touching the private parts to break wudu regardless of whether it is with or without desire.',
 'المالكية يأخذون بظاهر الحديث ويرون أن مس العورة يبطل الوضوء',
 ARRAY['Applies to touching one\'s own private parts', 'Applies to both male and female'],
 ARRAY['Touching through a barrier does not break wudu'],
 'Al-Mudawwana al-Kubra',
 'Imam Malik',
 false,
 'Malikis agree with Shafi\'is and Hanbalis on this issue, differing from Hanafis.'
),

(10, 'shafii',
 'Does touching one\'s own private parts break wudu?',
 'هل مس العورة يبطل الوضوء؟',
 'Touching the private parts breaks wudu according to the authentic hadith.',
 'مس العورة يبطل الوضوء وفق الحديث الصحيح',
 'haram',
 'The Shafi\'i school follows the authentic hadith on this matter. They consider the hadith to be clear evidence that wudu is broken by touching the private parts.',
 'الشافعية يتبعون الحديث الصحيح في هذه المسألة',
 ARRAY['Applies to any touching of the private parts', 'Applies to both males and females'],
 ARRAY['Touching without desire still breaks wudu'],
 'Al-Umm',
 'Imam al-Shafi\'i',
 false,
 'Shafi\'is align with Malikis and Hanbalis against Hanafis on this issue.'
),

(10, 'hanbali',
 'Does touching one\'s own private parts break wudu?',
 'هل مس العورة يبطل الوضوء؟',
 'Touching the private parts breaks wudu based on the explicit hadith.',
 'مس العورة يبطل الوضوء بناءً على الحديث الصريح',
 'haram',
 'The Hanbali school follows the apparent meaning of the hadith. They hold that touching the private parts invalidates wudu.',
 'الحنابلة يأخذون بظاهر الحديث',
 ARRAY['Applies to touching one\'s own private parts'],
 ARRAY['None'],
 'Musnad Ahmad',
 'Imam Ahmad ibn Hanbal',
 false,
 'Hanbalis agree with Malikis and Shafi\'is, while Hanafis hold a different view.'
);

-- Insert Ruling Comparisons
INSERT INTO ruling_comparisons (
    ruling_1_id, ruling_2_id, similarity_score, agreement_level,
    points_of_agreement, points_of_difference, difference_reasons
)
SELECT 
    h1.id, h2.id, 25, 'Different',
    ARRAY['All agree that purity is important', 'All base their opinion on hadith'],
    ARRAY['Hanafis say wudu is NOT broken', 'Malikis, Shafi\'is, and Hanbalis say wudu IS broken'],
    'The difference stems from the grading of the hadith. Hanafis consider the hadith weak, while others consider it authentic.'
FROM madhab_rulings h1, madhab_rulings h2
WHERE h1.topic_id = 10 AND h2.topic_id = 10
  AND h1.madhab = 'hanafi' AND h2.madhab = 'maliki'
LIMIT 1;

-- Insert Usul al-Fiqh Principles
INSERT INTO fiqh_principles (
    name, name_arabic, description, description_arabic, used_by_madhabs,
    hanafi_application, maliki_application, shafii_application, hanbali_application
) VALUES
(
    'Qiyas (Analogical Reasoning)',
    'القياس',
    'Deriving rulings for new cases based on similarity to established cases',
    'استنباط الأحكام للمسائل الجديدة بناءً على الشبه بالمسائل الثابتة',
    ARRAY['hanafi', 'maliki', 'shafii', 'hanbali'],
    'Used extensively. Hanafis give qiyas high priority after Quran, Sunnah, and ijma.',
    'Used but with caution. Malikis prefer other sources when available.',
    'Used as fourth source after Quran, Sunnah, and ijma.',
    'Used as last resort when no text is available.'
),
(
    'Istihsan (Juristic Preference)',
    'الاستحسان',
    'Preferring a ruling that goes against strict analogy for a stronger reason',
    'تفضيل حكم يخالف القياس لسبب أقوى',
    ARRAY['hanafi', 'hanbali'],
    'Used extensively as a source of legislation.',
    'Not used as a formal source.',
    'Not accepted as independent source.',
    'Used in limited circumstances.'
),
(
    'Maslaha Mursala (Unrestricted Public Interest)',
    'المصلحة المرسلة',
    'Considering public interest when no text exists',
    'مراعاة المصلحة العامة عند عدم وجود نص',
    ARRAY['maliki', 'hanafi'],
    'Used indirectly through istihsan.',
    'Used as an independent source. Malikis give it significant weight.',
    'Not accepted as independent source.',
    'Not accepted as independent source.'
),
(
    'Sadd al-Dharai (Blocking the Means)',
    'سد الذرائع',
    'Blocking means that may lead to prohibited ends',
    'سد الطرق التي قد تؤدي إلى المحرمات',
    ARRAY['maliki', 'hanbali', 'shafii'],
    'Used in limited circumstances.',
    'Used extensively. One of the characteristic features of Maliki fiqh.',
    'Used with conditions.',
    'Used extensively, especially in matters of worship.'
);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_madhab_rulings_madhab ON madhab_rulings(madhab);
CREATE INDEX IF NOT EXISTS idx_madhab_rulings_topic ON madhab_rulings(topic_id);
CREATE INDEX IF NOT EXISTS idx_madhab_rulings_category ON madhab_rulings(ruling_category);
CREATE INDEX IF NOT EXISTS idx_madhab_rulings_ijma ON madhab_rulings(has_ijma);
CREATE INDEX IF NOT EXISTS idx_madhab_scholars_madhab ON madhab_scholars(madhab);
