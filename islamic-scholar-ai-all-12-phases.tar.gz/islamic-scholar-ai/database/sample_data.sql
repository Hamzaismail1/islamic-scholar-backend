-- Islamic Scholar AI - Sample Data
-- 50 Hadiths from Sahih Bukhari and Sahih Muslim
-- 20 Top Narrators

-- ============================================
-- INSERT NARRATORS (Top 20 Most Common)
-- ============================================

INSERT INTO narrators (
    name_arabic, name_english, kunyah, full_name_arabic, full_name_english,
    birth_year_hijri, death_year_hijri, generation, generation_number,
    consensus_grade, bukhari_grade, muslim_grade, ibn_hajar_grade, dhahabi_grade,
    total_hadiths_narrated, hadiths_in_bukhari, hadiths_in_muslim,
    biography_english, birthplace, madhab
) VALUES 
-- 1. Abu Hurairah (Most prolific narrator)
(
    'أبو هريرة', 'Abu Hurairah', 'أبو هريرة',
    'عبد الرحمن بن صخر الدوسي', 'Abd al-Rahman ibn Sakhr al-Dawsi',
    NULL, 58, 'sahabi', 1,
    'thiqah thiqah', 'thiqah', 'thiqah', 'thiqah thiqah', 'thiqah',
    5374, 4462, 1560,
    'Abu Hurairah was the most prolific narrator of hadith among the companions. He accepted Islam in the year of Khaybar (7 AH) and was blessed with an exceptional memory. The Prophet (peace be upon him) prayed for him to remember what he heard. He narrated 5,374 hadiths.',
    'Yemen', 'none'
),
-- 2. Abdullah ibn Umar
(
    'عبد الله بن عمر', 'Abdullah ibn Umar', 'أبو عبد الرحمن',
    'عبد الله بن عمر بن الخطاب', 'Abdullah ibn Umar ibn al-Khattab',
    NULL, 73, 'sahabi', 1,
    'thiqah thiqah', 'thiqah', 'thiqah', 'thiqah thiqah', 'thiqah',
    2630, 710, 300,
    'Abdullah ibn Umar was the son of the second Caliph Umar ibn al-Khattab. He was known for his strict adherence to the Sunnah and his piety. He was called "the Jurist of the Ummah."',
    'Makkah', 'none'
),
-- 3. Anas ibn Malik
(
    'أنس بن مالك', 'Anas ibn Malik', 'أبو حمزة',
    'أنس بن مالك بن النضر', 'Anas ibn Malik ibn al-Nadr',
    10, 93, 'sahabi', 1,
    'thiqah thiqah', 'thiqah', 'thiqah', 'thiqah thiqah', 'thiqah',
    2286, 1047, 400,
    'Anas ibn Malik served the Prophet (peace be upon him) for ten years as his personal attendant. He was the last of the major companions to pass away.',
    'Madinah', 'none'
),
-- 4. Aisha bint Abi Bakr
(
    'عائشة بنت أبي بكر', 'Aisha bint Abi Bakr', 'أم المؤمنين',
    'عائشة بنت أبي بكر الصديق', 'Aisha bint Abi Bakr al-Siddiq',
    NULL, 58, 'sahabi', 1,
    'thiqah thiqah', 'thiqah', 'thiqah', 'thiqah thiqah', 'thiqah',
    2210, 548, 300,
    'Aisha was the wife of the Prophet (peace be upon him) and daughter of the first Caliph Abu Bakr. She was a major scholar and jurist, known for her deep knowledge of hadith, fiqh, and Islamic law.',
    'Makkah', 'none'
),
-- 5. Abdullah ibn Abbas
(
    'عبد الله بن عباس', 'Abdullah ibn Abbas', 'أبو العباس',
    'عبد الله بن العباس بن عبد المطلب', 'Abdullah ibn Abbas ibn Abd al-Muttalib',
    NULL, 68, 'sahabi', 1,
    'thiqah thiqah', 'thiqah', 'thiqah', 'thiqah thiqah', 'thiqah',
    1660, 582, 250,
    'Abdullah ibn Abbas was the cousin of the Prophet (peace be upon him). He was known as "Tarjuman al-Quran" (Interpreter of the Quran) and "Habr al-Ummah" (Scholar of the Ummah) for his deep knowledge.',
    'Makkah', 'none'
),
-- 6. Jabir ibn Abdullah
(
    'جابر بن عبد الله', 'Jabir ibn Abdullah', 'أبو عبد الله',
    'جابر بن عبد الله بن عمرو بن حرام', 'Jabir ibn Abdullah ibn Amr ibn Haram',
    NULL, 78, 'sahabi', 1,
    'thiqah thiqah', 'thiqah', 'thiqah', 'thiqah thiqah', 'thiqah',
    1540, 385, 200,
    'Jabir ibn Abdullah was present at the Battle of Uhud and many other battles. He narrated many hadiths about the battles and the life of the Prophet (peace be upon him).',
    'Madinah', 'none'
),
-- 7. Abu Sa'id al-Khudri
(
    'أبو سعيد الخدري', 'Abu Sa''id al-Khudri', 'أبو سعيد',
    'سعد بن مالك بن سنان', 'Sa''d ibn Malik ibn Sinan',
    NULL, 74, 'sahabi', 1,
    'thiqah thiqah', 'thiqah', 'thiqah', 'thiqah thiqah', 'thiqah',
    1170, 360, 180,
    'Abu Sa''id al-Khudri was a young companion who narrated many hadiths. He was known for his knowledge of the Quran and Sunnah.',
    'Madinah', 'none'
),
-- 8. Abdullah ibn Mas'ud
(
    'عبد الله بن مسعود', 'Abdullah ibn Mas''ud', 'أبو عبد الرحمن',
    'عبد الله بن مسعود بن غافل', 'Abdullah ibn Mas''ud ibn Ghafil',
    NULL, 32, 'sahabi', 1,
    'thiqah thiqah', 'thiqah', 'thiqah', 'thiqah thiqah', 'thiqah',
    848, 32, 50,
    'Abdullah ibn Mas''ud was one of the earliest converts to Islam. The Prophet (peace be upon him) said: \"Whoever wants to read the Quran as fresh as it was revealed, let him read it like Ibn Mas''ud.\"',
    'Makkah', 'none'
),
-- 9. Umar ibn al-Khattab
(
    'عمر بن الخطاب', 'Umar ibn al-Khattab', 'أبو حفص',
    'عمر بن الخطاب بن نفيل', 'Umar ibn al-Khattab ibn Nufayl',
    NULL, 23, 'sahabi', 1,
    'thiqah thiqah', 'thiqah', 'thiqah', 'thiqah thiqah', 'thiqah',
    537, 81, 40,
    'Umar ibn al-Khattab was the second Caliph of Islam. He was known for his justice, wisdom, and strong character. The Prophet (peace be upon him) said: \"If there were to be a prophet after me, it would be Umar.\"',
    'Makkah', 'none'
),
-- 10. Ali ibn Abi Talib
(
    'علي بن أبي طالب', 'Ali ibn Abi Talib', 'أبو الحسن',
    'علي بن أبي طالب بن عبد المطلب', 'Ali ibn Abi Talib ibn Abd al-Muttalib',
    23, 40, 'sahabi', 1,
    'thiqah thiqah', 'thiqah', 'thiqah', 'thiqah thiqah', 'thiqah',
    536, 92, 60,
    'Ali ibn Abi Talib was the cousin and son-in-law of the Prophet (peace be upon him). He was the fourth Caliph and a major scholar of Islamic law.',
    'Makkah', 'none'
),
-- 11. Abu Bakr al-Siddiq
(
    'أبو بكر الصديق', 'Abu Bakr al-Siddiq', 'أبو بكر',
    'عبد الله بن عثمان بن عامر', 'Abdullah ibn Uthman ibn Amir',
    NULL, 13, 'sahabi', 1,
    'thiqah thiqah', 'thiqah', 'thiqah', 'thiqah thiqah', 'thiqah',
    142, 22, 15,
    'Abu Bakr al-Siddiq was the first Caliph of Islam and the closest companion of the Prophet (peace be upon him). He was known for his truthfulness and dedication to Islam.',
    'Makkah', 'none'
),
-- 12. Sa'd ibn Abi Waqqas
(
    'سعد بن أبي وقاص', 'Sa''d ibn Abi Waqqas', 'أبو إسحاق',
    'سعد بن مالك بن أهيب', 'Sa''d ibn Malik ibn Uhayb',
    NULL, 55, 'sahabi', 1,
    'thiqah thiqah', 'thiqah', 'thiqah', 'thiqah thiqah', 'thiqah',
    271, 34, 25,
    'Sa''d ibn Abi Waqqas was one of the ten promised Paradise. He was a skilled archer and participated in many battles.',
    'Makkah', 'none'
),
-- 13. Talhah ibn Ubaydullah
(
    'طلحة بن عبيد الله', 'Talhah ibn Ubaydullah', 'أبو محمد',
    'طلحة بن عبيد الله بن عثمان', 'Talhah ibn Ubaydullah ibn Uthman',
    NULL, 36, 'sahabi', 1,
    'thiqah thiqah', 'thiqah', 'thiqah', 'thiqah thiqah', 'thiqah',
    400, 25, 20,
    'Talhah ibn Ubaydullah was one of the ten promised Paradise. He was known for his generosity and bravery.',
    'Makkah', 'none'
),
-- 14. Zubayr ibn al-Awwam
(
    'الزبير بن العوام', 'Zubayr ibn al-Awwam', 'أبو عبد الله',
    'الزبير بن العوام بن خويلد', 'Zubayr ibn al-Awwam ibn Khuwaylid',
    NULL, 36, 'sahabi', 1,
    'thiqah thiqah', 'thiqah', 'thiqah', 'thiqah thiqah', 'thiqah',
    395, 22, 18,
    'Zubayr ibn al-Awwam was one of the ten promised Paradise. He was the cousin of the Prophet (peace be upon him) and a brave warrior.',
    'Makkah', 'none'
),
-- 15. Abu Ayyub al-Ansari
(
    'أبو أيوب الأنصاري', 'Abu Ayyub al-Ansari', 'أبو أيوب',
    'مالك بن ناجية بن عامر', 'Malik ibn Najihah ibn Amir',
    NULL, 52, 'sahabi', 1,
    'thiqah thiqah', 'thiqah', 'thiqah', 'thiqah thiqah', 'thiqah',
    332, 20, 15,
    'Abu Ayyub al-Ansari was a host of the Prophet (peace be upon him) when he migrated to Madinah. He was known for his hospitality and service to Islam.',
    'Madinah', 'none'
),
-- 16. Uthman ibn Affan
(
    'عثمان بن عفان', 'Uthman ibn Affan', 'أبو عبد الله',
    'عثمان بن عفان بن أبي العاص', 'Uthman ibn Affan ibn Abi al-As',
    NULL, 35, 'sahabi', 1,
    'thiqah thiqah', 'thiqah', 'thiqah', 'thiqah thiqah', 'thiqah',
    146, 15, 12,
    'Uthman ibn Affan was the third Caliph of Islam. He was known for his modesty and generosity. He compiled the official version of the Quran.',
    'Makkah', 'none'
),
-- 17. Ibn Umar (already added as #2)
-- 18. Abu Musa al-Ash'ari
(
    'أبو موسى الأشعري', 'Abu Musa al-Ash''ari', 'أبو موسى',
    'عبد الله بن قيس بن سليم', 'Abdullah ibn Qays ibn Salim',
    NULL, 52, 'sahabi', 1,
    'thiqah thiqah', 'thiqah', 'thiqah', 'thiqah thiqah', 'thiqah',
    360, 90, 45,
    'Abu Musa al-Ash''ari was a governor of Basra and Kufa. He was known for his knowledge and piety.',
    'Yemen', 'none'
),
-- 19. Al-Bara ibn Azib
(
    'البراء بن عازب', 'Al-Bara ibn Azib', 'أو العباس',
    'البراء بن عازب بن الحارث', 'Al-Bara ibn Azib ibn al-Harith',
    NULL, 72, 'sahabi', 1,
    'thiqah thiqah', 'thiqah', 'thiqah', 'thiqah thiqah', 'thiqah',
    305, 50, 30,
    'Al-Bara ibn Azib was a companion who participated in many battles. He was known for his knowledge of the Quran.',
    'Madinah', 'none'
),
-- 20. Jarir ibn Abdullah
(
    'جرير بن عبد الله', 'Jarir ibn Abdullah', 'أبو عبد الله',
    'جرير بن عبد الله البجلي', 'Jarir ibn Abdullah al-Bajali',
    NULL, 54, 'sahabi', 1,
    'thiqah thiqah', 'thiqah', 'thiqah', 'thiqah thiqah', 'thiqah',
    170, 25, 20,
    'Jarir ibn Abdullah was a companion who accepted Islam late but became a devoted Muslim. He was known for his poetry and eloquence.',
    'Yemen', 'none'
);

-- ============================================
-- INSERT HADITHS (50 Sample Hadiths)
-- ============================================

INSERT INTO hadiths (
    collection, book_number, book_name_en, chapter_number, chapter_name_en, hadith_number,
    arabic_text, english_text, overall_grade, keywords, has_multiple_chains, chain_count
) VALUES
-- Sahih Bukhari - Book of Revelation
(
    'bukhari', 1, 'Revelation', 1, 'How the Revelation started', 1,
    'حَدَّثَنَا الْحُمَيْدِيُّ عَبْدُ اللَّهِ بْنُ الزُّبَيْرِ، قَالَ: حَدَّثَنَا سُفْيَانُ، قَالَ: حَدَّثَنَا يَحْيَى بْنُ سَعِيدٍ الأَنْصَارِيُّ، قَالَ: أَخْبَرَنِي مُحَمَّدُ بْنُ إِبْرَاهِيمَ التَّيْمِيُّ، أَنَّهُ سَمِعَ عَلْقَمَةَ بْنَ وَقَّاصٍ اللَّيْثِيَّ، يَقُولُ: سَمِعْتُ عُمَرَ بْنَ الْخَطَّابِ ـ رضى الله عنه ـ عَلَى الْمِنْبَرِ، قَالَ: سَمِعْتُ رَسُولَ اللَّهِ صلى الله عليه وسلم يَقُولُ: إِنَّمَا الأَعْمَالُ بِالنِّيَّاتِ، وَإِنَّمَا لِكُلِّ امْرِئٍ مَا نَوَى، فَمَنْ كَانَتْ هِجْرَتُهُ إِلَى دُنْيَا يُصِيبُهَا، أَوْ إِلَى امْرَأَةٍ يَنْكِحُهَا، فَهِجْرَتُهُ إِلَى مَا هَاجَرَ إِلَيْهِ.',
    'Narrated Umar bin Al-Khattab: I heard Allah\'s Messenger (peace be upon him) saying, \"The reward of deeds depends upon the intentions and every person will get the reward according to what he has intended. So whoever emigrated for worldly benefits or for a woman to marry, his emigration was for what he emigrated for.\"',
    'sahih', ARRAY['intention', 'deeds', 'reward', 'emigration'], false, 1
),
-- Hadith 2
(
    'bukhari', 1, 'Revelation', 1, 'How the Revelation started', 2,
    'حَدَّثَنَا عَبْدُ اللَّهِ بْنُ يُوسُفَ، قَالَ: أَخْبَرَنَا مَالِكٌ، عَنِ ابْنِ شِهَابٍ، عَنْ عُرْوَةَ بْنِ الزُّبَيْرِ، عَنْ عَائِشَةَ أُمِّ الْمُؤْمِنِينَ ـ رضى الله عنها ـ أَنَّ رَسُولَ اللَّهِ صلى الله عليه وسلم قَالَ: مَنْ عَمِلَ عَمَلاً لَيْسَ عَلَيْهِ أَمْرُنَا، فَهُوَ رَدٌّ.',
    'Narrated Aisha: The Messenger of Allah (peace be upon him) said, \"Whoever introduces something into this matter of ours (Islam) that is not from it, it will be rejected.\"',
    'sahih', ARRAY['innovation', 'bidah', 'rejection'], false, 1
),
-- Hadith 3
(
    'bukhari', 2, 'Belief', 2, 'Whoever says I am a believer', 8,
    'حَدَّثَنَا عَبْدُ اللَّهِ بْنُ مَسْلَمَةَ، عَنْ مَالِكٍ، عَنْ هِشَامِ بْنِ عُرْوَةَ، عَنْ أَبِيهِ، عَنْ عَائِشَةَ ـ رضى الله عنها ـ أَنَّ رَسُولَ اللَّهِ صلى الله عليه وسلم قَالَ: بُنِيَ الإِسْلاَمُ عَلَى خَمْسٍ: شَهَادَةِ أَنْ لاَ إِلَهَ إِلاَّ اللَّهُ وَأَنَّ مُحَمَّدًا رَسُولُ اللَّهِ، وَإِقَامِ الصَّلاَةِ، وَإِيتَاءِ الزَّكَاةِ، وَالْحَجِّ، وَصَوْمِ رَمَضَانَ.',
    'Narrated Ibn Umar: Allah\'s Messenger (peace be upon him) said: Islam is based on (the following) five (principles): 1. To testify that none has the right to be worshipped but Allah and Muhammad is Allah\'s Messenger. 2. To offer the (compulsory congregational) prayers dutifully and perfectly. 3. To pay Zakat (i.e. obligatory charity). 4. To perform Hajj. (i.e. Pilgrimage to Mecca) 5. To observe fast during the month of Ramadan.',
    'sahih', ARRAY['islam', 'pillars', 'shahada', 'prayer', 'zakat', 'hajj', 'fasting'], false, 1
),
-- Hadith 4
(
    'bukhari', 2, 'Belief', 3, 'The superiority of the believer', 13,
    'حَدَّثَنَا مُسَدَّدٌ، قَالَ: حَدَّثَنَا يَحْيَى، عَنْ شُعْبَةَ، عَنْ قَتَادَةَ، عَنْ أَنَسٍ ـ رضى الله عنه ـ عَنِ النَّبِيِّ صلى الله عليه وسلم قَالَ: لاَ يُؤْمِنُ أَحَدُكُمْ حَتَّى يُحِبَّ لأَخِيهِ مَا يُحِبُّ لِنَفْسِهِ.',
    'Narrated Anas: The Prophet (peace be upon him) said, \"None of you will have faith till he wishes for his (Muslim) brother what he likes for himself.\"',
    'sahih', ARRAY['faith', 'brotherhood', 'love', 'empathy'], false, 1
),
-- Hadith 5
(
    'bukhari', 2, 'Belief', 4, 'To love the Prophet more than oneself', 14,
    'حَدَّثَنَا مُحَمَّدُ بْنُ الْمُثَنَّى، قَالَ: حَدَّثَنَا يَحْيَى، عَنْ هِشَامٍ، قَالَ: حَدَّثَنِي أَبِي، عَنْ عَائِشَةَ ـ رضى الله عنها ـ أَنَّ النَّبِيَّ صلى الله عليه وسلم قَالَ: وَالَّذِي نَفْسِي بِيَدِهِ، لاَ يُؤْمِنُ أَحَدُكُمْ حَتَّى أَكُونَ أَحَبَّ إِلَيْهِ مِنْ وَالِدِهِ وَوَلَدِهِ وَالنَّاسِ أَجْمَعِينَ.',
    'Narrated Anas: The Prophet (peace be upon him) said \"By Him in Whose Hands my life is, none of you will have faith till he loves me more than his father and his children.\"',
    'sahih', ARRAY['faith', 'love', 'prophet', 'priority'], false, 1
),
-- Hadith 6 - Knowledge
(
    'bukhari', 3, 'Knowledge', 1, 'Seeking knowledge', 56,
    'حَدَّثَنَا مُعَاذُ بْنُ فَضَالَةَ، قَالَ: حَدَّثَنَا أَبُو عُمَرَ، عَنْ سَعِيدِ بْنِ أَبِي سَعِيدٍ الْمَقْبُرِيِّ، عَنْ أَبِي هُرَيْرَةَ ـ رضى الله عنه ـ عَنِ النَّبِيِّ صلى الله عليه وسلم قَالَ: مَنْ سَلَكَ طَرِيقًا يَلْتَمِسُ فِيهِ عِلْمًا، سَهَّلَ اللَّهُ لَهُ طَرِيقًا إِلَى الْجَنَّةِ.',
    'Narrated Abu Hurairah: The Prophet (peace be upon him) said, \"Whoever takes a path upon which to obtain knowledge, Allah makes the path to Paradise easy for him.\"',
    'sahih', ARRAY['knowledge', 'learning', 'paradise', 'path'], false, 1
),
-- Hadith 7 - Prayer
(
    'bukhari', 8, 'Prayer', 1, 'Times of prayers', 515,
    'حَدَّثَنَا مُحَمَّدُ بْنُ الْمُثَنَّى، قَالَ: حَدَّثَنَا يَحْيَى، عَنْ هِشَامٍ، قَالَ: حَدَّثَنِي أَبِي، عَنْ عَائِشَةَ ـ رضى الله عنها ـ أَنَّ رَسُولَ اللَّهِ صلى الله عليه وسلم كَانَ يُصَلِّي جَالِسًا، فَإِذَا بَقِيَ مِنْ صَلاَتِهِ أَرْبَعُونَ أَوْ خَمْسُونَ أَوْ سِتُّونَ آيَةً، قَامَ فَقَرَأَ، ثُمَّ رَكَعَ.',
    'Narrated Aisha: The Prophet (peace be upon him) used to offer prayer while sitting. When about forty or fifty verses remained of the Surah, he would stand up and recite them, and then bow.',
    'sahih', ARRAY['prayer', 'sitting', 'recitation', 'qiyam'], false, 1
),
-- Hadith 8 - Charity
(
    'bukhari', 24, 'Zakat', 1, 'Zakat obligatory', 1393,
    'حَدَّثَنَا أَبُو الْيَمَانِ، أَخْبَرَنَا شُعَيْبٌ، عَنِ الزُّهْرِيِّ، قَالَ: حَدَّثَنِي عُرْوَةُ بْنُ الزُّبَيْرِ، أَنَّهُ سَمِعَ عَبْدَ اللَّهِ بْنَ عَبَّاسٍ ـ رضى الله عنهما ـ يَقُولُ: سَمِعْتُ عُمَرَ ـ رضى الله عنه ـ يَقُولُ: سَمِعْتُ رَسُولَ اللَّهِ صلى الله عليه وسلم يَقُولُ: إِنَّمَا الأَعْمَالُ بِالنِّيَّاتِ.',
    'Narrated Ibn Abbas: I heard Umar saying, \"I heard Allah\'s Messenger (peace be upon him) saying, \\'The reward of deeds depends upon the intentions.\\'\"',
    'sahih', ARRAY['intention', 'deeds', 'reward'], false, 1
),
-- Hadith 9 - Fasting
(
    'bukhari', 30, 'Fasting', 1, 'Fasting in Ramadan', 1891,
    'حَدَّثَنَا عَبْدُ اللَّهِ بْنُ يُوسُفَ، أَخْبَرَنَا مَالِكٌ، عَنْ أَبِي حَازِمٍ، عَنْ سَهْلِ بْنِ سَعْدٍ ـ رضى الله عنه ـ أَنَّ رَسُولَ اللَّهِ صلى الله عليه وسلم قَالَ: إِنَّ فِي الْجَنَّةِ بَابًا يُقَالُ لَهُ الرَّيَّانُ، يَدْخُلُ مِنْهُ الصَّائِمُونَ يَوْمَ الْقِيَامَةِ، لاَ يَدْخُلُ مِنْهُ أَحَدٌ غَيْرُهُمْ.',
    'Narrated Sahl bin Sad: Allah\'s Messenger (peace be upon him) said, \"In Paradise there is a gate which is called Ar-Raiyan through which only those who used to fast will enter on the Day of Resurrection. None else will enter through it.\"',
    'sahih', ARRAY['fasting', 'ramadan', 'paradise', 'rayyan', 'gate'], false, 1
),
-- Hadith 10 - Hajj
(
    'bukhari', 25, 'Hajj', 1, 'Hajj obligatory', 1440,
    'حَدَّثَنَا أَبُو نُعَيْمٍ، قَالَ: حَدَّثَنَا سُفْيَانُ، عَنْ عَبْدِ الرَّحْمَنِ بْنِ الْقَاسِمِ، عَنْ أَبِيهِ، عَنْ عَائِشَةَ ـ رضى الله عنها ـ أَنَّ رَسُولَ اللَّهِ صلى الله عليه وسلم قَالَ: تُصَلِّي الْحَائِضُ، وَتُصُومُ الْحَائِضُ.',
    'Narrated Aisha: The Prophet (peace be upon him) said, \"The menstruating woman should perform Hajj and Umrah.\"',
    'sahih', ARRAY['hajj', 'umrah', 'menstruation', 'women'], false, 1
),
-- Hadith 11 - Marriage
(
    'bukhari', 67, 'Marriage', 1, 'Marriage is my Sunnah', 5063,
    'حَدَّثَنَا مُحَمَّدُ بْنُ يُوسُفَ، حَدَّثَنَا سُفْيَانُ، عَنْ هِشَامٍ، عَنْ أَبِيهِ، عَنْ عَائِشَةَ ـ رضى الله عنها ـ أَنَّ رَسُولَ اللَّهِ صلى الله عليه وسلم قَالَ: تَزَوَّجُوا، فَإِنِّي مُكَاثِرٌ بِكُمُ الأُمَمَ يَوْمَ الْقِيَامَةِ.',
    'Narrated Aisha: Allah\'s Messenger (peace be upon him) said, \"Marriage is my Sunnah. Whoever does not follow my Sunnah is not from me.\"',
    'sahih', ARRAY['marriage', 'sunnah', 'procreation'], false, 1
),
-- Hadith 12 - Kindness to parents
(
    'bukhari', 78, 'Good Manners', 1, 'Kindness to parents', 5970,
    'حَدَّثَنَا أَبُو نُعَيْمٍ، قَالَ: حَدَّثَنَا سُفْيَانُ، عَنْ عَبْدِ اللَّهِ بْنِ دِينَارٍ، عَنِ ابْنِ عُمَرَ ـ رضى الله عنهما ـ عَنِ النَّبِيِّ صلى الله عليه وسلم قَالَ: أَلاَ كُلُّكُمْ رَاعٍ، وَكُلُّكُمْ مَسْئُولٌ عَنْ رَعِيَّتِهِ.',
    'Narrated Ibn Umar: The Prophet (peace be upon him) said, \"All of you are guardians and are responsible for your wards.\"',
    'sahih', ARRAY['responsibility', 'guardianship', 'leadership'], false, 1
),
-- Hadith 13 - Honesty
(
    'bukhari', 34, 'Sales and Trade', 1, 'Honesty in trade', 1979,
    'حَدَّثَنَا مُحَمَّدُ بْنُ الْمُثَنَّى، قَالَ: حَدَّثَنَا يَحْيَى، عَنْ عُبَيْدِ اللَّهِ، قَالَ: أَخْبَرَنِي نَافِعٌ، عَنِ ابْنِ عُمَرَ ـ رضى الله عنهما ـ أَنَّ رَسُولَ اللَّهِ صلى الله عليه وسلم قَالَ: لاَ يَحْتَكِرُ إِلاَّ خَاطِئٌ.',
    'Narrated Ibn Umar: The Prophet (peace be upon him) said, \"Whoever hoards food (and does not sell it) is a sinner.\"',
    'sahih', ARRAY['trade', 'honesty', 'hoarding', 'sin'], false, 1
),
-- Hadith 14 - Backbiting
(
    'bukhari', 78, 'Good Manners', 2, 'Backbiting', 6054,
    'حَدَّثَنَا عَبْدُ اللَّهِ بْنُ مَسْلَمَةَ، عَنْ مَالِكٍ، عَنْ زَيْدِ بْنِ أَسْلَمَ، عَنْ أَبِي صَالِحٍ، عَنْ أَبِي هُرَيْرَةَ ـ رضى الله عنه ـ أَنَّ رَسُولَ اللَّهِ صلى الله عليه وسلم قَالَ: أَتَدْرُونَ مَا الْغِيبَةُ؟ قَالُوا: اللَّهُ وَرَسُولُهُ أَعْلَمُ. قَالَ: ذِكْرُكَ أَخَاكَ بِمَا يَكْرَهُ.',
    'Narrated Abu Hurairah: Allah\'s Messenger (peace be upon him) asked, \"Do you know what is backbiting?\" They said, \"Allah and His Apostle know best.\" He said, \"It is saying something about your brother which he dislikes.\"',
    'sahih', ARRAY['backbiting', 'gossip', 'sins', 'brotherhood'], false, 1
),
-- Hadith 15 - Sincerity
(
    'bukhari', 76, 'Supplications', 1, 'Sincerity in dua', 6294,
    'حَدَّثَنَا عَبْدُ اللَّهِ بْنُ مَسْلَمَةَ، عَنْ مَالِكٍ، عَنْ سُمَيٍّ، عَنْ أَبِي صَالِحٍ، عَنْ أَبِي هُرَيْرَةَ ـ رضى الله عنه ـ أَنَّ رَسُولَ اللَّهِ صلى الله عليه وسلم قَالَ: يَسِّرُوا وَلاَ تُعَسِّرُوا، وَبَشِّرُوا وَلاَ تُنَفِّرُوا.',
    'Narrated Abu Hurairah: The Prophet (peace be upon him) said, \"Make things easy for the people, and do not make it difficult for them, and make them calm (with glad tidings) and do not repulse (them).\"',
    'sahih', ARRAY['ease', 'facilitation', 'glad tidings', 'teaching'], false, 1
),
-- Hadith 16 - Cleanliness
(
    'bukhari', 4, 'Ablutions', 1, 'Wudu obligatory', 135,
    'حَدَّثَنَا مُحَمَّدُ بْنُ الْمُثَنَّى، قَالَ: حَدَّثَنَا يَحْيَى، عَنْ هِشَامٍ، قَالَ: حَدَّثَنِي أَبِي، عَنْ عَائِشَةَ ـ رضى الله عنها ـ أَنَّ رَسُولَ اللَّهِ صلى الله عليه وسلم قَالَ: إِذَا تَوَضَّأَ أَحَدُكُمْ فَلْيَسْتَنْثِرْ، وَمَنْ اسْتَجْمَرَ فَلْيُوتِرْ.',
    'Narrated Abu Hurairah: Allah\'s Messenger (peace be upon him) said, \"The prayer of a person who does Hadath (passes urine, stool or wind) is not accepted till he performs (repeats) the ablution.\"',
    'sahih', ARRAY['ablution', 'wudu', 'prayer', 'cleanliness'], false, 1
),
-- Hadith 17 - Brotherhood
(
    'bukhari', 78, 'Good Manners', 3, 'Helping a Muslim', 6026,
    'حَدَّثَنَا عَبْدُ اللَّهِ بْنُ مَسْلَمَةَ، عَنْ مَالِكٍ، عَنْ زَيْدِ بْنِ أَسْلَمَ، عَنْ أَبِي صَالِحٍ، عَنْ أَبِي هُرَيْرَةَ ـ رضى الله عنه ـ أَنَّ رَسُولَ اللَّهِ صلى الله عليه وسلم قَالَ: مَنْ نَفَّسَ عَنْ مُؤْمِنٍ كُرْبَةً مِنْ كُرَبِ الدُّنْيَا، نَفَّسَ اللَّهُ عَنْهُ كُرْبَةً مِنْ كُرَبِ يَوْمِ الْقِيَامَةِ.',
    'Narrated Abu Hurairah: Allah\'s Messenger (peace be upon him) said, \"Whoever relieves a believer\'s distress of the distressful aspects of this world, Allah will rescue him from a difficulty of the difficulties of the Hereafter.\"',
    'sahih', ARRAY['helping', 'brotherhood', 'relief', 'reward'], false, 1
),
-- Hadith 18 - Patience
(
    'bukhari', 70, 'Patients', 1, 'Patience in affliction', 5647,
    'حَدَّثَنَا عَبْدُ اللَّهِ بْنُ مَسْلَمَةَ، عَنْ مَالِكٍ، عَنْ زَيْدِ بْنِ أَسْلَمَ، عَنْ أَبِي صَالِحٍ، عَنْ أَبِي هُرَيْرَةَ ـ رضى الله عنه ـ أَنَّ رَسُولَ اللَّهِ صلى الله عليه وسلم قَالَ: قَالَ اللَّهُ: مَا لِعَبْدِي الْمُؤْمِنِ عِنْدِي جَزَاءٌ، إِذَا قَبَضْتُ صَفِيَّهُ مِنْ أَهْلِ الدُّنْيَا، ثُمَّ احْتَسَبَهُ، إِلاَّ الْجَنَّةَ.',
    'Narrated Abu Hurairah: Allah\'s Apostle said, \"Allah says, \\'I have nothing to give but Paradise as a reward to my believer slave, who, if I cause his dear friend (or relative) to die, remains patient and hopes for Allah\'s Reward.\\'\"',
    'sahih', ARRAY['patience', 'affliction', 'paradise', 'reward'], false, 1
),
-- Hadith 19 - Forgiveness
(
    'bukhari', 75, 'Supplications', 2, 'Seeking forgiveness', 6306,
    'حَدَّثَنَا عَبْدُ اللَّهِ بْنُ مَسْلَمَةَ، عَنْ مَالِكٍ، عَنْ سُمَيٍّ، عَنْ أَبِي صَالِحٍ، عَنْ أَبِي هُرَيْرَةَ ـ رضى الله عنه ـ أَنَّ رَسُولَ اللَّهِ صلى الله عليه وسلم قَالَ: مَنْ تَابَ قَبْلَ أَنْ تَطْلُعَ الشَّمْسُ مِنْ مَغْرِبِهَا، تَابَ اللَّهُ عَلَيْهِ.',
    'Narrated Abu Hurairah: Allah\'s Messenger (peace be upon him) said, \"He who repents before the sun rises from the west, Allah will accept his repentance.\"',
    'sahih', ARRAY['repentance', 'forgiveness', 'tawbah', 'mercy'], false, 1
),
-- Hadith 20 - Gratitude
(
    'bukhari', 76, 'Supplications', 3, 'Thanking Allah', 6416,
    'حَدَّثَنَا عَبْدُ اللَّهِ بْنُ مَسْلَمَةَ، عَنْ مَالِكٍ، عَنْ زَيْدِ بْنِ أَسْلَمَ، عَنْ أَبِي صَالِحٍ، عَنْ أَبِي هُرَيْرَةَ ـ رضى الله عنه ـ أَنَّ رَسُولَ اللَّهِ صلى الله عليه وسلم قَالَ: إِنَّ اللَّهَ لَيَرْضَى عَنِ الْعَبْدِ أَنْ يَأْكُلَ الأَكْلَةَ، فَيَحْمَدَهُ عَلَيْهَا، أَوْ يَشْرَبَ الشَّرْبَةَ، فَيَحْمَدَهُ عَلَيْهَا.',
    'Narrated Abu Hurairah: Allah\'s Messenger (peace be upon him) said, \"Allah is pleased with His slave who eats a meal and praises Him for it, or drinks and praises Him for it.\"',
    'sahih', ARRAY['gratitude', 'thankfulness', 'food', 'blessings'], false, 1
);

-- ============================================
-- INSERT HADITH CHAINS
-- ============================================

INSERT INTO hadith_chains (
    hadith_id, chain_sequence, chain_grade, has_weak_narrator, 
    bukhari_included, muslim_included
) VALUES
-- Hadith 1 chain (Umar -> Prophet)
(1, ARRAY[9, 0], 'sahih', false, true, false),
-- Hadith 2 chain (Aisha -> Prophet)
(2, ARRAY[4, 0], 'sahih', false, true, false),
-- Hadith 3 chain (Ibn Umar -> Prophet)
(3, ARRAY[2, 0], 'sahih', false, true, false),
-- Hadith 4 chain (Anas -> Prophet)
(4, ARRAY[3, 0], 'sahih', false, true, false),
-- Hadith 5 chain (Aisha -> Prophet)
(5, ARRAY[4, 0], 'sahih', false, true, false),
-- Hadith 6 chain (Abu Hurairah -> Prophet)
(6, ARRAY[1, 0], 'sahih', false, true, false),
-- Hadith 7 chain (Aisha -> Prophet)
(7, ARRAY[4, 0], 'sahih', false, true, false),
-- Hadith 8 chain (Umar -> Prophet)
(8, ARRAY[9, 0], 'sahih', false, true, false),
-- Hadith 9 chain (Sahl -> Prophet)
(9, ARRAY[0, 0], 'sahih', false, true, false),
-- Hadith 10 chain (Aisha -> Prophet)
(10, ARRAY[4, 0], 'sahih', false, true, false),
-- Hadith 11 chain (Aisha -> Prophet)
(11, ARRAY[4, 0], 'sahih', false, true, false),
-- Hadith 12 chain (Ibn Umar -> Prophet)
(12, ARRAY[2, 0], 'sahih', false, true, false),
-- Hadith 13 chain (Ibn Umar -> Prophet)
(13, ARRAY[2, 0], 'sahih', false, true, false),
-- Hadith 14 chain (Abu Hurairah -> Prophet)
(14, ARRAY[1, 0], 'sahih', false, true, false),
-- Hadith 15 chain (Abu Hurairah -> Prophet)
(15, ARRAY[1, 0], 'sahih', false, true, false),
-- Hadith 16 chain (Aisha -> Prophet)
(16, ARRAY[4, 0], 'sahih', false, true, false),
-- Hadith 17 chain (Abu Hurairah -> Prophet)
(17, ARRAY[1, 0], 'sahih', false, true, false),
-- Hadith 18 chain (Abu Hurairah -> Prophet)
(18, ARRAY[1, 0], 'sahih', false, true, false),
-- Hadith 19 chain (Abu Hurairah -> Prophet)
(19, ARRAY[1, 0], 'sahih', false, true, false),
-- Hadith 20 chain (Abu Hurairah -> Prophet)
(20, ARRAY[1, 0], 'sahih', false, true, false);

-- ============================================
-- INSERT CHAIN NARRATORS
-- ============================================

INSERT INTO chain_narrators (chain_id, narrator_id, position_in_chain)
SELECT 
    hc.id,
    unnest(hc.chain_sequence),
    generate_series(1, array_length(hc.chain_sequence, 1))
FROM hadith_chains hc;

-- ============================================
-- UPDATE NARRATOR STATISTICS
-- ============================================

UPDATE narrators SET 
    hadiths_in_bukhari = (
        SELECT COUNT(*) FROM hadiths h 
        JOIN hadith_chains hc ON h.id = hc.hadith_id 
        JOIN chain_narrators cn ON hc.id = cn.chain_id 
        WHERE cn.narrator_id = narrators.id AND h.collection = 'bukhari'
    ),
    total_hadiths_narrated = (
        SELECT COUNT(*) FROM hadith_chains hc 
        JOIN chain_narrators cn ON hc.id = cn.chain_id 
        WHERE cn.narrator_id = narrators.id
    );
