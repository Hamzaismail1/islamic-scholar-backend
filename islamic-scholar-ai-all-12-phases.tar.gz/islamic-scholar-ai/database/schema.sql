-- Islamic Scholar AI - Database Schema
-- PostgreSQL Database for Hadiths, Narrators, and Islamic Knowledge

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ============================================
-- HADITHS TABLE
-- ============================================
CREATE TABLE hadiths (
    id SERIAL PRIMARY KEY,
    
    -- Collection info
    collection VARCHAR(50) NOT NULL, -- 'bukhari', 'muslim', 'abu_dawud', etc.
    book_number INTEGER,
    book_name_ar VARCHAR(255),
    book_name_en VARCHAR(255),
    chapter_number INTEGER,
    chapter_name_ar VARCHAR(255),
    chapter_name_en VARCHAR(255),
    hadith_number INTEGER NOT NULL,
    
    -- Hadith text
    arabic_text TEXT NOT NULL,
    arabic_text_normalized TEXT, -- For search optimization
    
    -- Translations
    english_text TEXT,
    english_narrator TEXT,
    urdu_text TEXT,
    indonesian_text TEXT,
    
    -- Authentication
    overall_grade VARCHAR(20), -- 'sahih', 'hasan', 'dhaif', 'mawdu'
    albani_grade VARCHAR(50),
    
    -- Metadata
    has_multiple_chains BOOLEAN DEFAULT FALSE,
    chain_count INTEGER DEFAULT 1,
    theme VARCHAR(100),
    keywords TEXT[], -- Array of keywords
    
    -- Timestamps
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW(),
    
    -- Unique constraint
    UNIQUE(collection, hadith_number)
);

-- Create indexes for hadiths
CREATE INDEX idx_hadiths_collection ON hadiths(collection);
CREATE INDEX idx_hadiths_grade ON hadiths(overall_grade);
CREATE INDEX idx_hadiths_keywords ON hadiths USING gin(keywords);

-- Full-text search indexes
CREATE INDEX idx_hadiths_arabic_fts ON hadiths USING gin(to_tsvector('arabic', arabic_text));
CREATE INDEX idx_hadiths_english_fts ON hadiths USING gin(to_tsvector('english', english_text));

-- ============================================
-- NARRATORS TABLE (RIJAL)
-- ============================================
CREATE TABLE narrators (
    id SERIAL PRIMARY KEY,
    
    -- Names
    name_arabic VARCHAR(255) NOT NULL,
    name_english VARCHAR(255),
    full_name_arabic TEXT,
    full_name_english TEXT,
    kunyah VARCHAR(100), -- Abu/Umm X
    laqab VARCHAR(100), -- Nickname/title
    nisba VARCHAR(100), -- Attribution (al-Madani, al-Baghdadi)
    
    -- Life span
    birth_year_hijri INTEGER,
    birth_year_gregorian INTEGER,
    death_year_hijri INTEGER,
    death_year_gregorian INTEGER,
    age_at_death INTEGER,
    
    -- Classification
    generation VARCHAR(50), -- 'sahabi', 'tabi', 'tabi_tabi', 'taba_al_tabi'
    generation_number INTEGER, -- 1 = Companions, 2 = Successors, etc.
    
    -- Reliability Grades from Classical Scholars
    bukhari_grade VARCHAR(100),
    muslim_grade VARCHAR(100),
    ahmed_ibn_hanbal_grade VARCHAR(100),
    yahya_ibn_main_grade VARCHAR(100),
    ibn_hajar_grade VARCHAR(100), -- From Tahdhib al-Tahdhib
    dhahabi_grade VARCHAR(100), -- From Mizan al-I'tidal
    
    -- Overall consensus grade
    consensus_grade VARCHAR(50), -- 'thiqah', 'saduq', 'dhaif', 'matruk', 'kadhhab'
    
    -- Statistics
    total_hadiths_narrated INTEGER DEFAULT 0,
    hadiths_in_bukhari INTEGER DEFAULT 0,
    hadiths_in_muslim INTEGER DEFAULT 0,
    teachers_count INTEGER DEFAULT 0,
    students_count INTEGER DEFAULT 0,
    
    -- Biography
    biography_arabic TEXT,
    biography_english TEXT,
    
    -- Personal info
    birthplace VARCHAR(100),
    residence VARCHAR(100),
    madhab VARCHAR(50),
    
    -- References
    reference_books TEXT[], -- Which Rijal books mention this narrator
    
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- Create indexes for narrators
CREATE INDEX idx_narrators_name_arabic ON narrators(name_arabic);
CREATE INDEX idx_narrators_consensus_grade ON narrators(consensus_grade);
CREATE INDEX idx_narrators_generation ON narrators(generation);

-- ============================================
-- HADITH CHAINS (ISNAD)
-- ============================================
CREATE TABLE hadith_chains (
    id SERIAL PRIMARY KEY,
    hadith_id INTEGER REFERENCES hadiths(id) ON DELETE CASCADE,
    
    -- Chain details
    chain_sequence INTEGER[] NOT NULL, -- Ordered array of narrator IDs
    chain_arabic TEXT,
    chain_english TEXT,
    
    -- Authentication for this specific chain
    chain_grade VARCHAR(20), -- 'sahih', 'hasan', 'dhaif', 'munqati', 'mursal'
    chain_grade_reason TEXT,
    
    -- Weaknesses
    has_weak_narrator BOOLEAN DEFAULT FALSE,
    weak_narrator_id INTEGER REFERENCES narrators(id),
    weak_narrator_name VARCHAR(255),
    weakness_type VARCHAR(50), -- 'matruk', 'kadhhab', 'dhaif', etc.
    
    has_missing_link BOOLEAN DEFAULT FALSE,
    missing_link_location TEXT,
    
    -- Scholarly opinions on this chain
    bukhari_included BOOLEAN,
    muslim_included BOOLEAN,
    
    created_at TIMESTAMP DEFAULT NOW()
);

-- Create indexes for chains
CREATE INDEX idx_chains_hadith_id ON hadith_chains(hadith_id);
CREATE INDEX idx_chains_grade ON hadith_chains(chain_grade);

-- ============================================
-- CHAIN NARRATORS JUNCTION TABLE
-- ============================================
CREATE TABLE chain_narrators (
    id SERIAL PRIMARY KEY,
    chain_id INTEGER REFERENCES hadith_chains(id) ON DELETE CASCADE,
    narrator_id INTEGER REFERENCES narrators(id),
    position_in_chain INTEGER NOT NULL, -- 1 = closest to Prophet, N = final transmitter
    
    UNIQUE(chain_id, position_in_chain)
);

CREATE INDEX idx_chain_narrators_chain ON chain_narrators(chain_id);
CREATE INDEX idx_chain_narrators_narrator ON chain_narrators(narrator_id);

-- ============================================
-- NARRATOR RELATIONSHIPS (TEACHER-STUDENT)
-- ============================================
CREATE TABLE narrator_relationships (
    id SERIAL PRIMARY KEY,
    teacher_id INTEGER REFERENCES narrators(id),
    student_id INTEGER REFERENCES narrators(id),
    
    -- Relationship strength
    relationship_type VARCHAR(50), -- 'definite', 'probable', 'possible', 'disputed'
    
    -- Evidence
    hadith_count INTEGER DEFAULT 0, -- How many hadiths student narrated from teacher
    explicit_mention BOOLEAN, -- Mentioned in classical rijal books
    
    UNIQUE(teacher_id, student_id)
);

CREATE INDEX idx_relationships_teacher ON narrator_relationships(teacher_id);
CREATE INDEX idx_relationships_student ON narrator_relationships(student_id);

-- ============================================
-- USERS TABLE
-- ============================================
CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255),
    
    -- Profile
    username VARCHAR(100) UNIQUE,
    first_name VARCHAR(100),
    last_name VARCHAR(100),
    
    -- Preferences
    preferred_madhab VARCHAR(20), -- 'hanafi', 'maliki', 'shafii', 'hanbali'
    preferred_language VARCHAR(10) DEFAULT 'en',
    
    -- Subscription
    subscription_tier VARCHAR(20) DEFAULT 'free', -- 'free', 'premium', 'scholar'
    subscription_expires_at TIMESTAMP,
    
    -- Usage stats
    questions_asked INTEGER DEFAULT 0,
    questions_remaining INTEGER DEFAULT 10, -- For free tier
    
    -- Auth
    email_verified BOOLEAN DEFAULT FALSE,
    is_active BOOLEAN DEFAULT TRUE,
    
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW(),
    last_login_at TIMESTAMP
);

CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_subscription ON users(subscription_tier);

-- ============================================
-- SAVED HADITHS (USER FAVORITES)
-- ============================================
CREATE TABLE user_saved_hadiths (
    id SERIAL PRIMARY KEY,
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    hadith_id INTEGER REFERENCES hadiths(id) ON DELETE CASCADE,
    
    notes TEXT,
    tags TEXT[],
    
    created_at TIMESTAMP DEFAULT NOW(),
    
    UNIQUE(user_id, hadith_id)
);

CREATE INDEX idx_saved_hadiths_user ON user_saved_hadiths(user_id, created_at DESC);

-- ============================================
-- SEARCH LOGS (For analytics and improvement)
-- ============================================
CREATE TABLE search_logs (
    id SERIAL PRIMARY KEY,
    user_id UUID REFERENCES users(id),
    query TEXT NOT NULL,
    query_type VARCHAR(50), -- 'hadith', 'narrator', 'general'
    results_count INTEGER,
    clicked_result_id INTEGER,
    response_time_ms INTEGER,
    
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_search_logs_user ON search_logs(user_id);
CREATE INDEX idx_search_logs_created ON search_logs(created_at DESC);

-- ============================================
-- VECTOR EMBEDDINGS (For RAG)
-- ============================================
CREATE TABLE hadith_embeddings (
    id SERIAL PRIMARY KEY,
    hadith_id INTEGER REFERENCES hadiths(id) ON DELETE CASCADE,
    embedding_vector vector(1536), -- OpenAI embedding dimension
    model_name VARCHAR(100) DEFAULT 'text-embedding-3-large',
    
    created_at TIMESTAMP DEFAULT NOW(),
    
    UNIQUE(hadith_id)
);

CREATE INDEX idx_embeddings_vector ON hadith_embeddings USING ivfflat (embedding_vector vector_cosine_ops);

-- ============================================
-- TRIGGER FOR UPDATED_AT
-- ============================================
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_hadiths_updated_at BEFORE UPDATE ON hadiths
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_narrators_updated_at BEFORE UPDATE ON narrators
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON users
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
