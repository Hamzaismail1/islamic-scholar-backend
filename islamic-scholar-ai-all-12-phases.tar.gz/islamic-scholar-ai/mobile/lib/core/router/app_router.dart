import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../features/home/presentation/screens/home_screen.dart';
import '../../features/hadith/presentation/screens/hadith_search_screen.dart';
import '../../features/hadith/presentation/screens/hadith_detail_screen.dart';
import '../../features/narrator/presentation/screens/narrator_list_screen.dart';
import '../../features/narrator/presentation/screens/narrator_detail_screen.dart';
import '../../features/search/presentation/screens/rag_search_screen.dart';
import '../../features/settings/presentation/screens/settings_screen.dart';

// Router Provider
final appRouterProvider = Provider<GoRouter>((ref) {
  return GoRouter(
    initialLocation: '/',
    debugLogDiagnostics: true,
    routes: [
      // Home
      GoRoute(
        path: '/',
        name: 'home',
        builder: (context, state) => const HomeScreen(),
      ),
      
      // Hadith Routes
      GoRoute(
        path: '/hadiths',
        name: 'hadiths',
        builder: (context, state) => const HadithSearchScreen(),
      ),
      GoRoute(
        path: '/hadiths/:id',
        name: 'hadith-detail',
        builder: (context, state) {
          final id = int.parse(state.pathParameters['id']!);
          return HadithDetailScreen(hadithId: id);
        },
      ),
      
      // Narrator Routes
      GoRoute(
        path: '/narrators',
        name: 'narrators',
        builder: (context, state) => const NarratorListScreen(),
      ),
      GoRoute(
        path: '/narrators/:id',
        name: 'narrator-detail',
        builder: (context, state) {
          final id = int.parse(state.pathParameters['id']!);
          return NarratorDetailScreen(narratorId: id);
        },
      ),
      
      // AI Search
      GoRoute(
        path: '/ai-search',
        name: 'ai-search',
        builder: (context, state) => const RAGSearchScreen(),
      ),
      
      // Settings
      GoRoute(
        path: '/settings',
        name: 'settings',
        builder: (context, state) => const SettingsScreen(),
      ),
    ],
    errorBuilder: (context, state) => Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.error_outline, size: 64, color: Colors.red),
            const SizedBox(height: 16),
            Text(
              'Page Not Found',
              style: Theme.of(context).textTheme.headlineMedium,
            ),
            const SizedBox(height: 8),
            Text(
              'The page ${state.uri.path} does not exist.',
              style: Theme.of(context).textTheme.bodyMedium,
            ),
            const SizedBox(height: 24),
            ElevatedButton(
              onPressed: () => context.go('/'),
              child: const Text('Go Home'),
            ),
          ],
        ),
      ),
    ),
  );
});

// Navigation Helper
class AppNavigator {
  static void goHome(BuildContext context) => context.go('/');
  static void goHadiths(BuildContext context) => context.go('/hadiths');
  static void goHadithDetail(BuildContext context, int id) => 
      context.go('/hadiths/$id');
  static void goNarrators(BuildContext context) => context.go('/narrators');
  static void goNarratorDetail(BuildContext context, int id) => 
      context.go('/narrators/$id');
  static void goAISearch(BuildContext context) => context.go('/ai-search');
  static void goSettings(BuildContext context) => context.go('/settings');
}
