import 'package:dio/dio.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

// API Configuration
const String baseUrl = 'http://localhost:8000';

// Dio Provider
final dioProvider = Provider<Dio>((ref) {
  final dio = Dio(
    BaseOptions(
      baseUrl: baseUrl,
      connectTimeout: const Duration(seconds: 30),
      receiveTimeout: const Duration(seconds: 30),
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
      },
    ),
  );
  
  // Add interceptors
  dio.interceptors.add(
    InterceptorsWrapper(
      onRequest: (options, handler) {
        // Add auth token if available
        // final token = ref.read(authTokenProvider);
        // if (token != null) {
        //   options.headers['Authorization'] = 'Bearer $token';
        // }
        return handler.next(options);
      },
      onResponse: (response, handler) {
        return handler.next(response);
      },
      onError: (error, handler) {
        // Handle errors
        return handler.next(error);
      },
    ),
  );
  
  return dio;
});

// API Client Class
class ApiClient {
  final Dio _dio;
  
  ApiClient(this._dio);
  
  // Hadith Endpoints
  Future<Map<String, dynamic>> getHadiths({
    String? collection,
    String? grade,
    String? search,
    int page = 1,
    int pageSize = 20,
  }) async {
    final response = await _dio.get('/api/hadiths/', queryParameters: {
      if (collection != null) 'collection': collection,
      if (grade != null) 'grade': grade,
      if (search != null) 'search': search,
      'page': page,
      'page_size': pageSize,
    });
    return response.data;
  }
  
  Future<Map<String, dynamic>> searchHadiths(String query, {
    String? collection,
    String? grade,
    int limit = 20,
  }) async {
    final response = await _dio.get('/api/hadiths/search', queryParameters: {
      'q': query,
      if (collection != null) 'collection': collection,
      if (grade != null) 'grade': grade,
      'limit': limit,
    });
    return response.data;
  }
  
  Future<Map<String, dynamic>> getHadith(int id) async {
    final response = await _dio.get('/api/hadiths/$id');
    return response.data;
  }
  
  Future<Map<String, dynamic>> getHadithAuthentication(int id) async {
    final response = await _dio.get('/api/hadiths/$id/authentication');
    return response.data;
  }
  
  // Narrator Endpoints
  Future<Map<String, dynamic>> getNarrators({
    String? generation,
    String? grade,
    String? search,
    int page = 1,
    int pageSize = 20,
  }) async {
    final response = await _dio.get('/api/narrators/', queryParameters: {
      if (generation != null) 'generation': generation,
      if (grade != null) 'grade': grade,
      if (search != null) 'search': search,
      'page': page,
      'page_size': pageSize,
    });
    return response.data;
  }
  
  Future<Map<String, dynamic>> searchNarrators(String query, {int limit = 20}) async {
    final response = await _dio.get('/api/narrators/search', queryParameters: {
      'q': query,
      'limit': limit,
    });
    return response.data;
  }
  
  Future<Map<String, dynamic>> getNarrator(int id) async {
    final response = await _dio.get('/api/narrators/$id');
    return response.data;
  }
  
  // Search Endpoints
  Future<Map<String, dynamic>> globalSearch(String query, {String? type}) async {
    final response = await _dio.get('/api/search/', queryParameters: {
      'q': query,
      if (type != null) 'type': type,
    });
    return response.data;
  }
  
  // RAG Endpoints
  Future<Map<String, dynamic>> ragQuery(
    String query, {
    String? userMadhab,
    String authenticityFilter = 'sahih_only',
    int topK = 10,
  }) async {
    final response = await _dio.post('/api/rag/query', data: {
      'query': query,
      'user_madhab': userMadhab,
      'authenticity_filter': authenticityFilter,
      'top_k': topK,
    });
    return response.data;
  }
  
  Future<List<dynamic>> semanticSearch(
    String query, {
    int topK = 10,
  }) async {
    final response = await _dio.post('/api/rag/semantic-search', data: {
      'query': query,
      'top_k': topK,
    });
    return response.data;
  }
}

// API Client Provider
final apiClientProvider = Provider<ApiClient>((ref) {
  final dio = ref.watch(dioProvider);
  return ApiClient(dio);
});
