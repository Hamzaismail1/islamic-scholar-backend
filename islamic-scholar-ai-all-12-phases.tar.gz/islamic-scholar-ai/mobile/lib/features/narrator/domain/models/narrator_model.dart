import 'package:freezed_annotation/freezed_annotation.dart';

part 'narrator_model.freezed.dart';
part 'narrator_model.g.dart';

@freezed
class NarratorModel with _$NarratorModel {
  const factory NarratorModel({
    required int id,
    required String nameArabic,
    String? nameEnglish,
    String? kunyah,
    String? fullNameArabic,
    String? fullNameEnglish,
    int? birthYearHijri,
    int? deathYearHijri,
    String? generation,
    String? consensusGrade,
    String? biographyEnglish,
    String? birthplace,
    String? madhab,
    int? totalHadithsNarrated,
    int? hadithsInBukhari,
    int? hadithsInMuslim,
    DateTime? createdAt,
  }) = _NarratorModel;

  factory NarratorModel.fromJson(Map<String, dynamic> json) =>
      _$NarratorModelFromJson(json);
}

@freezed
class NarratorDetailModel with _$NarratorDetailModel {
  const factory NarratorDetailModel({
    required int id,
    required String nameArabic,
    String? nameEnglish,
    String? kunyah,
    String? fullNameArabic,
    String? fullNameEnglish,
    int? birthYearHijri,
    int? deathYearHijri,
    String? generation,
    String? consensusGrade,
    String? bukhariGrade,
    String? muslimGrade,
    String? ibnHajarGrade,
    String? dhahabiGrade,
    int? ageAtDeath,
    String? biographyEnglish,
    String? birthplace,
    String? residence,
    String? madhab,
    List<String>? referenceBooks,
    int? totalHadithsNarrated,
    int? hadithsInBukhari,
    int? hadithsInMuslim,
  }) = _NarratorDetailModel;

  factory NarratorDetailModel.fromJson(Map<String, dynamic> json) =>
      _$NarratorDetailModelFromJson(json);
}

@freezed
class NarratorListResponse with _$NarratorListResponse {
  const factory NarratorListResponse({
    required List<NarratorModel> items,
    required int total,
    required int page,
    required int pageSize,
    required int pages,
  }) = _NarratorListResponse;

  factory NarratorListResponse.fromJson(Map<String, dynamic> json) =>
      _$NarratorListResponseFromJson(json);
}
