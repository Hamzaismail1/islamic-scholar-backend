import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../../core/theme/app_theme.dart';
import '../../data/narrator_repository.dart';

class NarratorListScreen extends ConsumerStatefulWidget {
  const NarratorListScreen({super.key});

  @override
  ConsumerState<NarratorListScreen> createState() => _NarratorListScreenState();
}

class _NarratorListScreenState extends ConsumerState<NarratorListScreen> {
  final TextEditingController _searchController = TextEditingController();

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  void _performSearch() {
    final query = _searchController.text.trim();
    if (query.isNotEmpty) {
      ref.read(narratorSearchProvider.notifier).search(query);
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final searchResults = ref.watch(narratorSearchProvider);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Narrators'),
      ),
      body: Column(
        children: [
          // Search Bar
          Padding(
            padding: const EdgeInsets.all(16),
            child: TextField(
              controller: _searchController,
              decoration: InputDecoration(
                hintText: 'Search narrators...',
                prefixIcon: const Icon(Icons.search),
                suffixIcon: _searchController.text.isNotEmpty
                    ? IconButton(
                        icon: const Icon(Icons.clear),
                        onPressed: () {
                          _searchController.clear();
                          ref.read(narratorSearchProvider.notifier).clear();
                        },
                      )
                    : null,
              ),
              onSubmitted: (_) => _performSearch(),
            ),
          ),

          // Results
          Expanded(
            child: searchResults.when(
              data: (narrators) {
                if (narrators.isEmpty && _searchController.text.isEmpty) {
                  return _buildEmptyState(theme);
                }
                if (narrators.isEmpty) {
                  return _buildNoResultsState(theme);
                }
                return ListView.builder(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  itemCount: narrators.length,
                  itemBuilder: (context, index) {
                    final narrator = narrators[index];
                    return _NarratorListTile(
                      narrator: narrator,
                      onTap: () => context.push('/narrators/${narrator.id}'),
                    );
                  },
                );
              },
              loading: () => const Center(
                child: CircularProgressIndicator(),
              ),
              error: (error, _) => Center(
                child: Text('Error: $error'),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildEmptyState(ThemeData theme) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.people_outline,
            size: 64,
            color: AppTheme.onSurfaceVariant.withOpacity(0.5),
          ),
          const SizedBox(height: 16),
          Text(
            'Search Narrators',
            style: theme.textTheme.titleLarge?.copyWith(
              color: AppTheme.onSurfaceVariant,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'Find information about hadith narrators\nand their reliability grades',
            style: theme.textTheme.bodyMedium?.copyWith(
              color: AppTheme.onSurfaceVariant,
            ),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 24),
          Wrap(
            spacing: 8,
            children: [
              _SuggestionChip(
                label: 'Abu Hurairah',
                onTap: () {
                  _searchController.text = 'Abu Hurairah';
                  _performSearch();
                },
              ),
              _SuggestionChip(
                label: 'Aisha',
                onTap: () {
                  _searchController.text = 'Aisha';
                  _performSearch();
                },
              ),
              _SuggestionChip(
                label: 'Ibn Umar',
                onTap: () {
                  _searchController.text = 'Ibn Umar';
                  _performSearch();
                },
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildNoResultsState(ThemeData theme) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.search_off_outlined,
            size: 64,
            color: AppTheme.onSurfaceVariant.withOpacity(0.5),
          ),
          const SizedBox(height: 16),
          Text(
            'No Narrators Found',
            style: theme.textTheme.titleLarge?.copyWith(
              color: AppTheme.onSurfaceVariant,
            ),
          ),
        ],
      ),
    );
  }
}

class _NarratorListTile extends StatelessWidget {
  final dynamic narrator;
  final VoidCallback? onTap;

  const _NarratorListTile({required this.narrator, this.onTap});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      child: ListTile(
        onTap: onTap,
        leading: CircleAvatar(
          backgroundColor: AppTheme.getNarratorGradeColor(narrator.consensusGrade)
              .withOpacity(0.2),
          child: Text(
            narrator.nameArabic[0],
            style: TextStyle(
              color: AppTheme.getNarratorGradeColor(narrator.consensusGrade),
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
        title: Text(
          narrator.nameEnglish ?? narrator.nameArabic,
          style: theme.textTheme.titleSmall?.copyWith(
            fontWeight: FontWeight.bold,
          ),
        ),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              narrator.nameArabic,
              style: theme.textTheme.bodySmall?.copyWith(
                color: AppTheme.onSurfaceVariant,
              ),
            ),
            if (narrator.consensusGrade != null)
              Container(
                margin: const EdgeInsets.only(top: 4),
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                decoration: BoxDecoration(
                  color: AppTheme.getNarratorGradeColor(narrator.consensusGrade)
                      .withOpacity(0.1),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(
                  narrator.consensusGrade!,
                  style: theme.textTheme.bodySmall?.copyWith(
                    color: AppTheme.getNarratorGradeColor(narrator.consensusGrade),
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
          ],
        ),
        trailing: const Icon(Icons.chevron_right),
      ),
    );
  }
}

class _SuggestionChip extends StatelessWidget {
  final String label;
  final VoidCallback onTap;

  const _SuggestionChip({required this.label, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return ActionChip(
      label: Text(label),
      onPressed: onTap,
      backgroundColor: AppTheme.surfaceVariant,
      side: BorderSide.none,
    );
  }
}
