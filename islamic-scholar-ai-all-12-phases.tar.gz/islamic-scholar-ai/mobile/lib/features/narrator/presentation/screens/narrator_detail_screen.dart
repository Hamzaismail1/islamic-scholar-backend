import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/theme/app_theme.dart';
import '../../data/narrator_repository.dart';

class NarratorDetailScreen extends ConsumerWidget {
  final int narratorId;

  const NarratorDetailScreen({
    super.key,
    required this.narratorId,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final theme = Theme.of(context);
    final narratorAsync = ref.watch(narratorDetailProvider(narratorId));

    return Scaffold(
      appBar: AppBar(
        title: narratorAsync.when(
          data: (narrator) => Text(narrator.nameEnglish ?? narrator.nameArabic),
          loading: () => const Text('Loading...'),
          error: (_, __) => const Text('Error'),
        ),
      ),
      body: narratorAsync.when(
        data: (narrator) => SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Header Card
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [
                      AppTheme.primary,
                      AppTheme.primaryDark,
                    ],
                  ),
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Column(
                  children: [
                    // Arabic Name
                    Directionality(
                      textDirection: TextDirection.rtl,
                      child: Text(
                        narrator.nameArabic,
                        style: const TextStyle(
                          fontSize: 28,
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                          fontFamily: 'Amiri',
                        ),
                      ),
                    ),
                    const SizedBox(height: 8),
                    
                    // English Name
                    if (narrator.nameEnglish != null)
                      Text(
                        narrator.nameEnglish!,
                        style: theme.textTheme.titleMedium?.copyWith(
                          color: Colors.white70,
                        ),
                      ),
                    
                    const SizedBox(height: 16),
                    
                    // Grade Badge
                    if (narrator.consensusGrade != null)
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 16,
                          vertical: 8,
                        ),
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.2),
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Text(
                          narrator.consensusGrade!.toUpperCase(),
                          style: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                  ],
                ),
              ),
              
              const SizedBox(height: 24),
              
              // Stats Row
              Row(
                children: [
                  _StatCard(
                    label: 'Hadiths',
                    value: narrator.totalHadithsNarrated?.toString() ?? '0',
                    icon: Icons.menu_book_outlined,
                  ),
                  const SizedBox(width: 12),
                  _StatCard(
                    label: 'In Bukhari',
                    value: narrator.hadithsInBukhari?.toString() ?? '0',
                    icon: Icons.book_outlined,
                  ),
                  const SizedBox(width: 12),
                  _StatCard(
                    label: 'In Muslim',
                    value: narrator.hadithsInMuslim?.toString() ?? '0',
                    icon: Icons.book_outlined,
                  ),
                ],
              ),
              
              const SizedBox(height: 24),
              
              // Biography
              if (narrator.biographyEnglish != null) ...[
                Text(
                  'Biography',
                  style: theme.textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 12),
                Text(
                  narrator.biographyEnglish!,
                  style: theme.textTheme.bodyLarge?.copyWith(
                    height: 1.6,
                  ),
                ),
                const SizedBox(height: 24),
              ],
              
              // Details
              Text(
                'Details',
                style: theme.textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 12),
              
              _DetailRow(
                label: 'Generation',
                value: narrator.generation?.capitalize() ?? 'Unknown',
              ),
              
              if (narrator.birthYearHijri != null)
                _DetailRow(
                  label: 'Birth Year (Hijri)',
                  value: narrator.birthYearHijri.toString(),
                ),
              
              if (narrator.deathYearHijri != null)
                _DetailRow(
                  label: 'Death Year (Hijri)',
                  value: narrator.deathYearHijri.toString(),
                ),
              
              if (narrator.birthplace != null)
                _DetailRow(
                  label: 'Birthplace',
                  value: narrator.birthplace!,
                ),
              
              if (narrator.madhab != null)
                _DetailRow(
                  label: 'Madhab',
                  value: narrator.madhab!.capitalize(),
                ),
              
              const SizedBox(height: 24),
              
              // Scholar Grades
              if (narrator.bukhariGrade != null ||
                  narrator.muslimGrade != null ||
                  narrator.ibnHajarGrade != null ||
                  narrator.dhahabiGrade != null) ...[
                Text(
                  'Scholarly Grades',
                  style: theme.textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 12),
                
                if (narrator.bukhariGrade != null)
                  _GradeRow(
                    scholar: 'Imam Bukhari',
                    grade: narrator.bukhariGrade!,
                  ),
                
                if (narrator.muslimGrade != null)
                  _GradeRow(
                    scholar: 'Imam Muslim',
                    grade: narrator.muslimGrade!,
                  ),
                
                if (narrator.ibnHajarGrade != null)
                  _GradeRow(
                    scholar: 'Ibn Hajar',
                    grade: narrator.ibnHajarGrade!,
                  ),
                
                if (narrator.dhahabiGrade != null)
                  _GradeRow(
                    scholar: 'Imam Dhahabi',
                    grade: narrator.dhahabiGrade!,
                  ),
              ],
              
              const SizedBox(height: 32),
            ],
          ),
        ),
        loading: () => const Center(
          child: CircularProgressIndicator(),
        ),
        error: (error, _) => Center(
          child: Text('Error: $error'),
        ),
      ),
    );
  }
}

class _StatCard extends StatelessWidget {
  final String label;
  final String value;
  final IconData icon;

  const _StatCard({
    required this.label,
    required this.value,
    required this.icon,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: AppTheme.surfaceVariant,
          borderRadius: BorderRadius.circular(12),
        ),
        child: Column(
          children: [
            Icon(icon, color: AppTheme.primary),
            const SizedBox(height: 8),
            Text(
              value,
              style: theme.textTheme.titleLarge?.copyWith(
                fontWeight: FontWeight.bold,
                color: AppTheme.primary,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              label,
              style: theme.textTheme.bodySmall?.copyWith(
                color: AppTheme.onSurfaceVariant,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _DetailRow extends StatelessWidget {
  final String label;
  final String value;

  const _DetailRow({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        children: [
          Text(
            label,
            style: theme.textTheme.bodyMedium?.copyWith(
              color: AppTheme.onSurfaceVariant,
            ),
          ),
          const Spacer(),
          Text(
            value,
            style: theme.textTheme.bodyMedium?.copyWith(
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }
}

class _GradeRow extends StatelessWidget {
  final String scholar;
  final String grade;

  const _GradeRow({required this.scholar, required this.grade});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        children: [
          Text(
            scholar,
            style: theme.textTheme.bodyMedium,
          ),
          const Spacer(),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
            decoration: BoxDecoration(
              color: AppTheme.getNarratorGradeColor(grade).withOpacity(0.1),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Text(
              grade,
              style: theme.textTheme.bodySmall?.copyWith(
                color: AppTheme.getNarratorGradeColor(grade),
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

extension StringExtension on String {
  String capitalize() {
    if (isEmpty) return this;
    return "${this[0].toUpperCase()}${substring(1)}";
  }
}
