import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/api/api_client.dart';
import '../domain/models/narrator_model.dart';

// Narrator Repository Provider
final narratorRepositoryProvider = Provider<NarratorRepository>((ref) {
  final apiClient = ref.watch(apiClientProvider);
  return NarratorRepository(apiClient);
});

class NarratorRepository {
  final ApiClient _apiClient;

  NarratorRepository(this._apiClient);

  Future<NarratorListResponse> getNarrators({
    String? generation,
    String? grade,
    String? search,
    int page = 1,
    int pageSize = 20,
  }) async {
    final data = await _apiClient.getNarrators(
      generation: generation,
      grade: grade,
      search: search,
      page: page,
      pageSize: pageSize,
    );
    return NarratorListResponse.fromJson(data);
  }

  Future<List<NarratorModel>> searchNarrators(String query, {int limit = 20}) async {
    final data = await _apiClient.searchNarrators(query, limit: limit);
    return (data as List)
        .map((item) => NarratorModel.fromJson(item))
        .toList();
  }

  Future<NarratorDetailModel> getNarrator(int id) async {
    final data = await _apiClient.getNarrator(id);
    return NarratorDetailModel.fromJson(data);
  }
}

// State Notifiers for UI
final narratorSearchProvider = StateNotifierProvider<NarratorSearchNotifier, AsyncValue<List<NarratorModel>>>((ref) {
  return NarratorSearchNotifier(ref.watch(narratorRepositoryProvider));
});

class NarratorSearchNotifier extends StateNotifier<AsyncValue<List<NarratorModel>>> {
  final NarratorRepository _repository;

  NarratorSearchNotifier(this._repository) : super(const AsyncValue.data([]));

  Future<void> search(String query) async {
    if (query.isEmpty) {
      state = const AsyncValue.data([]);
      return;
    }

    state = const AsyncValue.loading();
    try {
      final results = await _repository.searchNarrators(query);
      state = AsyncValue.data(results);
    } catch (e, st) {
      state = AsyncValue.error(e, st);
    }
  }

  void clear() {
    state = const AsyncValue.data([]);
  }
}

final narratorDetailProvider = FutureProvider.family<NarratorDetailModel, int>((ref, id) async {
  final repository = ref.watch(narratorRepositoryProvider);
  return repository.getNarrator(id);
});

final narratorListProvider = FutureProvider.family<NarratorListResponse, NarratorListParams>((ref, params) async {
  final repository = ref.watch(narratorRepositoryProvider);
  return repository.getNarrators(
    generation: params.generation,
    grade: params.grade,
    search: params.search,
    page: params.page,
    pageSize: params.pageSize,
  );
});

class NarratorListParams {
  final String? generation;
  final String? grade;
  final String? search;
  final int page;
  final int pageSize;

  NarratorListParams({
    this.generation,
    this.grade,
    this.search,
    this.page = 1,
    this.pageSize = 20,
  });
}
