import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/theme/app_theme.dart';
import '../../data/hadith_repository.dart';

class HadithDetailScreen extends ConsumerWidget {
  final int hadithId;

  const HadithDetailScreen({
    super.key,
    required this.hadithId,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final theme = Theme.of(context);
    final hadithAsync = ref.watch(hadithDetailProvider(hadithId));
    final authAsync = ref.watch(hadithAuthenticationProvider(hadithId));

    return Scaffold(
      appBar: AppBar(
        title: hadithAsync.when(
          data: (hadith) => Text('${hadith.collection.capitalize()} ${hadith.hadithNumber}'),
          loading: () => const Text('Loading...'),
          error: (_, __) => const Text('Error'),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.share_outlined),
            onPressed: () {},
          ),
          IconButton(
            icon: const Icon(Icons.bookmark_border),
            onPressed: () {},
          ),
        ],
      ),
      body: hadithAsync.when(
        data: (hadith) => SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Grade Badge
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    decoration: BoxDecoration(
                      color: AppTheme.getGradeColor(hadith.overallGrade),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Text(
                      hadith.overallGrade?.toUpperCase() ?? 'UNKNOWN',
                      style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        fontSize: 12,
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  if (hadith.bookNameEn != null)
                    Expanded(
                      child: Text(
                        hadith.bookNameEn!,
                        style: theme.textTheme.bodyMedium?.copyWith(
                          color: AppTheme.onSurfaceVariant,
                        ),
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                ],
              ),
              const SizedBox(height: 24),

              // Arabic Text
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: AppTheme.surfaceVariant,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Directionality(
                  textDirection: TextDirection.rtl,
                  child: Text(
                    hadith.arabicText,
                    style: const TextStyle(
                      fontSize: 22,
                      height: 2,
                      fontFamily: 'Amiri',
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 24),

              // English Translation
              if (hadith.englishText != null) ...[
                Text(
                  'Translation',
                  style: theme.textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 12),
                Text(
                  hadith.englishText!,
                  style: theme.textTheme.bodyLarge?.copyWith(
                    height: 1.6,
                  ),
                ),
                const SizedBox(height: 24),
              ],

              // Keywords
              if (hadith.keywords != null && hadith.keywords!.isNotEmpty) ...[
                Text(
                  'Keywords',
                  style: theme.textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 12),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: hadith.keywords!
                      .map((keyword) => Chip(
                            label: Text(keyword),
                            backgroundColor: AppTheme.surfaceVariant,
                            side: BorderSide.none,
                          ))
                      .toList(),
                ),
                const SizedBox(height: 24),
              ],

              // Authentication Section
              Text(
                'Authentication',
                style: theme.textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 12),

              authAsync.when(
                data: (auth) => Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Authentication Explanation
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: AppTheme.primary.withOpacity(0.05),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(
                          color: AppTheme.primary.withOpacity(0.2),
                        ),
                      ),
                      child: Text(
                        auth.authenticationExplanation,
                        style: theme.textTheme.bodyMedium,
                      ),
                    ),
                    const SizedBox(height: 16),

                    // Chains
                    if (auth.chains.isNotEmpty) ...[
                      Text(
                        'Chain of Transmission',
                        style: theme.textTheme.titleSmall?.copyWith(
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 12),
                      ...auth.chains.map((chain) => _ChainCard(chain: chain)),
                    ],
                  ],
                ),
                loading: () => const Center(
                  child: CircularProgressIndicator(),
                ),
                error: (error, _) => Text(
                  'Error loading authentication: $error',
                  style: theme.textTheme.bodyMedium?.copyWith(
                    color: AppTheme.error,
                  ),
                ),
              ),

              const SizedBox(height: 32),
            ],
          ),
        ),
        loading: () => const Center(
          child: CircularProgressIndicator(),
        ),
        error: (error, _) => Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(Icons.error_outline, size: 64, color: AppTheme.error),
              const SizedBox(height: 16),
              Text(
                'Error: $error',
                style: theme.textTheme.bodyMedium,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _ChainCard extends StatelessWidget {
  final dynamic chain;

  const _ChainCard({required this.chain});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(
                  chain.hasMissingLink
                      ? Icons.error_outline
                      : Icons.check_circle_outline,
                  color: chain.hasMissingLink ? AppTheme.error : AppTheme.sahih,
                ),
                const SizedBox(width: 8),
                Text(
                  'Grade: ${chain.chainGrade ?? 'Unknown'}',
                  style: theme.textTheme.titleSmall?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
            if (chain.chainGradeReason != null) ...[
              const SizedBox(height: 8),
              Text(
                chain.chainGradeReason!,
                style: theme.textTheme.bodySmall?.copyWith(
                  color: AppTheme.onSurfaceVariant,
                ),
              ),
            ],
            if (chain.hasWeakNarrator) ...[
              const SizedBox(height: 12),
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: AppTheme.warning.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Row(
                  children: [
                    const Icon(Icons.warning_amber, color: AppTheme.warning, size: 20),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        'Weak narrator: ${chain.weakNarratorName}',
                        style: theme.textTheme.bodySmall?.copyWith(
                          color: AppTheme.warning,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}

extension StringExtension on String {
  String capitalize() {
    return "${this[0].toUpperCase()}${substring(1)}";
  }
}
