import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../../core/theme/app_theme.dart';
import '../widgets/hadith_card.dart';
import '../../data/hadith_repository.dart';

class HadithSearchScreen extends ConsumerStatefulWidget {
  const HadithSearchScreen({super.key});

  @override
  ConsumerState<HadithSearchScreen> createState() => _HadithSearchScreenState();
}

class _HadithSearchScreenState extends ConsumerState<HadithSearchScreen> {
  final TextEditingController _searchController = TextEditingController();
  String? _selectedCollection;
  String? _selectedGrade;

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  void _performSearch() {
    final query = _searchController.text.trim();
    if (query.isNotEmpty) {
      ref.read(hadithSearchProvider.notifier).search(
        query,
        collection: _selectedCollection,
        grade: _selectedGrade,
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final searchResults = ref.watch(hadithSearchProvider);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Search Hadiths'),
        actions: [
          IconButton(
            icon: const Icon(Icons.filter_list),
            onPressed: () => _showFilterSheet(context),
          ),
        ],
      ),
      body: Column(
        children: [
          // Search Bar
          Padding(
            padding: const EdgeInsets.all(16),
            child: TextField(
              controller: _searchController,
              decoration: InputDecoration(
                hintText: 'Search hadiths...',
                prefixIcon: const Icon(Icons.search),
                suffixIcon: _searchController.text.isNotEmpty
                    ? IconButton(
                        icon: const Icon(Icons.clear),
                        onPressed: () {
                          _searchController.clear();
                          ref.read(hadithSearchProvider.notifier).clear();
                        },
                      )
                    : null,
              ),
              onSubmitted: (_) => _performSearch(),
              textInputAction: TextInputAction.search,
            ),
          ),

          // Active Filters
          if (_selectedCollection != null || _selectedGrade != null)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Row(
                children: [
                  if (_selectedCollection != null)
                    Padding(
                      padding: const EdgeInsets.only(right: 8),
                      child: Chip(
                        label: Text(_selectedCollection!.capitalize()),
                        onDeleted: () {
                          setState(() => _selectedCollection = null);
                          _performSearch();
                        },
                      ),
                    ),
                  if (_selectedGrade != null)
                    Chip(
                      label: Text(_selectedGrade!.capitalize()),
                      backgroundColor: AppTheme.getGradeColor(_selectedGrade),
                      onDeleted: () {
                        setState(() => _selectedGrade = null);
                        _performSearch();
                      },
                    ),
                ],
              ),
            ),

          // Results
          Expanded(
            child: searchResults.when(
              data: (results) {
                if (results.isEmpty && _searchController.text.isEmpty) {
                  return _buildEmptyState(theme);
                }
                if (results.isEmpty) {
                  return _buildNoResultsState(theme);
                }
                return ListView.builder(
                  padding: const EdgeInsets.all(16),
                  itemCount: results.length,
                  itemBuilder: (context, index) {
                    final result = results[index];
                    return HadithCard(
                      hadith: result.hadith,
                      relevanceScore: result.relevanceScore,
                      onTap: () => context.push('/hadiths/${result.hadith.id}'),
                    );
                  },
                );
              },
              loading: () => const Center(
                child: CircularProgressIndicator(),
              ),
              error: (error, _) => Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Icon(Icons.error_outline, size: 48, color: AppTheme.error),
                    const SizedBox(height: 16),
                    Text(
                      'Error: $error',
                      style: theme.textTheme.bodyMedium,
                      textAlign: TextAlign.center,
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildEmptyState(ThemeData theme) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.menu_book_outlined,
            size: 64,
            color: AppTheme.onSurfaceVariant.withOpacity(0.5),
          ),
          const SizedBox(height: 16),
          Text(
            'Search Hadiths',
            style: theme.textTheme.titleLarge?.copyWith(
              color: AppTheme.onSurfaceVariant,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'Enter keywords to search through\nSahih Bukhari and Sahih Muslim',
            style: theme.textTheme.bodyMedium?.copyWith(
              color: AppTheme.onSurfaceVariant,
            ),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 24),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            alignment: WrapAlignment.center,
            children: [
              _SuggestionChip(
                label: 'Intention',
                onTap: () {
                  _searchController.text = 'intention';
                  _performSearch();
                },
              ),
              _SuggestionChip(
                label: 'Prayer',
                onTap: () {
                  _searchController.text = 'prayer';
                  _performSearch();
                },
              ),
              _SuggestionChip(
                label: 'Charity',
                onTap: () {
                  _searchController.text = 'charity';
                  _performSearch();
                },
              ),
              _SuggestionChip(
                label: 'Patience',
                onTap: () {
                  _searchController.text = 'patience';
                  _performSearch();
                },
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildNoResultsState(ThemeData theme) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.search_off_outlined,
            size: 64,
            color: AppTheme.onSurfaceVariant.withOpacity(0.5),
          ),
          const SizedBox(height: 16),
          Text(
            'No Results Found',
            style: theme.textTheme.titleLarge?.copyWith(
              color: AppTheme.onSurfaceVariant,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'Try different keywords or filters',
            style: theme.textTheme.bodyMedium?.copyWith(
              color: AppTheme.onSurfaceVariant,
            ),
          ),
        ],
      ),
    );
  }

  void _showFilterSheet(BuildContext context) {
    showModalBottomSheet(
      context: context,
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setModalState) {
            return Container(
              padding: const EdgeInsets.all(20),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Filters',
                    style: Theme.of(context).textTheme.titleLarge?.copyWith(
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 20),
                  
                  // Collection Filter
                  Text(
                    'Collection',
                    style: Theme.of(context).textTheme.titleSmall,
                  ),
                  const SizedBox(height: 8),
                  Wrap(
                    spacing: 8,
                    children: [
                      _FilterChip(
                        label: 'All',
                        selected: _selectedCollection == null,
                        onSelected: (_) {
                          setModalState(() => _selectedCollection = null);
                        },
                      ),
                      _FilterChip(
                        label: 'Bukhari',
                        selected: _selectedCollection == 'bukhari',
                        onSelected: (_) {
                          setModalState(() => _selectedCollection = 'bukhari');
                        },
                      ),
                      _FilterChip(
                        label: 'Muslim',
                        selected: _selectedCollection == 'muslim',
                        onSelected: (_) {
                          setModalState(() => _selectedCollection = 'muslim');
                        },
                      ),
                    ],
                  ),
                  const SizedBox(height: 20),
                  
                  // Grade Filter
                  Text(
                    'Grade',
                    style: Theme.of(context).textTheme.titleSmall,
                  ),
                  const SizedBox(height: 8),
                  Wrap(
                    spacing: 8,
                    children: [
                      _FilterChip(
                        label: 'All',
                        selected: _selectedGrade == null,
                        onSelected: (_) {
                          setModalState(() => _selectedGrade = null);
                        },
                      ),
                      _FilterChip(
                        label: 'Sahih',
                        selected: _selectedGrade == 'sahih',
                        color: AppTheme.sahih,
                        onSelected: (_) {
                          setModalState(() => _selectedGrade = 'sahih');
                        },
                      ),
                      _FilterChip(
                        label: 'Hasan',
                        selected: _selectedGrade == 'hasan',
                        color: AppTheme.hasan,
                        onSelected: (_) {
                          setModalState(() => _selectedGrade = 'hasan');
                        },
                      ),
                    ],
                  ),
                  const SizedBox(height: 20),
                  
                  // Apply Button
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: () {
                        Navigator.pop(context);
                        _performSearch();
                      },
                      child: const Text('Apply Filters'),
                    ),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }
}

class _SuggestionChip extends StatelessWidget {
  final String label;
  final VoidCallback onTap;

  const _SuggestionChip({required this.label, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return ActionChip(
      label: Text(label),
      onPressed: onTap,
      backgroundColor: AppTheme.surfaceVariant,
      side: BorderSide.none,
    );
  }
}

class _FilterChip extends StatelessWidget {
  final String label;
  final bool selected;
  final Color? color;
  final ValueChanged<bool> onSelected;

  const _FilterChip({
    required this.label,
    required this.selected,
    this.color,
    required this.onSelected,
  });

  @override
  Widget build(BuildContext context) {
    return FilterChip(
      label: Text(label),
      selected: selected,
      onSelected: onSelected,
      selectedColor: color?.withOpacity(0.2) ?? AppTheme.primary.withOpacity(0.2),
      checkmarkColor: color ?? AppTheme.primary,
    );
  }
}

extension StringExtension on String {
  String capitalize() {
    return "${this[0].toUpperCase()}${substring(1)}";
  }
}
