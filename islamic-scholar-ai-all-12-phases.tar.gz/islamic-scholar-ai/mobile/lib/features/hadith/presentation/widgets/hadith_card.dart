import 'package:flutter/material.dart';

import '../../../../core/theme/app_theme.dart';
import '../../domain/models/hadith_model.dart';

class HadithCard extends StatelessWidget {
  final HadithModel hadith;
  final double? relevanceScore;
  final VoidCallback? onTap;

  const HadithCard({
    super.key,
    required this.hadith,
    this.relevanceScore,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Header Row
              Row(
                children: [
                  // Grade Badge
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                    decoration: BoxDecoration(
                      color: AppTheme.getGradeColor(hadith.overallGrade),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Text(
                      (hadith.overallGrade ?? 'Unknown').toUpperCase(),
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 10,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  
                  // Collection & Number
                  Text(
                    '${hadith.collection.capitalize()} ${hadith.hadithNumber}',
                    style: theme.textTheme.bodySmall?.copyWith(
                      color: AppTheme.onSurfaceVariant,
                    ),
                  ),
                  
                  const Spacer(),
                  
                  // Relevance Score (if available)
                  if (relevanceScore != null)
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                      decoration: BoxDecoration(
                        color: AppTheme.primary.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Text(
                        '${(relevanceScore! * 100).toInt()}%',
                        style: theme.textTheme.bodySmall?.copyWith(
                          color: AppTheme.primary,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                ],
              ),
              
              const SizedBox(height: 12),
              
              // Arabic Text Preview
              Directionality(
                textDirection: TextDirection.rtl,
                child: Text(
                  _truncateArabic(hadith.arabicText, 120),
                  style: const TextStyle(
                    fontSize: 16,
                    height: 1.8,
                    fontFamily: 'Amiri',
                  ),
                  maxLines: 3,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
              
              const SizedBox(height: 12),
              
              // English Translation Preview
              if (hadith.englishText != null)
                Text(
                  _truncateEnglish(hadith.englishText!, 150),
                  style: theme.textTheme.bodyMedium?.copyWith(
                    color: AppTheme.onSurfaceVariant,
                    height: 1.5,
                  ),
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                ),
              
              const SizedBox(height: 12),
              
              // Keywords
              if (hadith.keywords != null && hadith.keywords!.isNotEmpty)
                Wrap(
                  spacing: 6,
                  runSpacing: 6,
                  children: hadith.keywords!
                      .take(4)
                      .map((keyword) => Container(
                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                            decoration: BoxDecoration(
                              color: AppTheme.surfaceVariant,
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: Text(
                              keyword,
                              style: theme.textTheme.bodySmall?.copyWith(
                                fontSize: 11,
                              ),
                            ),
                          ))
                      .toList(),
                ),
            ],
          ),
        ),
      ),
    );
  }

  String _truncateArabic(String text, int maxLength) {
    if (text.length <= maxLength) return text;
    return '${text.substring(0, maxLength)}...';
  }

  String _truncateEnglish(String text, int maxLength) {
    if (text.length <= maxLength) return text;
    return '${text.substring(0, maxLength)}...';
  }
}

class HadithListTile extends StatelessWidget {
  final HadithModel hadith;
  final VoidCallback? onTap;

  const HadithListTile({
    super.key,
    required this.hadith,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return ListTile(
      onTap: onTap,
      leading: Container(
        width: 48,
        height: 48,
        decoration: BoxDecoration(
          color: AppTheme.getGradeColor(hadith.overallGrade).withOpacity(0.1),
          borderRadius: BorderRadius.circular(8),
        ),
        child: Center(
          child: Text(
            (hadith.overallGrade ?? '?')[0].toUpperCase(),
            style: TextStyle(
              color: AppTheme.getGradeColor(hadith.overallGrade),
              fontWeight: FontWeight.bold,
              fontSize: 18,
            ),
          ),
        ),
      ),
      title: Text(
        '${hadith.collection.capitalize()} ${hadith.hadithNumber}',
        style: theme.textTheme.titleSmall?.copyWith(
          fontWeight: FontWeight.bold,
        ),
      ),
      subtitle: Text(
        hadith.theme ?? 'No theme',
        style: theme.textTheme.bodySmall?.copyWith(
          color: AppTheme.onSurfaceVariant,
        ),
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
      ),
      trailing: const Icon(Icons.chevron_right),
    );
  }
}

extension StringExtension on String {
  String capitalize() {
    if (isEmpty) return this;
    return "${this[0].toUpperCase()}${substring(1)}";
  }
}
