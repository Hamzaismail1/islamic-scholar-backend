import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/api/api_client.dart';
import '../domain/models/hadith_model.dart';

// Hadith Repository Provider
final hadithRepositoryProvider = Provider<HadithRepository>((ref) {
  final apiClient = ref.watch(apiClientProvider);
  return HadithRepository(apiClient);
});

class HadithRepository {
  final ApiClient _apiClient;

  HadithRepository(this._apiClient);

  Future<HadithListResponse> getHadiths({
    String? collection,
    String? grade,
    String? search,
    int page = 1,
    int pageSize = 20,
  }) async {
    final data = await _apiClient.getHadiths(
      collection: collection,
      grade: grade,
      search: search,
      page: page,
      pageSize: pageSize,
    );
    return HadithListResponse.fromJson(data);
  }

  Future<List<HadithSearchResult>> searchHadiths(
    String query, {
    String? collection,
    String? grade,
    int limit = 20,
  }) async {
    final data = await _apiClient.searchHadiths(
      query,
      collection: collection,
      grade: grade,
      limit: limit,
    );
    return (data as List)
        .map((item) => HadithSearchResult.fromJson(item))
        .toList();
  }

  Future<HadithModel> getHadith(int id) async {
    final data = await _apiClient.getHadith(id);
    return HadithModel.fromJson(data);
  }

  Future<HadithAuthenticationModel> getHadithAuthentication(int id) async {
    final data = await _apiClient.getHadithAuthentication(id);
    
    // Parse chains from response
    final chains = (data['chains'] as List)
        .map((chain) => HadithChainModel.fromJson(chain))
        .toList();
    
    return HadithAuthenticationModel(
      hadithId: data['hadith_id'],
      overallGrade: data['overall_grade'],
      chains: chains,
      authenticationExplanation: data['authentication_explanation'],
      scholarlyOpinions: data['scholarly_opinions'],
    );
  }
}

// State Notifiers for UI
final hadithSearchProvider = StateNotifierProvider<HadithSearchNotifier, AsyncValue<List<HadithSearchResult>>>((ref) {
  return HadithSearchNotifier(ref.watch(hadithRepositoryProvider));
});

class HadithSearchNotifier extends StateNotifier<AsyncValue<List<HadithSearchResult>>> {
  final HadithRepository _repository;

  HadithSearchNotifier(this._repository) : super(const AsyncValue.data([]));

  Future<void> search(String query, {String? collection, String? grade}) async {
    if (query.isEmpty) {
      state = const AsyncValue.data([]);
      return;
    }

    state = const AsyncValue.loading();
    try {
      final results = await _repository.searchHadiths(
        query,
        collection: collection,
        grade: grade,
      );
      state = AsyncValue.data(results);
    } catch (e, st) {
      state = AsyncValue.error(e, st);
    }
  }

  void clear() {
    state = const AsyncValue.data([]);
  }
}

final hadithDetailProvider = FutureProvider.family<HadithModel, int>((ref, id) async {
  final repository = ref.watch(hadithRepositoryProvider);
  return repository.getHadith(id);
});

final hadithAuthenticationProvider = FutureProvider.family<HadithAuthenticationModel, int>((ref, id) async {
  final repository = ref.watch(hadithRepositoryProvider);
  return repository.getHadithAuthentication(id);
});
