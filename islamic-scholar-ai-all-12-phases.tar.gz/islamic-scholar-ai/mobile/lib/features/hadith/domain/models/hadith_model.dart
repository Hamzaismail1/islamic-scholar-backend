import 'package:freezed_annotation/freezed_annotation.dart';

part 'hadith_model.freezed.dart';
part 'hadith_model.g.dart';

@freezed
class HadithModel with _$HadithModel {
  const factory HadithModel({
    required int id,
    required String collection,
    int? bookNumber,
    String? bookNameEn,
    int? chapterNumber,
    String? chapterNameEn,
    required int hadithNumber,
    required String arabicText,
    String? englishText,
    String? overallGrade,
    String? theme,
    List<String>? keywords,
    bool? hasMultipleChains,
    int? chainCount,
    DateTime? createdAt,
  }) = _HadithModel;

  factory HadithModel.fromJson(Map<String, dynamic> json) =>
      _$HadithModelFromJson(json);
}

@freezed
class HadithChainModel with _$HadithChainModel {
  const factory HadithChainModel({
    required int id,
    required List<int> chainSequence,
    String? chainGrade,
    String? chainGradeReason,
    bool? hasWeakNarrator,
    String? weakNarratorName,
    String? weaknessType,
    bool? hasMissingLink,
    bool? bukhariIncluded,
    bool? muslimIncluded,
  }) = _HadithChainModel;

  factory HadithChainModel.fromJson(Map<String, dynamic> json) =>
      _$HadithChainModelFromJson(json);
}

@freezed
class HadithAuthenticationModel with _$HadithAuthenticationModel {
  const factory HadithAuthenticationModel({
    required int hadithId,
    String? overallGrade,
    required List<HadithChainModel> chains,
    required String authenticationExplanation,
    Map<String, dynamic>? scholarlyOpinions,
  }) = _HadithAuthenticationModel;

  factory HadithAuthenticationModel.fromJson(Map<String, dynamic> json) =>
      _$HadithAuthenticationModelFromJson(json);
}

@freezed
class HadithListResponse with _$HadithListResponse {
  const factory HadithListResponse({
    required List<HadithModel> items,
    required int total,
    required int page,
    required int pageSize,
    required int pages,
  }) = _HadithListResponse;

  factory HadithListResponse.fromJson(Map<String, dynamic> json) =>
      _$HadithListResponseFromJson(json);
}

@freezed
class HadithSearchResult with _$HadithSearchResult {
  const factory HadithSearchResult({
    required HadithModel hadith,
    required double relevanceScore,
    required List<String> matchedKeywords,
  }) = _HadithSearchResult;

  factory HadithSearchResult.fromJson(Map<String, dynamic> json) =>
      _$HadithSearchResultFromJson(json);
}
