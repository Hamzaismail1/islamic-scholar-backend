import 'package:freezed_annotation/freezed_annotation.dart';

part 'rag_model.freezed.dart';
part 'rag_model.g.dart';

@freezed
class RAGSource with _$RAGSource {
  const factory RAGSource({
    required String type,
    required int id,
    required String reference,
    required String text,
    String? grade,
    required double relevanceScore,
  }) = _RAGSource;

  factory RAGSource.fromJson(Map<String, dynamic> json) =>
      _$RAGSourceFromJson(json);
}

@freezed
class RAGResponse with _$RAGResponse {
  const factory RAGResponse({
    required String query,
    required String answer,
    required double confidenceScore,
    required List<RAGSource> sources,
    required bool requiresScholarReview,
    String? reviewReason,
  }) = _RAGResponse;

  factory RAGResponse.fromJson(Map<String, dynamic> json) =>
      _$RAGResponseFromJson(json);
}

@freezed
class SemanticSearchResult with _$SemanticSearchResult {
  const factory SemanticSearchResult({
    required int hadithId,
    required String collection,
    required int hadithNumber,
    required String arabicText,
    String? englishText,
    String? overallGrade,
    required double similarityScore,
  }) = _SemanticSearchResult;

  factory SemanticSearchResult.fromJson(Map<String, dynamic> json) =>
      _$SemanticSearchResultFromJson(json);
}
