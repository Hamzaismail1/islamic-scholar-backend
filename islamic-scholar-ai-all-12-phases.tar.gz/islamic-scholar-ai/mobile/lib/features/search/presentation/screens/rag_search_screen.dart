import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/theme/app_theme.dart';
import '../../data/rag_repository.dart';

class RAGSearchScreen extends ConsumerStatefulWidget {
  const RAGSearchScreen({super.key});

  @override
  ConsumerState<RAGSearchScreen> createState() => _RAGSearchScreenState();
}

class _RAGSearchScreenState extends ConsumerState<RAGSearchScreen> {
  final TextEditingController _queryController = TextEditingController();
  String _authenticityFilter = 'sahih_only';

  @override
  void dispose() {
    _queryController.dispose();
    super.dispose();
  }

  void _performQuery() {
    final query = _queryController.text.trim();
    if (query.isNotEmpty) {
      ref.read(ragQueryProvider.notifier).query(
        query,
        authenticityFilter: _authenticityFilter,
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final ragResponse = ref.watch(ragQueryProvider);

    return Scaffold(
      appBar: AppBar(
        title: const Text('AI Search'),
        actions: [
          PopupMenuButton<String>(
            icon: const Icon(Icons.tune),
            onSelected: (value) {
              setState(() => _authenticityFilter = value);
            },
            itemBuilder: (context) => [
              const PopupMenuItem(
                value: 'sahih_only',
                child: Text('Sahih Only'),
              ),
              const PopupMenuItem(
                value: 'sahih_hasan',
                child: Text('Sahih & Hasan'),
              ),
              const PopupMenuItem(
                value: 'all',
                child: Text('All Grades'),
              ),
            ],
          ),
        ],
      ),
      body: Column(
        children: [
          // Query Input
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: AppTheme.surface,
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.05),
                  blurRadius: 8,
                  offset: const Offset(0, 2),
                ),
              ],
            ),
            child: Column(
              children: [
                TextField(
                  controller: _queryController,
                  decoration: InputDecoration(
                    hintText: 'Ask any Islamic question...',
                    prefixIcon: const Icon(Icons.psychology_outlined),
                    suffixIcon: IconButton(
                      icon: const Icon(Icons.send),
                      onPressed: _performQuery,
                    ),
                  ),
                  maxLines: 3,
                  minLines: 1,
                  textInputAction: TextInputAction.send,
                  onSubmitted: (_) => _performQuery(),
                ),
                const SizedBox(height: 8),
                Row(
                  children: [
                    Chip(
                      label: Text(
                        _authenticityFilter.replaceAll('_', ' ').toUpperCase(),
                        style: const TextStyle(fontSize: 10),
                      ),
                      backgroundColor: AppTheme.surfaceVariant,
                      side: BorderSide.none,
                    ),
                    const Spacer(),
                    Text(
                      'Powered by GPT-4',
                      style: theme.textTheme.bodySmall?.copyWith(
                        color: AppTheme.onSurfaceVariant,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),

          // Results
          Expanded(
            child: ragResponse.when(
              data: (response) {
                if (response == null) {
                  return _buildEmptyState(theme);
                }
                return _buildResponseView(theme, response);
              },
              loading: () => const Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    CircularProgressIndicator(),
                    SizedBox(height: 16),
                    Text('Searching Islamic knowledge...'),
                  ],
                ),
              ),
              error: (error, _) => Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Icon(Icons.error_outline, size: 48, color: AppTheme.error),
                    const SizedBox(height: 16),
                    Text(
                      'Error: $error',
                      style: theme.textTheme.bodyMedium,
                      textAlign: TextAlign.center,
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildEmptyState(ThemeData theme) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.psychology_outlined,
            size: 64,
            color: AppTheme.onSurfaceVariant.withOpacity(0.5),
          ),
          const SizedBox(height: 16),
          Text(
            'Ask Islamic Questions',
            style: theme.textTheme.titleLarge?.copyWith(
              color: AppTheme.onSurfaceVariant,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'Get AI-powered answers from authentic hadiths\nwith full citations and authentication',
            style: theme.textTheme.bodyMedium?.copyWith(
              color: AppTheme.onSurfaceVariant,
            ),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 24),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            alignment: WrapAlignment.center,
            children: [
              _ExampleChip(
                label: 'What did the Prophet say about intentions?',
                onTap: () {
                  _queryController.text = 'What did the Prophet say about intentions?';
                  _performQuery();
                },
              ),
              _ExampleChip(
                label: 'How should we treat our parents?',
                onTap: () {
                  _queryController.text = 'How should we treat our parents?';
                  _performQuery();
                },
              ),
              _ExampleChip(
                label: 'What are the pillars of Islam?',
                onTap: () {
                  _queryController.text = 'What are the pillars of Islam?';
                  _performQuery();
                },
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildResponseView(ThemeData theme, dynamic response) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Scholar Review Warning
          if (response.requiresScholarReview)
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(16),
              margin: const EdgeInsets.only(bottom: 16),
              decoration: BoxDecoration(
                color: AppTheme.warning.withOpacity(0.1),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: AppTheme.warning.withOpacity(0.3)),
              ),
              child: Row(
                children: [
                  const Icon(Icons.warning_amber, color: AppTheme.warning),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Scholar Review Recommended',
                          style: theme.textTheme.titleSmall?.copyWith(
                            color: AppTheme.warning,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        if (response.reviewReason != null)
                          Text(
                            response.reviewReason!,
                            style: theme.textTheme.bodySmall?.copyWith(
                              color: AppTheme.warning,
                            ),
                          ),
                      ],
                    ),
                  ),
                ],
              ),
            ),

          // Answer
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: AppTheme.surface,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: AppTheme.primary.withOpacity(0.2)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                      decoration: BoxDecoration(
                        color: AppTheme.primary.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const Icon(
                            Icons.psychology,
                            size: 16,
                            color: AppTheme.primary,
                          ),
                          const SizedBox(width: 6),
                          Text(
                            'AI Answer',
                            style: theme.textTheme.bodySmall?.copyWith(
                              color: AppTheme.primary,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
                    ),
                    const Spacer(),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                      decoration: BoxDecoration(
                        color: _getConfidenceColor(response.confidenceScore),
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Text(
                        '${(response.confidenceScore * 100).toInt()}% Confidence',
                        style: theme.textTheme.bodySmall?.copyWith(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                Text(
                  response.answer,
                  style: theme.textTheme.bodyLarge?.copyWith(
                    height: 1.8,
                  ),
                ),
              ],
            ),
          ),

          const SizedBox(height: 24),

          // Sources
          if (response.sources.isNotEmpty) ...[
            Text(
              'Sources',
              style: theme.textTheme.titleMedium?.copyWith(
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 12),
            ...response.sources.map((source) => _SourceCard(source: source)),
          ],

          const SizedBox(height: 32),
        ],
      ),
    );
  }

  Color _getConfidenceColor(double score) {
    if (score >= 0.8) return AppTheme.sahih;
    if (score >= 0.6) return AppTheme.hasan;
    if (score >= 0.4) return AppTheme.warning;
    return AppTheme.error;
  }
}

class _ExampleChip extends StatelessWidget {
  final String label;
  final VoidCallback onTap;

  const _ExampleChip({required this.label, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return ActionChip(
      label: Text(
        label,
        style: const TextStyle(fontSize: 12),
      ),
      onPressed: onTap,
      backgroundColor: AppTheme.surfaceVariant,
      side: BorderSide.none,
    );
  }
}

class _SourceCard extends StatelessWidget {
  final dynamic source;

  const _SourceCard({required this.source});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    color: AppTheme.getGradeColor(source.grade),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text(
                    (source.grade ?? 'Unknown').toUpperCase(),
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 10,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                Text(
                  source.reference,
                  style: theme.textTheme.bodySmall?.copyWith(
                    color: AppTheme.onSurfaceVariant,
                  ),
                ),
                const Spacer(),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                  decoration: BoxDecoration(
                    color: AppTheme.primary.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(
                    '${(source.relevanceScore * 100).toInt()}%',
                    style: theme.textTheme.bodySmall?.copyWith(
                      color: AppTheme.primary,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Text(
              source.text,
              style: theme.textTheme.bodyMedium?.copyWith(
                color: AppTheme.onSurfaceVariant,
              ),
              maxLines: 3,
              overflow: TextOverflow.ellipsis,
            ),
          ],
        ),
      ),
    );
  }
}
