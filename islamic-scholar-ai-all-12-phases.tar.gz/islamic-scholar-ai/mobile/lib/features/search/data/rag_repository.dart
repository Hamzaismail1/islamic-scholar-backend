import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/api/api_client.dart';
import '../domain/models/rag_model.dart';

// RAG Repository Provider
final ragRepositoryProvider = Provider<RAGRepository>((ref) {
  final apiClient = ref.watch(apiClientProvider);
  return RAGRepository(apiClient);
});

class RAGRepository {
  final ApiClient _apiClient;

  RAGRepository(this._apiClient);

  Future<RAGResponse> query(
    String query, {
    String? userMadhab,
    String authenticityFilter = 'sahih_only',
    int topK = 10,
  }) async {
    final data = await _apiClient.ragQuery(
      query,
      userMadhab: userMadhab,
      authenticityFilter: authenticityFilter,
      topK: topK,
    );
    return RAGResponse.fromJson(data);
  }

  Future<List<SemanticSearchResult>> semanticSearch(
    String query, {
    int topK = 10,
  }) async {
    final data = await _apiClient.semanticSearch(query, topK: topK);
    return data
        .map((item) => SemanticSearchResult.fromJson(item))
        .toList();
  }
}

// State Notifiers for UI
final ragQueryProvider = StateNotifierProvider<RAGQueryNotifier, AsyncValue<RAGResponse?>>((ref) {
  return RAGQueryNotifier(ref.watch(ragRepositoryProvider));
});

class RAGQueryNotifier extends StateNotifier<AsyncValue<RAGResponse?>> {
  final RAGRepository _repository;

  RAGQueryNotifier(this._repository) : super(const AsyncValue.data(null));

  Future<void> query(
    String query, {
    String? userMadhab,
    String authenticityFilter = 'sahih_only',
  }) async {
    if (query.isEmpty) {
      state = const AsyncValue.data(null);
      return;
    }

    state = const AsyncValue.loading();
    try {
      final result = await _repository.query(
        query,
        userMadhab: userMadhab,
        authenticityFilter: authenticityFilter,
      );
      state = AsyncValue.data(result);
    } catch (e, st) {
      state = AsyncValue.error(e, st);
    }
  }

  void clear() {
    state = const AsyncValue.data(null);
  }
}

final semanticSearchProvider = StateNotifierProvider<SemanticSearchNotifier, AsyncValue<List<SemanticSearchResult>>>((ref) {
  return SemanticSearchNotifier(ref.watch(ragRepositoryProvider));
});

class SemanticSearchNotifier extends StateNotifier<AsyncValue<List<SemanticSearchResult>>> {
  final RAGRepository _repository;

  SemanticSearchNotifier(this._repository) : state(const AsyncValue.data([]));

  Future<void> search(String query, {int topK = 10}) async {
    if (query.isEmpty) {
      state = const AsyncValue.data([]);
      return;
    }

    state = const AsyncValue.loading();
    try {
      final results = await _repository.semanticSearch(query, topK: topK);
      state = AsyncValue.data(results);
    } catch (e, st) {
      state = AsyncValue.error(e, st);
    }
  }

  void clear() {
    state = const AsyncValue.data([]);
  }
}
