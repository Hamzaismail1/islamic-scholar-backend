"""
ISLAMIC SCHOLAR AI - 4 MADHAB COMPARISON ENGINE
Data Models for Fiqh Comparison
Phase 5: 4 Madhab Comparison Engine
"""

from sqlalchemy import Column, Integer, String, Text, JSON, ForeignKey, Enum, Boolean, DateTime, ARRAY
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from enum import Enum as PyEnum
from app.db.database import Base


class MadhabType(str, PyEnum):
    """The four major schools of Islamic jurisprudence"""
    HANAFI = "hanafi"
    MALIKI = "maliki"
    SHAFII = "shafii"
    HANBALI = "hanbali"


class EvidenceType(str, PyEnum):
    """Types of evidence used in fiqh rulings"""
    QURAN = "quran"
    SUNNAH = "sunnah"
    IJMA = "ijma"
    QIYAS = "qiyas"
    ISTIHSAN = "istihsan"
    MASLAHA = "maslaha"
    SADD_AL_DHARAI = "sadd_al_dharai"
    ISTISHAB = "istishab"
    URF = "urf"


class RulingCategory(str, PyEnum):
    """Categories of fiqh rulings"""
    WAJIB = "wajib"  # Obligatory
    MANDUB = "mandub"  # Recommended
    MUBAH = "mubah"  # Permissible
    MAKRUH = "makruh"  # Disliked
    HARAM = "haram"  # Forbidden
    SAH = "sah"  # Valid
    BATIL = "batil"  # Invalid


class FiqhTopic(Base):
    """Main fiqh topics/categories"""
    __tablename__ = "fiqh_topics"
    
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(200), nullable=False)
    name_arabic = Column(String(200))
    description = Column(Text)
    parent_id = Column(Integer, ForeignKey("fiqh_topics.id"), nullable=True)
    
    # Relationships
    subtopics = relationship("FiqhTopic", backref="parent", remote_side=[id])
    rulings = relationship("MadhabRuling", back_populates="topic")
    
    created_at = Column(DateTime, server_default=func.now())
    updated_at = Column(DateTime, onupdate=func.now())


class MadhabRuling(Base):
    """Fiqh rulings from each of the 4 madhabs"""
    __tablename__ = "madhab_rulings"
    
    id = Column(Integer, primary_key=True, index=True)
    
    # Topic reference
    topic_id = Column(Integer, ForeignKey("fiqh_topics.id"), nullable=False)
    topic = relationship("FiqhTopic", back_populates="rulings")
    
    # Madhab identification
    madhab = Column(Enum(MadhabType), nullable=False, index=True)
    
    # Ruling details
    question = Column(Text, nullable=False)  # The fiqh question
    question_arabic = Column(Text)
    ruling = Column(Text, nullable=False)  # The actual ruling
    ruling_arabic = Column(Text)
    ruling_category = Column(Enum(RulingCategory), nullable=False)
    
    # Detailed explanation
    explanation = Column(Text)
    explanation_arabic = Column(Text)
    
    # Key conditions and requirements
    conditions = Column(ARRAY(Text), default=[])
    conditions_arabic = Column(ARRAY(Text), default=[])
    
    # Exceptions to the ruling
    exceptions = Column(ARRAY(Text), default=[])
    exceptions_arabic = Column(ARRAY(Text), default=[])
    
    # Evidence and proof
    evidence = Column(JSON, default={})  # Structured evidence
    
    # Reference to source texts
    primary_source = Column(String(500))  # e.g., "Al-Mudawwana al-Kubra"
    primary_source_arabic = Column(String(500))
    volume_page = Column(String(100))
    
    # Imam who issued/affirmed this ruling
    issuing_imam = Column(String(200))
    issuing_imam_arabic = Column(String(200))
    
    # Later scholars who commented
    commentaries = Column(JSON, default=[])
    
    # Related hadiths
    related_hadith_ids = Column(ARRAY(Integer), default=[])
    
    # Consensus and differences
    has_ijma = Column(Boolean, default=False)  # Is there consensus?
    ijma_details = Column(Text)
    
    # Comparison notes
    comparison_notes = Column(Text)
    comparison_notes_arabic = Column(Text)
    
    # Metadata
    created_at = Column(DateTime, server_default=func.now())
    updated_at = Column(DateTime, onupdate=func.now())
    verified_by = Column(String(200))
    verification_date = Column(DateTime)
    
    # Relationships
    evidences = relationship("RulingEvidence", back_populates="ruling")
    comparisons = relationship("RulingComparison", foreign_keys="RulingComparison.ruling_1_id", back_populates="ruling_1")


class RulingEvidence(Base):
    """Evidence supporting a fiqh ruling"""
    __tablename__ = "ruling_evidences"
    
    id = Column(Integer, primary_key=True, index=True)
    ruling_id = Column(Integer, ForeignKey("madhab_rulings.id"), nullable=False)
    ruling = relationship("MadhabRuling", back_populates="evidences")
    
    evidence_type = Column(Enum(EvidenceType), nullable=False)
    
    # Quran evidence
    surah_number = Column(Integer)
    ayah_start = Column(Integer)
    ayah_end = Column(Integer)
    ayah_text = Column(Text)
    ayah_text_arabic = Column(Text)
    
    # Hadith evidence
    hadith_id = Column(Integer, ForeignKey("hadiths.id"))
    hadith_text = Column(Text)
    hadith_authenticity = Column(String(50))
    
    # Scholarly evidence
    scholar_name = Column(String(200))
    scholar_name_arabic = Column(String(200))
    source_text = Column(Text)
    source_text_arabic = Column(Text)
    
    # Reasoning evidence
    reasoning = Column(Text)
    reasoning_arabic = Column(Text)
    
    # Priority of this evidence
    priority = Column(Integer, default=1)
    
    created_at = Column(DateTime, server_default=func.now())


class RulingComparison(Base):
    """Comparative analysis between rulings of different madhabs"""
    __tablename__ = "ruling_comparisons"
    
    id = Column(Integer, primary_key=True, index=True)
    
    # The two rulings being compared
    ruling_1_id = Column(Integer, ForeignKey("madhab_rulings.id"), nullable=False)
    ruling_2_id = Column(Integer, ForeignKey("madhab_rulings.id"), nullable=False)
    
    ruling_1 = relationship("MadhabRuling", foreign_keys=[ruling_1_id], back_populates="comparisons")
    ruling_2 = relationship("MadhabRuling", foreign_keys=[ruling_2_id])
    
    # Comparison analysis
    similarity_score = Column(Integer)  # 0-100
    agreement_level = Column(String(50))  # Full, Partial, Different
    
    # Points of agreement
    points_of_agreement = Column(ARRAY(Text), default=[])
    points_of_agreement_arabic = Column(ARRAY(Text), default=[])
    
    # Points of difference
    points_of_difference = Column(ARRAY(Text), default=[])
    points_of_difference_arabic = Column(ARRAY(Text), default=[])
    
    # Reasons for difference
    difference_reasons = Column(Text)
    difference_reasons_arabic = Column(Text)
    
    # Which evidence led to different conclusions
    evidence_analysis = Column(JSON, default={})
    
    # Historical context of the difference
    historical_context = Column(Text)
    historical_context_arabic = Column(Text)
    
    # Contemporary applicability
    contemporary_notes = Column(Text)
    contemporary_notes_arabic = Column(Text)
    
    # Scholarly opinions on reconciliation
    reconciliation_opinions = Column(JSON, default=[])
    
    created_at = Column(DateTime, server_default=func.now())
    updated_at = Column(DateTime, onupdate=func.now())


class MadhabScholar(Base):
    """Scholars of each madhab"""
    __tablename__ = "madhab_scholars"
    
    id = Column(Integer, primary_key=True, index=True)
    
    name = Column(String(200), nullable=False)
    name_arabic = Column(String(200))
    kunya = Column(String(200))
    nisba = Column(String(200))
    
    birth_year = Column(Integer)
    death_year = Column(Integer)
    
    madhab = Column(Enum(MadhabType), nullable=False)
    
    # Position in madhab
    is_founder = Column(Boolean, default=False)
    is_major_student = Column(Boolean, default=False)
    generation = Column(Integer)  # 1st, 2nd, 3rd generation etc.
    
    # Teachers within the madhab
    teachers_ids = Column(ARRAY(Integer), default=[])
    
    # Students within the madhab
    students_ids = Column(ARRAY(Integer), default=[])
    
    # Major works
    major_works = Column(ARRAY(String), default=[])
    major_works_arabic = Column(ARRAY(String), default=[])
    
    # Specialization
    specializations = Column(ARRAY(String), default=[])
    
    # Biography
    biography = Column(Text)
    biography_arabic = Column(Text)
    
    created_at = Column(DateTime, server_default=func.now())


class FiqhPrinciple(Base):
    """Usul al-Fiqh principles used by each madhab"""
    __tablename__ = "fiqh_principles"
    
    id = Column(Integer, primary_key=True, index=True)
    
    name = Column(String(200), nullable=False)
    name_arabic = Column(String(200))
    
    description = Column(Text)
    description_arabic = Column(Text)
    
    # Which madhabs use this principle
    used_by_madhabs = Column(ARRAY(Enum(MadhabType)), default=[])
    
    # How each madhab applies it
    hanafi_application = Column(Text)
    maliki_application = Column(Text)
    shafii_application = Column(Text)
    hanbali_application = Column(Text)
    
    # Examples
    examples = Column(JSON, default=[])
    
    created_at = Column(DateTime, server_default=func.now())


class MadhabBiography(Base):
    """Historical information about each madhab"""
    __tablename__ = "madhab_biographies"
    
    id = Column(Integer, primary_key=True, index=True)
    
    madhab = Column(Enum(MadhabType), nullable=False, unique=True)
    
    # Founder information
    founder_name = Column(String(200))
    founder_name_arabic = Column(String(200))
    founder_death_year = Column(Integer)
    
    # Origin
    origin_city = Column(String(100))
    origin_city_arabic = Column(String(100))
    
    # History
    history = Column(Text)
    history_arabic = Column(Text)
    
    # Spread
    spread_regions = Column(ARRAY(String), default=[])
    spread_regions_arabic = Column(ARRAY(String), default=[])
    
    # Current status
    current_followers_estimate = Column(String(100))
    primary_regions_today = Column(ARRAY(String), default=[])
    
    # Characteristics
    key_characteristics = Column(ARRAY(Text), default=[])
    key_characteristics_arabic = Column(ARRAY(Text), default=[])
    
    # Methodology
    methodology = Column(Text)
    methodology_arabic = Column(Text)
    
    # Major texts
    major_texts = Column(JSON, default=[])
    
    created_at = Column(DateTime, server_default=func.now())
