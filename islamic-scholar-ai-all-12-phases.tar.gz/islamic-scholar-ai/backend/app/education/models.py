"""
ISLAMIC SCHOLAR AI - EDUCATIONAL PLATFORM
Phase 10: Educational Platform
"""

from sqlalchemy import Column, Integer, String, Text, Boolean, DateTime, ForeignKey, JSON, ARRAY
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func

from app.db.database import Base


class Course(Base):
    """Educational courses"""
    __tablename__ = "courses"
    
    id = Column(Integer, primary_key=True, index=True)
    title = Column(String(300), nullable=False)
    title_arabic = Column(String(300))
    description = Column(Text)
    description_arabic = Column(Text)
    
    # Instructor
    instructor_id = Column(Integer, ForeignKey("verified_scholars.id"))
    
    # Course Details
    level = Column(String(50))  # beginner, intermediate, advanced
    category = Column(String(100))
    duration_hours = Column(Integer)
    
    # Content
    lessons = relationship("Lesson", back_populates="course")
    
    # Status
    is_published = Column(Boolean, default=False)
    is_free = Column(Boolean, default=True)
    
    # Engagement
    enrolled_count = Column(Integer, default=0)
    completion_count = Column(Integer, default=0)
    average_rating = Column(Integer, default=0)
    
    created_at = Column(DateTime, server_default=func.now())


class Lesson(Base):
    """Course lessons"""
    __tablename__ = "lessons"
    
    id = Column(Integer, primary_key=True, index=True)
    course_id = Column(Integer, ForeignKey("courses.id"), nullable=False)
    course = relationship("Course", back_populates="lessons")
    
    title = Column(String(300), nullable=False)
    content = Column(Text)
    video_url = Column(String(500))
    audio_url = Column(String(500))
    
    order_index = Column(Integer, default=0)
    duration_minutes = Column(Integer)
    
    created_at = Column(DateTime, server_default=func.now())


class Quiz(Base):
    """Quizzes for courses"""
    __tablename__ = "quizzes"
    
    id = Column(Integer, primary_key=True, index=True)
    lesson_id = Column(Integer, ForeignKey("lessons.id"))
    
    title = Column(String(200))
    questions = Column(JSON, default=[])
    
    passing_score = Column(Integer, default=70)
    
    created_at = Column(DateTime, server_default=func.now())


class UserProgress(Base):
    """Track user progress in courses"""
    __tablename__ = "user_progress"
    
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    course_id = Column(Integer, ForeignKey("courses.id"), nullable=False)
    
    completed_lessons = Column(ARRAY(Integer), default=[])
    quiz_scores = Column(JSON, default={})
    
    progress_percentage = Column(Integer, default=0)
    is_completed = Column(Boolean, default=False)
    
    started_at = Column(DateTime, server_default=func.now())
    completed_at = Column(DateTime)
    
    last_activity_at = Column(DateTime, onupdate=func.now())


class Certificate(Base):
    """Course completion certificates"""
    __tablename__ = "certificates"
    
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    course_id = Column(Integer, ForeignKey("courses.id"), nullable=False)
    
    certificate_number = Column(String(100), unique=True)
    issued_at = Column(DateTime, server_default=func.now())
    
    # Verification
    verification_url = Column(String(500))
