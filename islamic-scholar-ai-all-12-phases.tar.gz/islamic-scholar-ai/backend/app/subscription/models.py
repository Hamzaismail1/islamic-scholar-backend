"""
ISLAMIC SCHOLAR AI - SUBSCRIPTION & MONETIZATION
Phase 8: Monetization & Premium Features
"""

from sqlalchemy import Column, Integer, String, Float, Boolean, DateTime, ForeignKey, Enum, JSON, Text
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from enum import Enum as PyEnum

from app.db.database import Base


class SubscriptionTier(str, PyEnum):
    FREE = "free"
    BASIC = "basic"
    PREMIUM = "premium"
    SCHOLAR = "scholar"


class SubscriptionStatus(str, PyEnum):
    ACTIVE = "active"
    CANCELLED = "cancelled"
    EXPIRED = "expired"
    PENDING = "pending"


class PaymentStatus(str, PyEnum):
    PENDING = "pending"
    COMPLETED = "completed"
    FAILED = "failed"
    REFUNDED = "refunded"


class SubscriptionPlan(Base):
    """Available subscription plans"""
    __tablename__ = "subscription_plans"
    
    id = Column(Integer, primary_key=True, index=True)
    tier = Column(Enum(SubscriptionTier), nullable=False, unique=True)
    name = Column(String(100), nullable=False)
    description = Column(Text)
    
    # Pricing
    monthly_price = Column(Float, default=0.0)
    yearly_price = Column(Float, default=0.0)
    currency = Column(String(3), default="USD")
    
    # Features
    features = Column(JSON, default=[])
    limits = Column(JSON, default={})
    
    # Status
    is_active = Column(Boolean, default=True)
    
    created_at = Column(DateTime, server_default=func.now())


class UserSubscription(Base):
    """User subscriptions"""
    __tablename__ = "user_subscriptions"
    
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    plan_id = Column(Integer, ForeignKey("subscription_plans.id"), nullable=False)
    
    # Subscription Details
    status = Column(Enum(SubscriptionStatus), default=SubscriptionStatus.PENDING)
    
    # Billing
    billing_cycle = Column(String(20), default="monthly")  # monthly, yearly
    current_period_start = Column(DateTime)
    current_period_end = Column(DateTime)
    
    # Payment
    payment_method = Column(String(50))
    payment_provider = Column(String(50))  # stripe, paypal, etc.
    payment_provider_subscription_id = Column(String(200))
    
    # Usage tracking
    searches_used_this_period = Column(Integer, default=0)
    ai_queries_used_this_period = Column(Integer, default=0)
    
    # Cancellation
    cancelled_at = Column(DateTime)
    cancellation_reason = Column(Text)
    
    created_at = Column(DateTime, server_default=func.now())
    updated_at = Column(DateTime, onupdate=func.now())


class Payment(Base):
    """Payment records"""
    __tablename__ = "payments"
    
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    subscription_id = Column(Integer, ForeignKey("user_subscriptions.id"))
    
    # Payment Details
    amount = Column(Float, nullable=False)
    currency = Column(String(3), default="USD")
    status = Column(Enum(PaymentStatus), default=PaymentStatus.PENDING)
    
    # Provider
    provider = Column(String(50))
    provider_payment_id = Column(String(200))
    
    # Metadata
    description = Column(String(500))
    metadata = Column(JSON, default={})
    
    # Timestamps
    paid_at = Column(DateTime)
    created_at = Column(DateTime, server_default=func.now())


class UsageQuota(Base):
    """Track user usage quotas"""
    __tablename__ = "usage_quotas"
    
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False, unique=True)
    
    # Search Quotas
    searches_remaining = Column(Integer, default=10)
    searches_total = Column(Integer, default=10)
    searches_reset_at = Column(DateTime)
    
    # AI Query Quotas
    ai_queries_remaining = Column(Integer, default=5)
    ai_queries_total = Column(Integer, default=5)
    ai_queries_reset_at = Column(DateTime)
    
    # Advanced Features
    isnad_analysis_remaining = Column(Integer, default=0)
    madhab_comparison_remaining = Column(Integer, default=0)
    scholar_consultation_remaining = Column(Integer, default=0)
    
    updated_at = Column(DateTime, onupdate=func.now())
