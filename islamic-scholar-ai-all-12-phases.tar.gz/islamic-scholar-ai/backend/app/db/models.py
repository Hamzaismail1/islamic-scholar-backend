"""
Islamic Scholar AI - Database Models
"""
from sqlalchemy import Column, Integer, String, Text, Boolean, DateTime, ForeignKey, ARRAY, UUID
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from app.db.database import Base


class Hadith(Base):
    __tablename__ = "hadiths"
    
    id = Column(Integer, primary_key=True, index=True)
    collection = Column(String(50), nullable=False, index=True)
    book_number = Column(Integer)
    book_name_ar = Column(String(255))
    book_name_en = Column(String(255))
    chapter_number = Column(Integer)
    chapter_name_ar = Column(String(255))
    chapter_name_en = Column(String(255))
    hadith_number = Column(Integer, nullable=False)
    
    # Text
    arabic_text = Column(Text, nullable=False)
    arabic_text_normalized = Column(Text)
    english_text = Column(Text)
    english_narrator = Column(Text)
    urdu_text = Column(Text)
    indonesian_text = Column(Text)
    
    # Authentication
    overall_grade = Column(String(20), index=True)
    albani_grade = Column(String(50))
    
    # Metadata
    has_multiple_chains = Column(Boolean, default=False)
    chain_count = Column(Integer, default=1)
    theme = Column(String(100))
    keywords = Column(ARRAY(String))
    
    # Timestamps
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
    
    # Relationships
    chains = relationship("HadithChain", back_populates="hadith", cascade="all, delete-orphan")
    
    class Config:
        unique_together = [("collection", "hadith_number")]


class Narrator(Base):
    __tablename__ = "narrators"
    
    id = Column(Integer, primary_key=True, index=True)
    
    # Names
    name_arabic = Column(String(255), nullable=False, index=True)
    name_english = Column(String(255))
    full_name_arabic = Column(Text)
    full_name_english = Column(Text)
    kunyah = Column(String(100))
    laqab = Column(String(100))
    nisba = Column(String(100))
    
    # Life span
    birth_year_hijri = Column(Integer)
    birth_year_gregorian = Column(Integer)
    death_year_hijri = Column(Integer)
    death_year_gregorian = Column(Integer)
    age_at_death = Column(Integer)
    
    # Classification
    generation = Column(String(50), index=True)
    generation_number = Column(Integer)
    
    # Grades
    bukhari_grade = Column(String(100))
    muslim_grade = Column(String(100))
    ahmed_ibn_hanbal_grade = Column(String(100))
    yahya_ibn_main_grade = Column(String(100))
    ibn_hajar_grade = Column(String(100))
    dhahabi_grade = Column(String(100))
    consensus_grade = Column(String(50), index=True)
    
    # Statistics
    total_hadiths_narrated = Column(Integer, default=0)
    hadiths_in_bukhari = Column(Integer, default=0)
    hadiths_in_muslim = Column(Integer, default=0)
    
    # Biography
    biography_arabic = Column(Text)
    biography_english = Column(Text)
    
    # Personal info
    birthplace = Column(String(100))
    residence = Column(String(100))
    madhab = Column(String(50))
    
    # References
    reference_books = Column(ARRAY(String))
    
    # Timestamps
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())


class HadithChain(Base):
    __tablename__ = "hadith_chains"
    
    id = Column(Integer, primary_key=True, index=True)
    hadith_id = Column(Integer, ForeignKey("hadiths.id", ondelete="CASCADE"))
    
    # Chain details
    chain_sequence = Column(ARRAY(Integer), nullable=False)
    chain_arabic = Column(Text)
    chain_english = Column(Text)
    
    # Authentication
    chain_grade = Column(String(20), index=True)
    chain_grade_reason = Column(Text)
    
    # Weaknesses
    has_weak_narrator = Column(Boolean, default=False)
    weak_narrator_id = Column(Integer, ForeignKey("narrators.id"))
    weak_narrator_name = Column(String(255))
    weakness_type = Column(String(50))
    
    has_missing_link = Column(Boolean, default=False)
    missing_link_location = Column(Text)
    
    # Scholarly opinions
    bukhari_included = Column(Boolean)
    muslim_included = Column(Boolean)
    
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    
    # Relationships
    hadith = relationship("Hadith", back_populates="chains")


class ChainNarrator(Base):
    __tablename__ = "chain_narrators"
    
    id = Column(Integer, primary_key=True, index=True)
    chain_id = Column(Integer, ForeignKey("hadith_chains.id", ondelete="CASCADE"))
    narrator_id = Column(Integer, ForeignKey("narrators.id"))
    position_in_chain = Column(Integer, nullable=False)
    
    class Config:
        unique_together = [("chain_id", "position_in_chain")]


class NarratorRelationship(Base):
    __tablename__ = "narrator_relationships"
    
    id = Column(Integer, primary_key=True, index=True)
    teacher_id = Column(Integer, ForeignKey("narrators.id"))
    student_id = Column(Integer, ForeignKey("narrators.id"))
    relationship_type = Column(String(50))
    hadith_count = Column(Integer, default=0)
    explicit_mention = Column(Boolean)
    
    class Config:
        unique_together = [("teacher_id", "student_id")]


class User(Base):
    __tablename__ = "users"
    
    id = Column(UUID(as_uuid=True), primary_key=True, index=True)
    email = Column(String(255), unique=True, nullable=False, index=True)
    password_hash = Column(String(255))
    
    # Profile
    username = Column(String(100), unique=True)
    first_name = Column(String(100))
    last_name = Column(String(100))
    
    # Preferences
    preferred_madhab = Column(String(20))
    preferred_language = Column(String(10), default='en')
    
    # Subscription
    subscription_tier = Column(String(20), default='free', index=True)
    subscription_expires_at = Column(DateTime(timezone=True))
    
    # Usage
    questions_asked = Column(Integer, default=0)
    questions_remaining = Column(Integer, default=10)
    
    # Auth
    email_verified = Column(Boolean, default=False)
    is_active = Column(Boolean, default=True)
    
    # Timestamps
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
    last_login_at = Column(DateTime(timezone=True))
