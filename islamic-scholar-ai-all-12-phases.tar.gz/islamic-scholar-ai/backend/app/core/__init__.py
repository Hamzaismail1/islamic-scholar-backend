# Islamic Scholar AI - Core Configuration
