"""
Islamic Scholar AI - Narrator API Endpoints
"""
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func, or_
from typing import Optional, List

from app.db.database import get_db
from app.db.models import Narrator, Hadith, HadithChain, ChainNarrator
from app.schemas.narrator import (
    NarratorResponse, NarratorDetailResponse, NarratorListResponse
)
from app.core.config import settings

router = APIRouter()


@router.get("/", response_model=NarratorListResponse)
async def list_narrators(
    generation: Optional[str] = Query(None, description="Filter by generation (sahabi, tabi, etc.)"),
    grade: Optional[str] = Query(None, description="Filter by reliability grade"),
    madhab: Optional[str] = Query(None, description="Filter by madhab affiliation"),
    search: Optional[str] = Query(None, description="Search by name"),
    page: int = Query(1, ge=1),
    page_size: int = Query(settings.DEFAULT_PAGE_SIZE, ge=1, le=settings.MAX_PAGE_SIZE),
    db: AsyncSession = Depends(get_db)
):
    """
    List narrators with optional filtering and pagination.
    """
    # Build query
    query = select(Narrator)
    
    # Apply filters
    if generation:
        query = query.where(Narrator.generation == generation)
    if grade:
        query = query.where(Narrator.consensus_grade == grade)
    if madhab:
        query = query.where(Narrator.madhab == madhab)
    if search:
        search_filter = or_(
            Narrator.name_arabic.ilike(f"%{search}%"),
            Narrator.name_english.ilike(f"%{search}%"),
            Narrator.kunyah.ilike(f"%{search}%")
        )
        query = query.where(search_filter)
    
    # Order by hadith count (most prolific first)
    query = query.order_by(Narrator.total_hadiths_narrated.desc())
    
    # Get total count
    count_query = select(func.count()).select_from(query.subquery())
    total = await db.scalar(count_query)
    
    # Apply pagination
    offset = (page - 1) * page_size
    query = query.offset(offset).limit(page_size)
    
    # Execute query
    result = await db.execute(query)
    narrators = result.scalars().all()
    
    return NarratorListResponse(
        items=[NarratorResponse.model_validate(n) for n in narrators],
        total=total,
        page=page,
        page_size=page_size,
        pages=(total + page_size - 1) // page_size
    )


@router.get("/search")
async def search_narrators(
    q: str = Query(..., min_length=2, description="Search query"),
    limit: int = Query(20, ge=1, le=100),
    db: AsyncSession = Depends(get_db)
):
    """
    Search narrators by name (Arabic or English).
    """
    query = select(Narrator).where(
        or_(
            Narrator.name_arabic.ilike(f"%{q}%"),
            Narrator.name_english.ilike(f"%{q}%"),
            Narrator.kunyah.ilike(f"%{q}%"),
            Narrator.full_name_arabic.ilike(f"%{q}%"),
            Narrator.full_name_english.ilike(f"%{q}%")
        )
    ).limit(limit)
    
    result = await db.execute(query)
    narrators = result.scalars().all()
    
    return [NarratorResponse.model_validate(n) for n in narrators]


@router.get("/{narrator_id}", response_model=NarratorDetailResponse)
async def get_narrator(
    narrator_id: int,
    db: AsyncSession = Depends(get_db)
):
    """
    Get detailed information about a narrator.
    """
    result = await db.execute(
        select(Narrator).where(Narrator.id == narrator_id)
    )
    narrator = result.scalar_one_or_none()
    
    if not narrator:
        raise HTTPException(status_code=404, detail="Narrator not found")
    
    return NarratorDetailResponse.model_validate(narrator)


@router.get("/{narrator_id}/hadiths")
async def get_narrator_hadiths(
    narrator_id: int,
    collection: Optional[str] = Query(None),
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    db: AsyncSession = Depends(get_db)
):
    """
    Get all hadiths narrated by a specific narrator.
    """
    # First check if narrator exists
    narrator_result = await db.execute(
        select(Narrator).where(Narrator.id == narrator_id)
    )
    narrator = narrator_result.scalar_one_or_none()
    
    if not narrator:
        raise HTTPException(status_code=404, detail="Narrator not found")
    
    # Get hadiths where this narrator appears in chains
    from app.schemas.hadith import HadithResponse, HadithListResponse
    
    query = select(Hadith).join(
        HadithChain, Hadith.id == HadithChain.hadith_id
    ).where(
        HadithChain.chain_sequence.any(narrator_id)
    )
    
    if collection:
        query = query.where(Hadith.collection == collection)
    
    # Get total count
    count_query = select(func.count()).select_from(query.subquery())
    total = await db.scalar(count_query)
    
    # Apply pagination
    offset = (page - 1) * page_size
    query = query.offset(offset).limit(page_size)
    
    result = await db.execute(query)
    hadiths = result.scalars().all()
    
    return HadithListResponse(
        items=[HadithResponse.model_validate(h) for h in hadiths],
        total=total,
        page=page,
        page_size=page_size,
        pages=(total + page_size - 1) // page_size
    )


@router.get("/{narrator_id}/students")
async def get_narrator_students(
    narrator_id: int,
    db: AsyncSession = Depends(get_db)
):
    """
    Get students who narrated from this narrator.
    """
    from app.db.models import NarratorRelationship
    
    # Check if narrator exists
    narrator_result = await db.execute(
        select(Narrator).where(Narrator.id == narrator_id)
    )
    if not narrator_result.scalar_one_or_none():
        raise HTTPException(status_code=404, detail="Narrator not found")
    
    # Get students
    query = select(Narrator).join(
        NarratorRelationship, Narrator.id == NarratorRelationship.student_id
    ).where(NarratorRelationship.teacher_id == narrator_id)
    
    result = await db.execute(query)
    students = result.scalars().all()
    
    return [NarratorResponse.model_validate(s) for s in students]


@router.get("/{narrator_id}/teachers")
async def get_narrator_teachers(
    narrator_id: int,
    db: AsyncSession = Depends(get_db)
):
    """
    Get teachers from whom this narrator learned.
    """
    from app.db.models import NarratorRelationship
    
    # Check if narrator exists
    narrator_result = await db.execute(
        select(Narrator).where(Narrator.id == narrator_id)
    )
    if not narrator_result.scalar_one_or_none():
        raise HTTPException(status_code=404, detail="Narrator not found")
    
    # Get teachers
    query = select(Narrator).join(
        NarratorRelationship, Narrator.id == NarratorRelationship.teacher_id
    ).where(NarratorRelationship.student_id == narrator_id)
    
    result = await db.execute(query)
    teachers = result.scalars().all()
    
    return [NarratorResponse.model_validate(t) for t in teachers]


@router.get("/top/prolific")
async def get_top_prolific_narrators(
    limit: int = Query(20, ge=1, le=100),
    db: AsyncSession = Depends(get_db)
):
    """
    Get top narrators by number of hadiths narrated.
    """
    query = select(Narrator).order_by(
        Narrator.total_hadiths_narrated.desc()
    ).limit(limit)
    
    result = await db.execute(query)
    narrators = result.scalars().all()
    
    return [NarratorResponse.model_validate(n) for n in narrators]


@router.get("/grades/list")
async def get_grade_definitions():
    """
    Get definitions of narrator reliability grades.
    """
    return {
        "thiqah": {
            "name": "Thiqah",
            "arabic": "ثقة",
            "description": "Trustworthy - Highest level of reliability"
        },
        "thiqah_thiqah": {
            "name": "Thiqah Thiqah",
            "arabic": "ثقة ثقة",
            "description": "Extremely trustworthy - Highest possible grade"
        },
        "saduq": {
            "name": "Saduq",
            "arabic": "صدوق",
            "description": "Truthful - Generally reliable narrator"
        },
        "saduq_yuham": {
            "name": "Saduq Yuham",
            "arabic": "صدوق يهم",
            "description": "Truthful but sometimes makes mistakes"
        },
        "maqbul": {
            "name": "Maqbul",
            "arabic": "مقبول",
            "description": "Acceptable - Can be used as supporting evidence"
        },
        "dhaif": {
            "name": "Dhaif",
            "arabic": "ضعيف",
            "description": "Weak - Not reliable enough for primary evidence"
        },
        "matruk": {
            "name": "Matruk",
            "arabic": "متروك",
            "description": "Abandoned - Known for serious weaknesses"
        },
        "kadhhab": {
            "name": "Kadhhab",
            "arabic": "كذاب",
            "description": "Liar - Known to fabricate hadiths"
        }
    }
