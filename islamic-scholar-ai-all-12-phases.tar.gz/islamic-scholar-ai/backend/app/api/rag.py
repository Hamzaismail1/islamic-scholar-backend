"""
Islamic Scholar AI - RAG API Endpoints
Retrieval Augmented Generation with OpenAI and Pinecone
"""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
import openai
import os
from typing import List

from app.db.database import get_db
from app.db.models import Hadith, Narrator
from app.schemas.rag import (
    RAGQueryRequest, RAGResponse, RAGSource,
    SemanticSearchRequest, SemanticSearchResult,
    EmbeddingRequest, EmbeddingResponse
)

router = APIRouter()

# Initialize OpenAI client
openai_client = openai.OpenAI(api_key=os.getenv("OPENAI_API_KEY", ""))

# Pinecone will be initialized lazily
pinecone_index = None


def get_pinecone_index():
    """Get or initialize Pinecone index"""
    global pinecone_index
    if pinecone_index is None:
        try:
            import pinecone
            pinecone.init(
                api_key=os.getenv("PINECONE_API_KEY", ""),
                environment=os.getenv("PINECONE_ENVIRONMENT", "us-east-1")
            )
            index_name = os.getenv("PINECONE_INDEX_NAME", "islamic-knowledge")
            if index_name in pinecone.list_indexes():
                pinecone_index = pinecone.Index(index_name)
        except Exception as e:
            print(f"Pinecone initialization error: {e}")
    return pinecone_index


async def create_embedding(text: str) -> List[float]:
    """Create embedding using OpenAI"""
    try:
        response = openai_client.embeddings.create(
            model="text-embedding-3-large",
            input=text
        )
        return response.data[0].embedding
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Embedding creation failed: {str(e)}")


@router.post("/query", response_model=RAGResponse)
async def rag_query(
    request: RAGQueryRequest,
    db: AsyncSession = Depends(get_db)
):
    """
    Query the Islamic knowledge base using RAG.
    Returns AI-generated answer with cited sources.
    """
    try:
        # Step 1: Create embedding for the query
        query_embedding = await create_embedding(request.query)
        
        # Step 2: Search for relevant hadiths
        relevant_hadiths = await search_relevant_hadiths(
            query_embedding, 
            request.authenticity_filter,
            request.top_k or 10,
            db
        )
        
        # Step 3: Build context from retrieved hadiths
        context = build_context(relevant_hadiths)
        
        # Step 4: Generate answer using GPT-4
        answer, confidence = await generate_answer(
            request.query, 
            context,
            request.user_madhab
        )
        
        # Step 5: Check if scholar review is needed
        needs_review, review_reason = check_scholar_review_needed(
            request.query, 
            answer, 
            confidence,
            relevant_hadiths
        )
        
        # Build sources list
        sources = [
            RAGSource(
                type="hadith",
                id=h["hadith"].id,
                reference=f"{h['hadith'].collection} {h['hadith'].hadith_number}",
                text=h["hadith"].english_text or h["hadith"].arabic_text[:200],
                grade=h["hadith"].overall_grade,
                relevance_score=h["score"]
            )
            for h in relevant_hadiths
        ]
        
        return RAGResponse(
            query=request.query,
            answer=answer,
            confidence_score=confidence,
            sources=sources,
            requires_scholar_review=needs_review,
            review_reason=review_reason
        )
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"RAG query failed: {str(e)}")


async def search_relevant_hadiths(
    query_embedding: List[float],
    authenticity_filter: str,
    top_k: int,
    db: AsyncSession
) -> List[dict]:
    """Search for relevant hadiths using vector similarity"""
    
    # Try Pinecone first
    index = get_pinecone_index()
    
    if index:
        try:
            # Query Pinecone
            filter_dict = {}
            if authenticity_filter == "sahih_only":
                filter_dict["grade"] = {"$eq": "sahih"}
            elif authenticity_filter == "sahih_hasan":
                filter_dict["grade"] = {"$in": ["sahih", "hasan"]}
            
            results = index.query(
                vector=query_embedding,
                top_k=top_k,
                filter=filter_dict if filter_dict else None,
                include_metadata=True
            )
            
            # Fetch full hadith details from database
            hadith_ids = [int(match.id) for match in results.matches]
            result = await db.execute(
                select(Hadith).where(Hadith.id.in_(hadith_ids))
            )
            hadiths = {h.id: h for h in result.scalars().all()}
            
            return [
                {
                    "hadith": hadiths[int(match.id)],
                    "score": match.score
                }
                for match in results.matches
                if int(match.id) in hadiths
            ]
            
        except Exception as e:
            print(f"Pinecone search failed, falling back to database: {e}")
    
    # Fallback: Simple keyword search in database
    # This is a simplified fallback - in production you'd use pgvector
    result = await db.execute(
        select(Hadith).limit(top_k * 2)
    )
    hadiths = result.scalars().all()
    
    # Return with dummy scores
    return [
        {"hadith": h, "score": 0.5}
        for h in hadiths[:top_k]
    ]


def build_context(hadiths: List[dict]) -> str:
    """Build context string from retrieved hadiths"""
    context_parts = []
    
    for i, item in enumerate(hadiths, 1):
        hadith = item["hadith"]
        context_parts.append(
            f"Hadith {i} [{hadith.collection} {hadith.hadith_number}]:\n"
            f"Grade: {hadith.overall_grade or 'Unknown'}\n"
            f"Text: {hadith.english_text or hadith.arabic_text[:500]}\n"
        )
    
    return "\n\n".join(context_parts)


async def generate_answer(
    query: str, 
    context: str,
    user_madhab: str = None
) -> tuple[str, float]:
    """Generate answer using GPT-4"""
    
    madhab_instruction = ""
    if user_madhab:
        madhab_instruction = f"\nThe user follows the {user_madhab} madhab. Prioritize this madhab's perspective when relevant."
    
    prompt = f"""You are an Islamic scholar AI assistant. Answer the user's question using ONLY the provided hadiths. Always cite your sources.

User Question: {query}{madhab_instruction}

Available Hadiths:
{context}

RULES:
1. Answer in clear, simple language
2. ALWAYS cite sources using format: [Collection Number] (e.g., [Bukhari 1])
3. If sources conflict, present both views
4. If answer not found in sources, say "I need to consult a scholar"
5. Never make up references or fabricate hadiths
6. Include hadith grade when citing (Sahih, Hasan, etc.)

Provide your answer:"""
    
    try:
        response = openai_client.chat.completions.create(
            model="gpt-4",
            messages=[
                {"role": "system", "content": "You are an expert Islamic scholar AI assistant."},
                {"role": "user", "content": prompt}
            ],
            temperature=0.2,
            max_tokens=1000
        )
        
        answer = response.choices[0].message.content
        
        # Calculate confidence based on response characteristics
        confidence = calculate_confidence(answer, context)
        
        return answer, confidence
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Answer generation failed: {str(e)}")


def calculate_confidence(answer: str, context: str) -> float:
    """Calculate confidence score for the answer"""
    confidence = 0.5  # Base confidence
    
    # Increase if citations are present
    if "[" in answer and "]" in answer:
        confidence += 0.2
    
    # Increase if grades are mentioned
    if any(grade in answer.lower() for grade in ["sahih", "hasan", "authentic"]):
        confidence += 0.1
    
    # Decrease if uncertain language
    uncertain_words = ["maybe", "perhaps", "possibly", "might", "unclear"]
    if any(word in answer.lower() for word in uncertain_words):
        confidence -= 0.2
    
    # Decrease if no sources found
    if "need to consult" in answer.lower() or "not found" in answer.lower():
        confidence = 0.3
    
    return max(0.0, min(1.0, confidence))


def check_scholar_review_needed(
    query: str, 
    answer: str, 
    confidence: float,
    sources: List[dict]
) -> tuple[bool, str]:
    """Check if question needs scholar verification"""
    
    # Low confidence
    if confidence < 0.6:
        return True, "Low confidence in AI-generated answer"
    
    # Controversial topics
    controversial_keywords = [
        "divorce", "inheritance", "marriage contract", "polygamy",
        "riba", "bitcoin", "cryptocurrency", "stock trading",
        "new technology", "modern", "contemporary", "fatwa"
    ]
    
    query_lower = query.lower()
    if any(keyword in query_lower for keyword in controversial_keywords):
        return True, "Question involves controversial or complex fiqh topic"
    
    # Conflicting sources
    if "however" in answer.lower() or "differ" in answer.lower() or "conflict" in answer.lower():
        return True, "Sources present conflicting views"
    
    # Explicit fatwa request
    fatwa_keywords = ["fatwa", "ruling on", "is it permissible", "halal or haram", "allowed"]
    if any(keyword in query_lower for keyword in fatwa_keywords):
        return True, "Question asks for binding religious ruling"
    
    return False, None


@router.post("/embeddings/create", response_model=EmbeddingResponse)
async def create_hadith_embeddings(
    request: EmbeddingRequest,
    db: AsyncSession = Depends(get_db)
):
    """
    Create embeddings for hadiths and store in Pinecone.
    This is an admin endpoint for initial data loading.
    """
    index = get_pinecone_index()
    if not index:
        raise HTTPException(status_code=500, detail="Pinecone not configured")
    
    # Get hadiths to embed
    if request.hadith_ids:
        result = await db.execute(
            select(Hadith).where(Hadith.id.in_(request.hadith_ids))
        )
    else:
        result = await db.execute(select(Hadith))
    
    hadiths = result.scalars().all()
    
    processed = 0
    failed = 0
    errors = []
    
    batch_size = request.batch_size or 100
    
    for i in range(0, len(hadiths), batch_size):
        batch = hadiths[i:i + batch_size]
        
        for hadith in batch:
            try:
                # Create embedding from English text (or Arabic if no English)
                text_to_embed = hadith.english_text or hadith.arabic_text
                if not text_to_embed:
                    continue
                
                embedding = await create_embedding(text_to_embed[:8000])  # Limit text length
                
                # Upsert to Pinecone
                index.upsert([
                    {
                        "id": str(hadith.id),
                        "values": embedding,
                        "metadata": {
                            "collection": hadith.collection,
                            "hadith_number": hadith.hadith_number,
                            "grade": hadith.overall_grade or "unknown",
                            "theme": hadith.theme or "",
                            "keywords": hadith.keywords or []
                        }
                    }
                ])
                
                processed += 1
                
            except Exception as e:
                failed += 1
                errors.append(f"Hadith {hadith.id}: {str(e)}")
    
    return EmbeddingResponse(
        processed=processed,
        failed=failed,
        errors=errors[:10]  # Limit error messages
    )


@router.post("/semantic-search")
async def semantic_search(
    request: SemanticSearchRequest,
    db: AsyncSession = Depends(get_db)
):
    """
    Semantic search for hadiths using vector similarity.
    """
    # Create embedding for query
    query_embedding = await create_embedding(request.query)
    
    # Search
    results = await search_relevant_hadiths(
        query_embedding,
        request.grade_filter[0] if request.grade_filter else "all",
        request.top_k,
        db
    )
    
    return [
        SemanticSearchResult(
            hadith_id=item["hadith"].id,
            collection=item["hadith"].collection,
            hadith_number=item["hadith"].hadith_number,
            arabic_text=item["hadith"].arabic_text[:200],
            english_text=item["hadith"].english_text[:200] if item["hadith"].english_text else None,
            overall_grade=item["hadith"].overall_grade,
            similarity_score=item["score"]
        )
        for item in results
    ]
