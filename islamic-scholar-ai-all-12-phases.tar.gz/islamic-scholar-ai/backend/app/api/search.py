"""
Islamic Scholar AI - Search API Endpoints
Combined search across hadiths, narrators, and themes
"""
from fastapi import APIRouter, Depends, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, or_, func
from typing import Optional, List

from app.db.database import get_db
from app.db.models import Hadith, Narrator
from app.schemas.hadith import HadithResponse
from app.schemas.narrator import NarratorResponse

router = APIRouter()


@router.get("/")
async def global_search(
    q: str = Query(..., min_length=2, description="Search query"),
    type: Optional[str] = Query(None, description="Filter by type: hadith, narrator, all"),
    limit: int = Query(20, ge=1, le=100),
    db: AsyncSession = Depends(get_db)
):
    """
    Global search across hadiths and narrators.
    """
    results = {
        "query": q,
        "hadiths": [],
        "narrators": [],
        "total": 0
    }
    
    # Search hadiths
    if type in [None, "hadith", "all"]:
        hadith_query = select(Hadith).where(
            or_(
                Hadith.arabic_text.ilike(f"%{q}%"),
                Hadith.english_text.ilike(f"%{q}%"),
                Hadith.keywords.any(q),
                Hadith.theme.ilike(f"%{q}%")
            )
        ).limit(limit)
        
        hadith_result = await db.execute(hadith_query)
        hadiths = hadith_result.scalars().all()
        results["hadiths"] = [HadithResponse.model_validate(h) for h in hadiths]
    
    # Search narrators
    if type in [None, "narrator", "all"]:
        narrator_query = select(Narrator).where(
            or_(
                Narrator.name_arabic.ilike(f"%{q}%"),
                Narrator.name_english.ilike(f"%{q}%"),
                Narrator.kunyah.ilike(f"%{q}%"),
                Narrator.biography_english.ilike(f"%{q}%")
            )
        ).limit(limit)
        
        narrator_result = await db.execute(narrator_query)
        narrators = narrator_result.scalars().all()
        results["narrators"] = [NarratorResponse.model_validate(n) for n in narrators]
    
    results["total"] = len(results["hadiths"]) + len(results["narrators"])
    
    return results


@router.get("/themes")
async def search_by_theme(
    theme: str = Query(..., description="Theme to search for"),
    collection: Optional[str] = Query(None),
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    db: AsyncSession = Depends(get_db)
):
    """
    Search hadiths by theme/topic.
    """
    query = select(Hadith).where(
        or_(
            Hadith.theme.ilike(f"%{theme}%"),
            Hadith.keywords.any(theme)
        )
    )
    
    if collection:
        query = query.where(Hadith.collection == collection)
    
    # Get total count
    count_query = select(func.count()).select_from(query.subquery())
    total = await db.scalar(count_query)
    
    # Apply pagination
    offset = (page - 1) * page_size
    query = query.offset(offset).limit(page_size)
    
    result = await db.execute(query)
    hadiths = result.scalars().all()
    
    return {
        "theme": theme,
        "items": [HadithResponse.model_validate(h) for h in hadiths],
        "total": total,
        "page": page,
        "page_size": page_size,
        "pages": (total + page_size - 1) // page_size
    }


@router.get("/keywords")
async def get_popular_keywords(
    limit: int = Query(50, ge=1, le=200),
    db: AsyncSession = Depends(get_db)
):
    """
    Get most popular keywords from hadiths.
    """
    # This is a simplified implementation
    # In production, you'd aggregate keywords across all hadiths
    
    common_keywords = [
        "prayer", "fasting", "charity", "faith", "repentance",
        "patience", "gratitude", "knowledge", "parents", "marriage",
        "honesty", "backbiting", "intention", "paradise", "hellfire",
        "prophet", "quran", "sunnah", "innovation", "brotherhood"
    ]
    
    return {
        "keywords": common_keywords[:limit],
        "total": len(common_keywords)
    }


@router.get("/advanced")
async def advanced_search(
    query: str = Query(..., description="Search query"),
    collections: Optional[List[str]] = Query(None, description="Filter by collections"),
    grades: Optional[List[str]] = Query(None, description="Filter by grades"),
    themes: Optional[List[str]] = Query(None, description="Filter by themes"),
    narrator_id: Optional[int] = Query(None, description="Filter by narrator"),
    date_from: Optional[str] = Query(None, description="From date (Hijri)"),
    date_to: Optional[str] = Query(None, description="To date (Hijri)"),
    limit: int = Query(20, ge=1, le=100),
    db: AsyncSession = Depends(get_db)
):
    """
    Advanced search with multiple filters.
    """
    from sqlalchemy import and_
    
    # Build base query
    sql_query = select(Hadith).where(
        or_(
            Hadith.arabic_text.ilike(f"%{query}%"),
            Hadith.english_text.ilike(f"%{query}%")
        )
    )
    
    # Apply filters
    if collections:
        sql_query = sql_query.where(Hadith.collection.in_(collections))
    
    if grades:
        sql_query = sql_query.where(Hadith.overall_grade.in_(grades))
    
    if themes:
        theme_filter = or_(
            *[Hadith.theme.ilike(f"%{theme}%") for theme in themes],
            *[Hadith.keywords.any(theme) for theme in themes]
        )
        sql_query = sql_query.where(theme_filter)
    
    if narrator_id:
        from app.db.models import HadithChain
        sql_query = sql_query.join(HadithChain).where(
            HadithChain.chain_sequence.any(narrator_id)
        )
    
    # Limit results
    sql_query = sql_query.limit(limit)
    
    result = await db.execute(sql_query)
    hadiths = result.scalars().all()
    
    return {
        "query": query,
        "filters_applied": {
            "collections": collections,
            "grades": grades,
            "themes": themes,
            "narrator_id": narrator_id
        },
        "results": [HadithResponse.model_validate(h) for h in hadiths],
        "total": len(hadiths)
    }


@router.get("/suggestions")
async def get_search_suggestions(
    q: str = Query(..., min_length=1, description="Partial query"),
    limit: int = Query(10, ge=1, le=20),
    db: AsyncSession = Depends(get_db)
):
    """
    Get search suggestions based on partial input.
    """
    suggestions = []
    
    # Suggest hadiths
    hadith_query = select(Hadith).where(
        or_(
            Hadith.english_text.ilike(f"%{q}%"),
            Hadith.theme.ilike(f"%{q}%")
        )
    ).limit(limit // 2)
    
    hadith_result = await db.execute(hadith_query)
    hadiths = hadith_result.scalars().all()
    
    for h in hadiths:
        if h.theme:
            suggestions.append({
                "type": "theme",
                "value": h.theme,
                "display": f"Theme: {h.theme}"
            })
    
    # Suggest narrators
    narrator_query = select(Narrator).where(
        or_(
            Narrator.name_english.ilike(f"%{q}%"),
            Narrator.name_arabic.ilike(f"%{q}%")
        )
    ).limit(limit // 2)
    
    narrator_result = await db.execute(narrator_query)
    narrators = narrator_result.scalars().all()
    
    for n in narrators:
        suggestions.append({
            "type": "narrator",
            "value": n.name_english or n.name_arabic,
            "display": f"Narrator: {n.name_english or n.name_arabic}"
        })
    
    # Remove duplicates
    seen = set()
    unique_suggestions = []
    for s in suggestions:
        if s["value"] not in seen:
            seen.add(s["value"])
            unique_suggestions.append(s)
    
    return {
        "query": q,
        "suggestions": unique_suggestions[:limit]
    }
