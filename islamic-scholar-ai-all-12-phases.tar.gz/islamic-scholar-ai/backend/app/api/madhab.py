"""
ISLAMIC SCHOLAR AI - 4 MADHAB COMPARISON API
REST API Endpoints for Fiqh Comparison
Phase 5: 4 Madhab Comparison Engine
"""

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from sqlalchemy import func
from typing import List, Optional
from pydantic import BaseModel
from enum import Enum

from app.db.database import get_db
from app.madhab.models import (
    MadhabRuling, RulingComparison, MadhabScholar, 
    FiqhTopic, FiqhPrinciple, MadhabBiography,
    MadhabType, RulingCategory, EvidenceType
)

router = APIRouter(prefix="/api/v1/madhab", tags=["4 Madhab Comparison"])


# ============== Pydantic Schemas ==============

class MadhabTypeEnum(str, Enum):
    hanafi = "hanafi"
    maliki = "maliki"
    shafii = "shafii"
    hanbali = "hanbali"


class RulingCategoryEnum(str, Enum):
    wajib = "wajib"
    mandub = "mandub"
    mubah = "mubah"
    makruh = "makruh"
    haram = "haram"


class RulingResponse(BaseModel):
    id: int
    madhab: str
    question: str
    question_arabic: Optional[str]
    ruling: str
    ruling_arabic: Optional[str]
    ruling_category: str
    explanation: Optional[str]
    conditions: List[str]
    exceptions: List[str]
    primary_source: Optional[str]
    issuing_imam: Optional[str]
    has_ijma: bool
    
    class Config:
        from_attributes = True


class ComparisonResponse(BaseModel):
    id: int
    topic: str
    rulings: List[RulingResponse]
    similarity_score: Optional[int]
    agreement_level: Optional[str]
    points_of_agreement: List[str]
    points_of_difference: List[str]
    difference_reasons: Optional[str]
    
    class Config:
        from_attributes = True


class ScholarResponse(BaseModel):
    id: int
    name: str
    name_arabic: Optional[str]
    madhab: str
    is_founder: bool
    death_year: Optional[int]
    major_works: List[str]
    specializations: List[str]
    
    class Config:
        from_attributes = True


class TopicResponse(BaseModel):
    id: int
    name: str
    name_arabic: Optional[str]
    description: Optional[str]
    subtopics: List[dict]
    
    class Config:
        from_attributes = True


class PrincipleResponse(BaseModel):
    id: int
    name: str
    name_arabic: Optional[str]
    description: Optional[str]
    used_by_madhabs: List[str]
    
    class Config:
        from_attributes = True


class MadhabInfoResponse(BaseModel):
    madhab: str
    founder_name: Optional[str]
    origin_city: Optional[str]
    history: Optional[str]
    key_characteristics: List[str]
    methodology: Optional[str]
    major_texts: List[dict]
    
    class Config:
        from_attributes = True


# ============== API Endpoints ==============

@router.get("/rulings", response_model=List[RulingResponse])
async def get_rulings(
    topic_id: Optional[int] = None,
    madhab: Optional[MadhabTypeEnum] = None,
    category: Optional[RulingCategoryEnum] = None,
    search: Optional[str] = None,
    has_ijma: Optional[bool] = None,
    limit: int = Query(20, ge=1, le=100),
    offset: int = Query(0, ge=0),
    db: Session = Depends(get_db)
):
    """
    Get fiqh rulings with optional filtering.
    
    - **topic_id**: Filter by fiqh topic
    - **madhab**: Filter by madhab (hanafi, maliki, shafii, hanbali)
    - **category**: Filter by ruling category (wajib, mandub, mubah, makruh, haram)
    - **search**: Search in question and ruling text
    - **has_ijma**: Filter by consensus status
    """
    query = db.query(MadhabRuling)
    
    if topic_id:
        query = query.filter(MadhabRuling.topic_id == topic_id)
    
    if madhab:
        query = query.filter(MadhabRuling.madhab == madhab.value)
    
    if category:
        query = query.filter(MadhabRuling.ruling_category == category.value)
    
    if has_ijma is not None:
        query = query.filter(MadhabRuling.has_ijma == has_ijma)
    
    if search:
        search_filter = f"%{search}%"
        query = query.filter(
            (MadhabRuling.question.ilike(search_filter)) |
            (MadhabRuling.ruling.ilike(search_filter)) |
            (MadhabRuling.explanation.ilike(search_filter))
        )
    
    total = query.count()
    rulings = query.offset(offset).limit(limit).all()
    
    return rulings


@router.get("/rulings/{ruling_id}", response_model=RulingResponse)
async def get_ruling_detail(
    ruling_id: int,
    db: Session = Depends(get_db)
):
    """Get detailed information about a specific ruling."""
    ruling = db.query(MadhabRuling).filter(MadhabRuling.id == ruling_id).first()
    
    if not ruling:
        raise HTTPException(status_code=404, detail="Ruling not found")
    
    return ruling


@router.get("/compare", response_model=ComparisonResponse)
async def compare_rulings(
    topic_id: int,
    madhabs: List[MadhabTypeEnum] = Query(..., description="List of madhabs to compare"),
    db: Session = Depends(get_db)
):
    """
    Compare rulings from different madhabs on the same topic.
    
    - **topic_id**: The fiqh topic to compare
    - **madhabs**: List of madhabs to include in comparison (2-4 madhabs)
    """
    if len(madhabs) < 2:
        raise HTTPException(status_code=400, detail="At least 2 madhabs required for comparison")
    
    if len(madhabs) > 4:
        raise HTTPException(status_code=400, detail="Maximum 4 madhabs allowed")
    
    madhab_values = [m.value for m in madhabs]
    
    # Get rulings for this topic from specified madhabs
    rulings = db.query(MadhabRuling).filter(
        MadhabRuling.topic_id == topic_id,
        MadhabRuling.madhab.in_(madhab_values)
    ).all()
    
    if len(rulings) < 2:
        raise HTTPException(
            status_code=404, 
            detail="Insufficient rulings found for comparison"
        )
    
    # Get topic name
    topic = db.query(FiqhTopic).filter(FiqhTopic.id == topic_id).first()
    
    # Try to find existing comparison
    ruling_ids = [r.id for r in rulings]
    comparison = db.query(RulingComparison).filter(
        (RulingComparison.ruling_1_id.in_(ruling_ids)) &
        (RulingComparison.ruling_2_id.in_(ruling_ids))
    ).first()
    
    return {
        "id": comparison.id if comparison else 0,
        "topic": topic.name if topic else "Unknown",
        "rulings": rulings,
        "similarity_score": comparison.similarity_score if comparison else None,
        "agreement_level": comparison.agreement_level if comparison else None,
        "points_of_agreement": comparison.points_of_agreement if comparison else [],
        "points_of_difference": comparison.points_of_difference if comparison else [],
        "difference_reasons": comparison.difference_reasons if comparison else None
    }


@router.get("/topics", response_model=List[TopicResponse])
async def get_topics(
    parent_id: Optional[int] = None,
    search: Optional[str] = None,
    db: Session = Depends(get_db)
):
    """Get fiqh topics/categories."""
    query = db.query(FiqhTopic)
    
    if parent_id:
        query = query.filter(FiqhTopic.parent_id == parent_id)
    else:
        query = query.filter(FiqhTopic.parent_id.is_(None))
    
    if search:
        query = query.filter(FiqhTopic.name.ilike(f"%{search}%"))
    
    topics = query.all()
    return topics


@router.get("/topics/{topic_id}/rulings")
async def get_topic_rulings(
    topic_id: int,
    madhab: Optional[MadhabTypeEnum] = None,
    db: Session = Depends(get_db)
):
    """Get all rulings for a specific topic, optionally filtered by madhab."""
    query = db.query(MadhabRuling).filter(MadhabRuling.topic_id == topic_id)
    
    if madhab:
        query = query.filter(MadhabRuling.madhab == madhab.value)
    
    rulings = query.all()
    
    # Group by madhab
    grouped = {}
    for ruling in rulings:
        madhab_name = ruling.madhab.value
        if madhab_name not in grouped:
            grouped[madhab_name] = []
        grouped[madhab_name].append(ruling)
    
    return {
        "topic_id": topic_id,
        "rulings_by_madhab": grouped
    }


@router.get("/scholars", response_model=List[ScholarResponse])
async def get_scholars(
    madhab: Optional[MadhabTypeEnum] = None,
    is_founder: Optional[bool] = None,
    generation: Optional[int] = None,
    search: Optional[str] = None,
    db: Session = Depends(get_db)
):
    """Get scholars from the 4 madhabs."""
    query = db.query(MadhabScholar)
    
    if madhab:
        query = query.filter(MadhabScholar.madhab == madhab.value)
    
    if is_founder is not None:
        query = query.filter(MadhabScholar.is_founder == is_founder)
    
    if generation:
        query = query.filter(MadhabScholar.generation == generation)
    
    if search:
        query = query.filter(MadhabScholar.name.ilike(f"%{search}%"))
    
    scholars = query.order_by(MadhabScholar.death_year).all()
    return scholars


@router.get("/scholars/{scholar_id}", response_model=ScholarResponse)
async def get_scholar_detail(
    scholar_id: int,
    db: Session = Depends(get_db)
):
    """Get detailed information about a specific scholar."""
    scholar = db.query(MadhabScholar).filter(MadhabScholar.id == scholar_id).first()
    
    if not scholar:
        raise HTTPException(status_code=404, detail="Scholar not found")
    
    return scholar


@router.get("/principles", response_model=List[PrincipleResponse])
async def get_principles(
    madhab: Optional[MadhabTypeEnum] = None,
    db: Session = Depends(get_db)
):
    """Get Usul al-Fiqh principles."""
    query = db.query(FiqhPrinciple)
    
    if madhab:
        # Filter principles used by this madhab
        query = query.filter(FiqhPrinciple.used_by_madhabs.contains([madhab.value]))
    
    principles = query.all()
    return principles


@router.get("/principles/{principle_id}")
async def get_principle_detail(
    principle_id: int,
    db: Session = Depends(get_db)
):
    """Get detailed information about a specific principle."""
    principle = db.query(FiqhPrinciple).filter(FiqhPrinciple.id == principle_id).first()
    
    if not principle:
        raise HTTPException(status_code=404, detail="Principle not found")
    
    return principle


@router.get("/info/{madhab}", response_model=MadhabInfoResponse)
async def get_madhab_info(
    madhab: MadhabTypeEnum,
    db: Session = Depends(get_db)
):
    """Get comprehensive information about a madhab."""
    info = db.query(MadhabBiography).filter(
        MadhabBiography.madhab == madhab.value
    ).first()
    
    if not info:
        raise HTTPException(status_code=404, detail="Madhab information not found")
    
    return info


@router.get("/statistics")
async def get_madhab_statistics(db: Session = Depends(get_db)):
    """Get statistics about the 4 madhabs in the database."""
    stats = {}
    
    for madhab in MadhabType:
        ruling_count = db.query(MadhabRuling).filter(
            MadhabRuling.madhab == madhab.value
        ).count()
        
        scholar_count = db.query(MadhabScholar).filter(
            MadhabScholar.madhab == madhab.value
        ).count()
        
        ijma_count = db.query(MadhabRuling).filter(
            MadhabRuling.madhab == madhab.value,
            MadhabRuling.has_ijma == True
        ).count()
        
        stats[madhab.value] = {
            "rulings": ruling_count,
            "scholars": scholar_count,
            "consensus_rulings": ijma_count
        }
    
    return stats


@router.get("/search")
async def search_madhab(
    query: str,
    search_in: List[str] = Query(default=["rulings", "scholars", "topics"]),
    db: Session = Depends(get_db)
):
    """
    Search across madhab content.
    
    - **query**: Search term
    - **search_in**: What to search in (rulings, scholars, topics, principles)
    """
    results = {
        "query": query,
        "rulings": [],
        "scholars": [],
        "topics": [],
        "principles": []
    }
    
    search_filter = f"%{query}%"
    
    if "rulings" in search_in:
        rulings = db.query(MadhabRuling).filter(
            (MadhabRuling.question.ilike(search_filter)) |
            (MadhabRuling.ruling.ilike(search_filter)) |
            (MadhabRuling.explanation.ilike(search_filter))
        ).limit(20).all()
        results["rulings"] = rulings
    
    if "scholars" in search_in:
        scholars = db.query(MadhabScholar).filter(
            MadhabScholar.name.ilike(search_filter)
        ).limit(20).all()
        results["scholars"] = scholars
    
    if "topics" in search_in:
        topics = db.query(FiqhTopic).filter(
            FiqhTopic.name.ilike(search_filter)
        ).limit(20).all()
        results["topics"] = topics
    
    if "principles" in search_in:
        principles = db.query(FiqhPrinciple).filter(
            FiqhPrinciple.name.ilike(search_filter)
        ).limit(20).all()
        results["principles"] = principles
    
    return results


@router.get("/consensus")
async def get_consensus_rulings(
    topic_id: Optional[int] = None,
    db: Session = Depends(get_db)
):
    """Get rulings where all 4 madhabs agree (Ijma)."""
    query = db.query(MadhabRuling).filter(MadhabRuling.has_ijma == True)
    
    if topic_id:
        query = query.filter(MadhabRuling.topic_id == topic_id)
    
    rulings = query.all()
    return rulings


@router.get("/differences")
async def get_differences(
    topic_id: Optional[int] = None,
    db: Session = Depends(get_db)
):
    """Get topics where madhabs have different rulings."""
    # Find topics with multiple different rulings
    query = db.query(
        MadhabRuling.topic_id,
        func.count(MadhabRuling.id).label('ruling_count'),
        func.count(func.distinct(MadhabRuling.ruling_category)).label('category_count')
    ).group_by(MadhabRuling.topic_id)
    
    if topic_id:
        query = query.filter(MadhabRuling.topic_id == topic_id)
    
    # Filter for topics with different rulings
    results = query.having(func.count(MadhabRuling.id) >= 2).all()
    
    differences = []
    for result in results:
        topic = db.query(FiqhTopic).filter(FiqhTopic.id == result.topic_id).first()
        rulings = db.query(MadhabRuling).filter(
            MadhabRuling.topic_id == result.topic_id
        ).all()
        
        differences.append({
            "topic_id": result.topic_id,
            "topic_name": topic.name if topic else "Unknown",
            "ruling_count": result.ruling_count,
            "category_count": result.category_count,
            "rulings": rulings
        })
    
    return differences
