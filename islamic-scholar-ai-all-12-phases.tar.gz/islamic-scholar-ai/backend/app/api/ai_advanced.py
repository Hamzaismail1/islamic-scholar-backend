"""
ISLAMIC SCHOLAR AI - ADVANCED AI API ENDPOINTS
Phase 6: Advanced AI Features
"""

from fastapi import APIRouter, Depends, HTTPException, Query, BackgroundTasks
from sqlalchemy.orm import Session
from typing import List, Optional, Dict, Any
from pydantic import BaseModel, Field
import asyncio

from app.db.database import get_db
from app.ai.advanced_rag import advanced_rag, AIResponse, SearchResult

router = APIRouter(prefix="/api/v1/ai", tags=["Advanced AI"])


# ============== Pydantic Schemas ==============

class QuestionRequest(BaseModel):
    question: str = Field(..., description="The Islamic question to answer")
    question_arabic: Optional[str] = Field(None, description="Arabic version of the question")
    search_depth: str = Field("standard", description="Search depth: quick, standard, comprehensive")
    include_arabic: bool = Field(True, description="Include Arabic text in response")
    include_reasoning: bool = Field(True, description="Include chain-of-thought reasoning")
    madhab_focus: Optional[str] = Field(None, description="Focus on specific madhab: hanafi, maliki, shafii, hanbali")
    topic_filter: Optional[str] = Field(None, description="Filter by topic: fiqh, aqeedah, seerah, etc.")


class VerifyHadithRequest(BaseModel):
    hadith_text: str = Field(..., description="The hadith text to verify")
    claimed_source: Optional[str] = Field(None, description="Claimed source if known")


class CompareMadhabsRequest(BaseModel):
    topic: str = Field(..., description="Fiqh topic to compare")
    specific_question: Optional[str] = Field(None, description="Specific question within topic")


class AIResponseSchema(BaseModel):
    answer: str
    answer_arabic: Optional[str]
    confidence: float
    confidence_level: str
    sources: List[Dict[str, Any]]
    reasoning_chain: List[str]
    related_questions: List[str]
    scholarly_disclaimer: str
    processing_time_ms: int
    
    class Config:
        from_attributes = True


class VerificationResponse(BaseModel):
    found: bool
    exact_match: Optional[bool]
    authenticity_grade: Optional[str]
    source: Optional[str]
    narrator_chain: Optional[str]
    full_text: Optional[str]
    scholarly_grading: List[Dict[str, Any]]
    message: Optional[str]
    recommendation: Optional[str]


class ComparisonResponse(BaseModel):
    topic: str
    question: Optional[str]
    comparison: str
    sources_by_madhab: Dict[str, List[Dict[str, Any]]]


class SearchRequest(BaseModel):
    query: str
    query_arabic: Optional[str] = None
    search_types: List[str] = Field(default=["semantic", "keyword"])
    filters: Optional[Dict[str, Any]] = None
    top_k: int = Field(10, ge=1, le=50)


# ============== API Endpoints ==============

@router.post("/ask", response_model=AIResponseSchema)
async def ask_question(
    request: QuestionRequest,
    background_tasks: BackgroundTasks,
    db: Session = Depends(get_db)
):
    """
    Ask an Islamic question and get an AI-generated answer with sources.
    
    This endpoint uses advanced RAG (Retrieval-Augmented Generation) to:
    1. Search across Quran, Hadith, and Fiqh databases
    2. Verify authenticity of sources
    3. Present scholarly views from all 4 madhabs
    4. Provide confidence scoring
    
    **Example Questions:**
    - "What are the conditions for valid wudu?"
    - "Is touching private parts breaking wudu?"
    - "What did the Prophet say about intentions?"
    """
    try:
        # Adjust search parameters based on depth
        top_k = {
            "quick": 5,
            "standard": 10,
            "comprehensive": 20
        }.get(request.search_depth, 10)
        
        # Build filters
        filters = {}
        if request.madhab_focus:
            filters["madhab"] = request.madhab_focus
        if request.topic_filter:
            filters["topic"] = request.topic_filter
        
        # Search for relevant sources
        search_results = await advanced_rag.search_multi_modal(
            query=request.question,
            query_arabic=request.question_arabic,
            search_types=["semantic", "keyword", "metadata"],
            filters=filters if filters else None,
            top_k=top_k
        )
        
        # Generate answer
        response = await advanced_rag.generate_answer(
            query=request.question,
            query_arabic=request.question_arabic,
            search_results=search_results,
            include_reasoning=request.include_reasoning
        )
        
        # Determine confidence level
        confidence_level = "HIGH" if response.confidence >= 0.9 else \
                          "MEDIUM" if response.confidence >= 0.7 else "LOW"
        
        # Format sources
        formatted_sources = [
            {
                "content": s.content[:300] + "..." if len(s.content) > 300 else s.content,
                "content_arabic": s.content_arabic[:200] + "..." if s.content_arabic and len(s.content_arabic) > 200 else s.content_arabic,
                "source": s.source,
                "source_type": s.source_type,
                "authenticity_grade": s.chain_authenticity,
                "relevance_score": round(s.relevance_score, 3)
            }
            for s in response.sources
        ]
        
        return {
            "answer": response.answer,
            "answer_arabic": response.answer_arabic,
            "confidence": round(response.confidence, 2),
            "confidence_level": confidence_level,
            "sources": formatted_sources,
            "reasoning_chain": response.reasoning_chain,
            "related_questions": response.related_questions,
            "scholarly_disclaimer": response.scholarly_disclaimer,
            "processing_time_ms": response.processing_time_ms
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"AI processing error: {str(e)}")


@router.post("/verify-hadith", response_model=VerificationResponse)
async def verify_hadith(
    request: VerifyHadithRequest,
    db: Session = Depends(get_db)
):
    """
    Verify the authenticity of a hadith.
    
    This endpoint checks if a hadith exists in major collections
    and returns its authenticity grade, source, and narrator chain.
    
    **Use Cases:**
    - Verify hadiths shared on social media
    - Check authenticity before using in sermons
    - Research hadith gradings
    """
    try:
        result = await advanced_rag.verify_authenticity(
            hadith_text=request.hadith_text,
            claimed_source=request.claimed_source
        )
        return result
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Verification error: {str(e)}")


@router.post("/compare-madhabs", response_model=ComparisonResponse)
async def compare_madhabs(
    request: CompareMadhabsRequest,
    db: Session = Depends(get_db)
):
    """
    Compare fiqh rulings across the 4 major madhabs.
    
    This endpoint provides:
    - Each madhab's view on the topic
    - Evidence used by each school
    - Points of agreement and difference
    - Reasons for scholarly differences
    
    **Example Topics:**
    - "Wudu: Does touching private parts break it?"
    - "Prayer: Where to place hands in qiyam?"
    - "Fasting: Does ear drop invalidate fast?"
    """
    try:
        result = await advanced_rag.compare_madhabs(
            topic=request.topic,
            specific_question=request.specific_question
        )
        
        # Format sources
        formatted_sources = {}
        for madhab, sources in result["sources_by_madhab"].items():
            formatted_sources[madhab] = [
                {
                    "content": s.content[:300] + "..." if len(s.content) > 300 else s.content,
                    "source": s.source,
                    "authenticity_grade": s.chain_authenticity
                }
                for s in sources[:3]
            ]
        
        return {
            "topic": result["topic"],
            "question": result["question"],
            "comparison": result["comparison"],
            "sources_by_madhab": formatted_sources
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Comparison error: {str(e)}")


@router.post("/search")
async def advanced_search(
    request: SearchRequest,
    db: Session = Depends(get_db)
):
    """
    Advanced search across all Islamic knowledge bases.
    
    Supports multiple search modes:
    - **semantic**: Vector similarity search (best for conceptual queries)
    - **keyword**: Full-text search (best for specific terms)
    - **metadata**: Search by narrator, book, topic (best for filtered searches)
    """
    try:
        results = await advanced_rag.search_multi_modal(
            query=request.query,
            query_arabic=request.query_arabic,
            search_types=request.search_types,
            filters=request.filters,
            top_k=request.top_k
        )
        
        return {
            "query": request.query,
            "results_count": len(results),
            "results": [
                {
                    "content": r.content[:500],
                    "content_arabic": r.content_arabic[:300] if r.content_arabic else None,
                    "source": r.source,
                    "source_type": r.source_type,
                    "authenticity_grade": r.chain_authenticity,
                    "relevance_score": round(r.relevance_score, 3),
                    "metadata": {
                        k: v for k, v in r.metadata.items() 
                        if k not in ['text_english', 'text_arabic', 'embedding']
                    }
                }
                for r in results
            ]
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Search error: {str(e)}")


@router.get("/suggest-questions")
async def suggest_questions(
    topic: Optional[str] = Query(None, description="Topic area"),
    db: Session = Depends(get_db)
):
    """Get suggested questions based on popular queries."""
    
    suggestions = {
        "purification": [
            "What breaks wudu?",
            "How to perform ghusl?",
            "Is wudu required for touching Quran?",
            "What is tayammum and when is it used?"
        ],
        "prayer": [
            "What are the times for each prayer?",
            "How many rakahs in each prayer?",
            "What invalidates prayer?",
            "Can I pray sitting down?"
        ],
        "fasting": [
            "What breaks the fast in Ramadan?",
            "Can I use eye drops while fasting?",
            "What is kaffarah for breaking fast?",
            "Who is exempt from fasting?"
        ],
        "zakat": [
            "Who must pay zakat?",
            "What is the nisab for zakat?",
            "Who can receive zakat?",
            "When is zakat due?"
        ],
        "general": [
            "What is the importance of intentions?",
            "How to seek forgiveness?",
            "What are the major sins?",
            "How to increase faith?"
        ]
    }
    
    if topic and topic in suggestions:
        return {"topic": topic, "suggestions": suggestions[topic]}
    
    # Return all suggestions
    all_suggestions = []
    for t, qs in suggestions.items():
        all_suggestions.extend([{"topic": t, "question": q} for q in qs])
    
    return {"suggestions": all_suggestions[:20]}


@router.get("/confidence-levels")
async def get_confidence_levels():
    """Get explanation of confidence levels used by the AI."""
    return {
        "confidence_levels": {
            "HIGH": {
                "score_range": "0.90 - 1.00",
                "description": "Clear evidence from Quran, Mutawatir Sunnah, or scholarly consensus (Ijma)",
                "reliability": "Very High - Can be acted upon with confidence"
            },
            "MEDIUM": {
                "score_range": "0.70 - 0.89",
                "description": "Strong evidence from authentic Ahad hadith with majority scholarly view",
                "reliability": "High - Can be acted upon, minor differences exist"
            },
            "LOW": {
                "score_range": "0.50 - 0.69",
                "description": "Weak evidence, significant scholarly difference, or limited sources",
                "reliability": "Moderate - Consult scholars for important matters"
            },
            "UNCERTAIN": {
                "score_range": "0.00 - 0.49",
                "description": "Insufficient evidence or conflicting sources",
                "reliability": "Low - Requires consultation with qualified scholars"
            }
        }
    }
