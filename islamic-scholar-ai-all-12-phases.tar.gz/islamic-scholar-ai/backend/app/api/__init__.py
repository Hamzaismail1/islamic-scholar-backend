# Islamic Scholar AI - API Routes
