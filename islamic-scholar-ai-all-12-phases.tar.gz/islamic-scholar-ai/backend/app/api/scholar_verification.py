"""
ISLAMIC SCHOLAR AI - SCHOLAR VERIFICATION API
Phase 7: Scholar Verification System
"""

from fastapi import APIRouter, Depends, HTTPException, Query, File, UploadFile
from sqlalchemy.orm import Session
from sqlalchemy import func
from typing import List, Optional
from pydantic import BaseModel, Field
from datetime import datetime

from app.db.database import get_db
from app.scholar_verification.models import (
    ScholarApplication, VerifiedScholar, ScholarContribution,
    ScholarReview, VerificationStatus, ScholarRank, InstitutionType
)

router = APIRouter(prefix="/api/v1/scholars", tags=["Scholar Verification"])


# ============== Pydantic Schemas ==============

class ScholarApplicationRequest(BaseModel):
    full_name: str = Field(..., min_length=3, max_length=200)
    email: str = Field(..., pattern=r'^[\w\.-]+@[\w\.-]+\.\w+$')
    phone: Optional[str] = None
    institution_name: str
    institution_type: InstitutionType
    institution_country: str
    degree_program: str
    graduation_year: int = Field(..., ge=1950, le=2030)
    specializations: List[str]
    madhab_affiliation: Optional[str] = None
    teaching_experience_years: int = Field(default=0, ge=0)
    bio: Optional[str] = None


class ScholarProfileResponse(BaseModel):
    id: int
    full_name: str
    display_name: Optional[str]
    bio: Optional[str]
    highest_degree: Optional[str]
    institution: Optional[str]
    specializations: List[str]
    madhab_affiliation: Optional[str]
    rank: str
    contributions_count: int
    average_rating: int
    is_verified: bool
    
    class Config:
        from_attributes = True


class ContributionRequest(BaseModel):
    contribution_type: str
    title: str
    content: str
    content_arabic: Optional[str] = None
    hadith_id: Optional[int] = None
    ruling_id: Optional[int] = None


# ============== API Endpoints ==============

@router.post("/apply")
async def submit_application(
    application: ScholarApplicationRequest,
    db: Session = Depends(get_db)
):
    """
    Submit an application to become a verified scholar on the platform.
    
    **Requirements:**
    - Islamic education from recognized institution
    - Minimum degree in Islamic Studies or equivalent
    - References from established scholars
    """
    # Check if email already exists
    existing = db.query(ScholarApplication).filter(
        ScholarApplication.email == application.email
    ).first()
    
    if existing:
        raise HTTPException(
            status_code=400, 
            detail="An application with this email already exists"
        )
    
    # Create application
    new_application = ScholarApplication(
        full_name=application.full_name,
        email=application.email,
        phone=application.phone,
        institution_name=application.institution_name,
        institution_type=application.institution_type,
        institution_country=application.institution_country,
        degree_program=application.degree_program,
        graduation_year=application.graduation_year,
        specializations=application.specializations,
        madhab_affiliation=application.madhab_affiliation,
        teaching_experience_years=application.teaching_experience_years,
        status=VerificationStatus.PENDING
    )
    
    db.add(new_application)
    db.commit()
    db.refresh(new_application)
    
    return {
        "message": "Application submitted successfully",
        "application_id": new_application.id,
        "status": new_application.status.value,
        "next_steps": "Your application will be reviewed within 7-14 days. You will receive an email notification."
    }


@router.get("/verified", response_model=List[ScholarProfileResponse])
async def list_verified_scholars(
    specialization: Optional[str] = None,
    madhab: Optional[str] = None,
    rank: Optional[ScholarRank] = None,
    min_rating: Optional[int] = Query(None, ge=0, le=100),
    limit: int = Query(20, ge=1, le=100),
    offset: int = Query(0, ge=0),
    db: Session = Depends(get_db)
):
    """List all verified scholars on the platform."""
    query = db.query(VerifiedScholar).filter(
        VerifiedScholar.is_verified == True,
        VerifiedScholar.is_public == True
    )
    
    if specialization:
        query = query.filter(
            VerifiedScholar.specializations.contains([specialization])
        )
    
    if madhab:
        query = query.filter(VerifiedScholar.madhab_affiliation == madhab)
    
    if rank:
        query = query.filter(VerifiedScholar.rank == rank)
    
    if min_rating:
        query = query.filter(VerifiedScholar.average_rating >= min_rating)
    
    total = query.count()
    scholars = query.offset(offset).limit(limit).all()
    
    return {
        "total": total,
        "scholars": scholars
    }


@router.get("/verified/{scholar_id}")
async def get_scholar_profile(
    scholar_id: int,
    db: Session = Depends(get_db)
):
    """Get detailed profile of a verified scholar."""
    scholar = db.query(VerifiedScholar).filter(
        VerifiedScholar.id == scholar_id,
        VerifiedScholar.is_verified == True
    ).first()
    
    if not scholar:
        raise HTTPException(status_code=404, detail="Scholar not found")
    
    # Get recent contributions
    contributions = db.query(ScholarContribution).filter(
        ScholarContribution.scholar_id == scholar_id,
        ScholarContribution.status == "published"
    ).order_by(ScholarContribution.created_at.desc()).limit(10).all()
    
    return {
        "scholar": scholar,
        "recent_contributions": contributions
    }


@router.get("/specializations")
async def list_specializations(db: Session = Depends(get_db)):
    """List all available specializations."""
    specializations = [
        "Fiqh (Jurisprudence)",
        "Usul al-Fiqh (Principles of Jurisprudence)",
        "Hadith Studies",
        "Hadith Authentication",
        "Tafsir (Quranic Exegesis)",
        "Aqeedah (Theology)",
        "Seerah (Prophetic Biography)",
        "Islamic History",
        "Arabic Language",
        "Islamic Finance",
        "Family Law",
        "Inheritance Law",
        "Criminal Law",
        "Comparative Fiqh",
        "Contemporary Fiqh Issues"
    ]
    
    return {"specializations": specializations}


@router.get("/ranks")
async def get_scholar_ranks():
    """Get explanation of scholar ranks."""
    return {
        "ranks": {
            "student": {
                "name": "Student",
                "description": "Currently pursuing Islamic studies",
                "requirements": "Enrollment in recognized Islamic institution"
            },
            "junior": {
                "name": "Junior Scholar",
                "description": "Recent graduate with 0-5 years experience",
                "requirements": "Degree in Islamic Studies + 0-5 years teaching/research"
            },
            "mid_level": {
                "name": "Mid-Level Scholar",
                "description": "Established scholar with 5-15 years experience",
                "requirements": "5-15 years of teaching, publications, and community service"
            },
            "senior": {
                "name": "Senior Scholar",
                "description": "Recognized authority with 15+ years experience",
                "requirements": "15+ years experience, multiple publications, recognized expertise"
            },
            "expert": {
                "name": "Expert Scholar",
                "description": "Major authority in their field",
                "requirements": "Internationally recognized, major contributions to Islamic scholarship"
            }
        }
    }


@router.get("/application-status/{application_id}")
async def check_application_status(
    application_id: int,
    email: str,
    db: Session = Depends(get_db)
):
    """Check the status of a scholar application."""
    application = db.query(ScholarApplication).filter(
        ScholarApplication.id == application_id,
        ScholarApplication.email == email
    ).first()
    
    if not application:
        raise HTTPException(status_code=404, detail="Application not found")
    
    return {
        "application_id": application.id,
        "status": application.status.value,
        "submitted_at": application.submitted_at,
        "reviewed_at": application.reviewed_at,
        "review_notes": application.review_notes if application.status != VerificationStatus.PENDING else None,
        "rejection_reason": application.rejection_reason if application.status == VerificationStatus.REJECTED else None
    }


# Admin endpoints (would require admin authentication)
@router.get("/admin/applications")
async def list_pending_applications(
    status: Optional[VerificationStatus] = Query(VerificationStatus.PENDING),
    db: Session = Depends(get_db)
):
    """List scholar applications (admin only)."""
    applications = db.query(ScholarApplication).filter(
        ScholarApplication.status == status
    ).order_by(ScholarApplication.submitted_at).all()
    
    return {
        "total": len(applications),
        "applications": applications
    }


@router.post("/admin/applications/{application_id}/review")
async def review_application(
    application_id: int,
    decision: str,  # approve, reject
    notes: Optional[str] = None,
    db: Session = Depends(get_db)
):
    """Review a scholar application (admin only)."""
    application = db.query(ScholarApplication).filter(
        ScholarApplication.id == application_id
    ).first()
    
    if not application:
        raise HTTPException(status_code=404, detail="Application not found")
    
    if decision == "approve":
        application.status = VerificationStatus.APPROVED
        application.reviewed_at = datetime.utcnow()
        application.review_notes = notes
        
        # Create verified scholar profile
        scholar = VerifiedScholar(
            application_id=application.id,
            full_name=application.full_name,
            email=application.email,
            institution=application.institution_name,
            graduation_year=application.graduation_year,
            specializations=application.specializations,
            madhab_affiliation=application.madhab_affiliation,
            is_verified=True,
            verified_at=datetime.utcnow()
        )
        db.add(scholar)
        
    elif decision == "reject":
        application.status = VerificationStatus.REJECTED
        application.reviewed_at = datetime.utcnow()
        application.rejection_reason = notes
    
    db.commit()
    
    return {
        "message": f"Application {decision}ed successfully",
        "application_id": application_id,
        "status": application.status.value
    }


@router.post("/contributions")
async def submit_contribution(
    contribution: ContributionRequest,
    scholar_id: int,  # Would come from authenticated user
    db: Session = Depends(get_db)
):
    """Submit a contribution as a verified scholar."""
    # Verify scholar exists and is active
    scholar = db.query(VerifiedScholar).filter(
        VerifiedScholar.id == scholar_id,
        VerifiedScholar.is_verified == True,
        VerifiedScholar.is_active == True
    ).first()
    
    if not scholar:
        raise HTTPException(status_code=403, detail="Only verified scholars can submit contributions")
    
    new_contribution = ScholarContribution(
        scholar_id=scholar_id,
        contribution_type=contribution.contribution_type,
        title=contribution.title,
        content=contribution.content,
        content_arabic=contribution.content_arabic,
        hadith_id=contribution.hadith_id,
        ruling_id=contribution.ruling_id,
        status="published"
    )
    
    db.add(new_contribution)
    
    # Update scholar stats
    scholar.contributions_count += 1
    if contribution.contribution_type == "answer":
        scholar.answers_count += 1
    elif contribution.contribution_type == "article":
        scholar.articles_count += 1
    
    db.commit()
    db.refresh(new_contribution)
    
    return {
        "message": "Contribution submitted successfully",
        "contribution_id": new_contribution.id,
        "status": new_contribution.status
    }


@router.get("/contributions")
async def list_contributions(
    scholar_id: Optional[int] = None,
    contribution_type: Optional[str] = None,
    limit: int = Query(20, ge=1, le=100),
    db: Session = Depends(get_db)
):
    """List scholar contributions."""
    query = db.query(ScholarContribution).filter(
        ScholarContribution.status == "published"
    )
    
    if scholar_id:
        query = query.filter(ScholarContribution.scholar_id == scholar_id)
    
    if contribution_type:
        query = query.filter(ScholarContribution.contribution_type == contribution_type)
    
    contributions = query.order_by(
        ScholarContribution.created_at.desc()
    ).limit(limit).all()
    
    return {
        "total": len(contributions),
        "contributions": contributions
    }


@router.get("/stats")
async def get_scholar_statistics(db: Session = Depends(get_db)):
    """Get statistics about verified scholars."""
    total_scholars = db.query(VerifiedScholar).filter(
        VerifiedScholar.is_verified == True
    ).count()
    
    scholars_by_rank = db.query(
        VerifiedScholar.rank,
        func.count(VerifiedScholar.id).label('count')
    ).filter(
        VerifiedScholar.is_verified == True
    ).group_by(VerifiedScholar.rank).all()
    
    scholars_by_madhab = db.query(
        VerifiedScholar.madhab_affiliation,
        func.count(VerifiedScholar.id).label('count')
    ).filter(
        VerifiedScholar.is_verified == True
    ).group_by(VerifiedScholar.madhab_affiliation).all()
    
    total_contributions = db.query(ScholarContribution).filter(
        ScholarContribution.status == "published"
    ).count()
    
    return {
        "total_verified_scholars": total_scholars,
        "scholars_by_rank": {r.rank.value: r.count for r in scholars_by_rank},
        "scholars_by_madhab": {m.madhab_affiliation or "Unspecified": m.count for m in scholars_by_madhab},
        "total_contributions": total_contributions
    }
