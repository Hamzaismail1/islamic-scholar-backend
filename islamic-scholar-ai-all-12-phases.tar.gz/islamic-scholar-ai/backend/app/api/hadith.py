"""
Islamic Scholar AI - Hadith API Endpoints
"""
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func, or_, and_
from typing import Optional, List

from app.db.database import get_db
from app.db.models import Hadith, HadithChain, Narrator
from app.schemas.hadith import (
    HadithResponse, HadithDetailResponse, HadithAuthenticationResponse,
    HadithListResponse, HadithSearchResult
)
from app.core.config import settings

router = APIRouter()


@router.get("/", response_model=HadithListResponse)
async def list_hadiths(
    collection: Optional[str] = Query(None, description="Filter by collection (bukhari, muslim, etc.)"),
    grade: Optional[str] = Query(None, description="Filter by grade (sahih, hasan, dhaif)"),
    theme: Optional[str] = Query(None, description="Filter by theme"),
    search: Optional[str] = Query(None, description="Search in Arabic or English text"),
    page: int = Query(1, ge=1),
    page_size: int = Query(settings.DEFAULT_PAGE_SIZE, ge=1, le=settings.MAX_PAGE_SIZE),
    db: AsyncSession = Depends(get_db)
):
    """
    List hadiths with optional filtering and pagination.
    """
    # Build query
    query = select(Hadith)
    
    # Apply filters
    if collection:
        query = query.where(Hadith.collection == collection)
    if grade:
        query = query.where(Hadith.overall_grade == grade)
    if theme:
        query = query.where(Hadith.theme.ilike(f"%{theme}%"))
    if search:
        search_filter = or_(
            Hadith.arabic_text.ilike(f"%{search}%"),
            Hadith.english_text.ilike(f"%{search}%"),
            Hadith.keywords.any(search)
        )
        query = query.where(search_filter)
    
    # Get total count
    count_query = select(func.count()).select_from(query.subquery())
    total = await db.scalar(count_query)
    
    # Apply pagination
    offset = (page - 1) * page_size
    query = query.offset(offset).limit(page_size)
    
    # Execute query
    result = await db.execute(query)
    hadiths = result.scalars().all()
    
    return HadithListResponse(
        items=[HadithResponse.model_validate(h) for h in hadiths],
        total=total,
        page=page,
        page_size=page_size,
        pages=(total + page_size - 1) // page_size
    )


@router.get("/search", response_model=List[HadithSearchResult])
async def search_hadiths(
    q: str = Query(..., min_length=2, description="Search query"),
    collection: Optional[str] = Query(None),
    grade: Optional[str] = Query(None),
    limit: int = Query(20, ge=1, le=100),
    db: AsyncSession = Depends(get_db)
):
    """
    Search hadiths by keyword in Arabic or English text.
    """
    # Build search query
    query = select(Hadith).where(
        or_(
            Hadith.arabic_text.ilike(f"%{q}%"),
            Hadith.english_text.ilike(f"%{q}%"),
            Hadith.keywords.any(q)
        )
    )
    
    # Apply filters
    if collection:
        query = query.where(Hadith.collection == collection)
    if grade:
        query = query.where(Hadith.overall_grade == grade)
    
    # Limit results
    query = query.limit(limit)
    
    # Execute
    result = await db.execute(query)
    hadiths = result.scalars().all()
    
    # Build response with relevance scores
    results = []
    for hadith in hadiths:
        # Simple relevance scoring
        score = 0.0
        matched_keywords = []
        
        if hadith.arabic_text and q.lower() in hadith.arabic_text.lower():
            score += 0.5
        if hadith.english_text and q.lower() in hadith.english_text.lower():
            score += 0.5
        if hadith.keywords and q.lower() in [k.lower() for k in hadith.keywords]:
            score += 1.0
            matched_keywords.append(q)
        
        results.append(HadithSearchResult(
            hadith=HadithResponse.model_validate(hadith),
            relevance_score=min(score, 1.0),
            matched_keywords=matched_keywords
        ))
    
    # Sort by relevance
    results.sort(key=lambda x: x.relevance_score, reverse=True)
    
    return results


@router.get("/{hadith_id}", response_model=HadithDetailResponse)
async def get_hadith(
    hadith_id: int,
    db: AsyncSession = Depends(get_db)
):
    """
    Get a single hadith by ID with all chains.
    """
    # Get hadith with chains
    result = await db.execute(
        select(Hadith).where(Hadith.id == hadith_id)
    )
    hadith = result.scalar_one_or_none()
    
    if not hadith:
        raise HTTPException(status_code=404, detail="Hadith not found")
    
    return HadithDetailResponse.model_validate(hadith)


@router.get("/{hadith_id}/authentication", response_model=HadithAuthenticationResponse)
async def get_hadith_authentication(
    hadith_id: int,
    db: AsyncSession = Depends(get_db)
):
    """
    Get authentication details for a hadith including:
    - Overall grade
    - All chains with narrator details
    - Authentication explanation
    """
    # Get hadith with chains
    result = await db.execute(
        select(Hadith).where(Hadith.id == hadith_id)
    )
    hadith = result.scalar_one_or_none()
    
    if not hadith:
        raise HTTPException(status_code=404, detail="Hadith not found")
    
    # Get narrator details for chains
    chain_responses = []
    for chain in hadith.chains:
        # Get narrator names for the chain
        narrator_ids = chain.chain_sequence
        narrator_result = await db.execute(
            select(Narrator).where(Narrator.id.in_(narrator_ids))
        )
        narrators = {n.id: n for n in narrator_result.scalars().all()}
        
        chain_responses.append(chain)
    
    # Generate authentication explanation
    explanation = generate_authentication_explanation(hadith, hadith.chains)
    
    return HadithAuthenticationResponse(
        hadith_id=hadith.id,
        overall_grade=hadith.overall_grade,
        chains=[
            {
                "id": c.id,
                "chain_sequence": c.chain_sequence,
                "chain_grade": c.chain_grade,
                "chain_grade_reason": c.chain_grade_reason,
                "has_weak_narrator": c.has_weak_narrator,
                "weak_narrator_name": c.weak_narrator_name,
                "weakness_type": c.weakness_type,
                "has_missing_link": c.has_missing_link,
                "bukhari_included": c.bukhari_included,
                "muslim_included": c.muslim_included
            }
            for c in hadith.chains
        ],
        authentication_explanation=explanation,
        scholarly_opinions={
            "albani": hadith.albani_grade
        }
    )


def generate_authentication_explanation(hadith: Hadith, chains: List[HadithChain]) -> str:
    """Generate human-readable authentication explanation"""
    if hadith.overall_grade == "sahih":
        if len(chains) == 1:
            return f"This hadith is authentic (Sahih). It has one connected chain with reliable narrators."
        else:
            return f"This hadith is authentic (Sahih). It has {len(chains)} connected chains with reliable narrators."
    elif hadith.overall_grade == "hasan":
        return "This hadith is good (Hasan). While not reaching the highest standard, the narrators are generally reliable."
    elif hadith.overall_grade == "dhaif":
        weak_chains = [c for c in chains if c.has_weak_narrator]
        if weak_chains:
            return f"This hadith is weak (Dhaif) due to weak narrators in the chain: {weak_chains[0].weak_narrator_name}"
        return "This hadith is weak (Dhaif) due to issues in the chain of transmission."
    else:
        return "Authentication information not available."


@router.get("/collection/{collection}/book/{book_number}")
async def get_hadiths_by_book(
    collection: str,
    book_number: int,
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    db: AsyncSession = Depends(get_db)
):
    """
    Get all hadiths from a specific book within a collection.
    """
    query = select(Hadith).where(
        and_(
            Hadith.collection == collection,
            Hadith.book_number == book_number
        )
    ).order_by(Hadith.hadith_number)
    
    # Get total count
    count_query = select(func.count()).select_from(query.subquery())
    total = await db.scalar(count_query)
    
    # Apply pagination
    offset = (page - 1) * page_size
    query = query.offset(offset).limit(page_size)
    
    result = await db.execute(query)
    hadiths = result.scalars().all()
    
    return HadithListResponse(
        items=[HadithResponse.model_validate(h) for h in hadiths],
        total=total,
        page=page,
        page_size=page_size,
        pages=(total + page_size - 1) // page_size
    )
