"""
ISLAMIC SCHOLAR AI - ANALYTICS & GROWTH
Phase 11: Analytics & Growth
"""

from sqlalchemy import Column, Integer, String, Float, DateTime, JSON, BigInteger
from sqlalchemy.sql import func

from app.db.database import Base


class DailyMetrics(Base):
    """Daily platform metrics"""
    __tablename__ = "daily_metrics"
    
    id = Column(Integer, primary_key=True, index=True)
    date = Column(DateTime, nullable=False, unique=True)
    
    # User Metrics
    new_users = Column(Integer, default=0)
    active_users = Column(Integer, default=0)
    total_users = Column(Integer, default=0)
    
    # Search Metrics
    total_searches = Column(Integer, default=0)
    avg_search_time_ms = Column(Float, default=0)
    
    # AI Metrics
    ai_queries = Column(Integer, default=0)
    avg_response_time_ms = Column(Float, default=0)
    
    # Content Metrics
    hadiths_viewed = Column(Integer, default=0)
    comparisons_made = Column(Integer, default=0)
    
    # Subscription Metrics
    new_subscriptions = Column(Integer, default=0)
    cancelled_subscriptions = Column(Integer, default=0)
    revenue = Column(Float, default=0)


class SearchAnalytics(Base):
    """Track search queries for insights"""
    __tablename__ = "search_analytics"
    
    id = Column(Integer, primary_key=True, index=True)
    
    query = Column(String(500))
    query_arabic = Column(String(500))
    
    # Results
    results_count = Column(Integer)
    clicked_result_id = Column(Integer)
    
    # User Info
    user_id = Column(Integer)
    is_authenticated = Column(Boolean)
    
    # Performance
    search_time_ms = Column(Integer)
    
    # Timestamp
    created_at = Column(DateTime, server_default=func.now())


class UserActivity(Base):
    """Track detailed user activity"""
    __tablename__ = "user_activity"
    
    id = Column(Integer, primary_key=True, index=True)
    
    user_id = Column(Integer)
    session_id = Column(String(100))
    
    activity_type = Column(String(50))  # search, view, ask, compare
    activity_details = Column(JSON)
    
    # Device/Location
    ip_address = Column(String(50))
    user_agent = Column(String(500))
    country = Column(String(100))
    
    created_at = Column(DateTime, server_default=func.now())
