"""
ISLAMIC SCHOLAR AI - SCHOLAR VERIFICATION SYSTEM
Models for Scholar Credential Verification
Phase 7: Scholar Verification System
"""

from sqlalchemy import Column, Integer, String, Text, Boolean, DateTime, ForeignKey, Enum, JSON, ARRAY
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from enum import Enum as PyEnum

from app.db.database import Base


class VerificationStatus(str, PyEnum):
    PENDING = "pending"
    UNDER_REVIEW = "under_review"
    APPROVED = "approved"
    REJECTED = "rejected"
    SUSPENDED = "suspended"


class ScholarRank(str, PyEnum):
    STUDENT = "student"  # Currently studying
    JUNIOR = "junior"  # Recent graduate, 0-5 years
    MID_LEVEL = "mid_level"  # 5-15 years experience
    SENIOR = "senior"  # 15+ years, recognized scholar
    EXPERT = "expert"  # Major authority in field


class InstitutionType(str, PyEnum):
    UNIVERSITY = "university"
    SEMINARY = "seminary"
    ISLAMIC_SCHOOL = "islamic_school"
    ONLINE_PLATFORM = "online_platform"
    OTHER = "other"


class ScholarApplication(Base):
    """Applications from scholars seeking verification"""
    __tablename__ = "scholar_applications"
    
    id = Column(Integer, primary_key=True, index=True)
    
    # Personal Information
    full_name = Column(String(200), nullable=False)
    email = Column(String(200), nullable=False, unique=True)
    phone = Column(String(50))
    
    # Academic Background
    institution_name = Column(String(200))
    institution_type = Column(Enum(InstitutionType))
    institution_country = Column(String(100))
    degree_program = Column(String(200))
    graduation_year = Column(Integer)
    
    # Specializations
    specializations = Column(ARRAY(String), default=[])
    madhab_affiliation = Column(String(50))
    
    # Credentials
    credentials = Column(JSON, default=[])
    # Each credential: {type, institution, year, document_url, verified}
    
    # Teaching Experience
    teaching_experience_years = Column(Integer, default=0)
    previous_institutions = Column(ARRAY(String), default=[])
    
    # Publications
    publications = Column(JSON, default=[])
    # Each publication: {title, type, year, url}
    
    # References
    references = Column(JSON, default=[])
    # Each reference: {name, institution, email, phone, relationship}
    
    # Application Status
    status = Column(Enum(VerificationStatus), default=VerificationStatus.PENDING)
    submitted_at = Column(DateTime, server_default=func.now())
    reviewed_at = Column(DateTime)
    reviewed_by = Column(Integer, ForeignKey("verified_scholars.id"))
    
    # Review Notes
    review_notes = Column(Text)
    rejection_reason = Column(Text)
    
    # Documents
    cv_url = Column(String(500))
    id_document_url = Column(String(500))
    degree_certificate_url = Column(String(500))
    additional_documents = Column(ARRAY(String), default=[])
    
    # Verification
    identity_verified = Column(Boolean, default=False)
    credentials_verified = Column(Boolean, default=False)
    references_verified = Column(Boolean, default=False)
    
    created_at = Column(DateTime, server_default=func.now())
    updated_at = Column(DateTime, onupdate=func.now())


class VerifiedScholar(Base):
    """Verified scholars who can contribute to the platform"""
    __tablename__ = "verified_scholars"
    
    id = Column(Integer, primary_key=True, index=True)
    
    # Application reference
    application_id = Column(Integer, ForeignKey("scholar_applications.id"))
    
    # Profile Information
    full_name = Column(String(200), nullable=False)
    display_name = Column(String(200))
    email = Column(String(200), nullable=False, unique=True)
    
    # Public Profile
    bio = Column(Text)
    bio_arabic = Column(Text)
    profile_image_url = Column(String(500))
    
    # Academic Credentials
    highest_degree = Column(String(200))
    institution = Column(String(200))
    graduation_year = Column(Integer)
    
    # Specializations
    specializations = Column(ARRAY(String), default=[])
    specializations_arabic = Column(ARRAY(String), default=[])
    
    # Madhab
    madhab_affiliation = Column(String(50))
    
    # Rank
    rank = Column(Enum(ScholarRank), default=ScholarRank.JUNIOR)
    
    # Verification Status
    is_verified = Column(Boolean, default=False)
    verified_at = Column(DateTime)
    verified_by = Column(Integer, ForeignKey("verified_scholars.id"))
    
    # Platform Activity
    contributions_count = Column(Integer, default=0)
    answers_count = Column(Integer, default=0)
    articles_count = Column(Integer, default=0)
    reviews_count = Column(Integer, default=0)
    
    # Ratings
    average_rating = Column(Integer, default=0)  # 0-100
    total_reviews = Column(Integer, default=0)
    
    # Permissions
    can_answer_questions = Column(Boolean, default=True)
    can_verify_hadith = Column(Boolean, default=False)
    can_review_content = Column(Boolean, default=False)
    can_verify_scholars = Column(Boolean, default=False)
    
    # Social Links
    website = Column(String(500))
    twitter = Column(String(100))
    linkedin = Column(String(100))
    
    # Status
    is_active = Column(Boolean, default=True)
    is_public = Column(Boolean, default=True)
    
    created_at = Column(DateTime, server_default=func.now())
    updated_at = Column(DateTime, onupdate=func.now())
    
    # Relationships
    contributions = relationship("ScholarContribution", back_populates="scholar")
    reviews = relationship("ScholarReview", back_populates="scholar")


class ScholarContribution(Base):
    """Contributions made by verified scholars"""
    __tablename__ = "scholar_contributions"
    
    id = Column(Integer, primary_key=True, index=True)
    
    scholar_id = Column(Integer, ForeignKey("verified_scholars.id"), nullable=False)
    scholar = relationship("VerifiedScholar", back_populates="contributions")
    
    # Contribution Details
    contribution_type = Column(String(50))  # answer, article, review, verification
    title = Column(String(500))
    content = Column(Text)
    content_arabic = Column(Text)
    
    # Related Content
    hadith_id = Column(Integer, ForeignKey("hadiths.id"))
    ruling_id = Column(Integer, ForeignKey("madhab_rulings.id"))
    
    # Status
    status = Column(String(50), default="published")  # draft, published, archived
    
    # Engagement
    views_count = Column(Integer, default=0)
    likes_count = Column(Integer, default=0)
    
    created_at = Column(DateTime, server_default=func.now())
    updated_at = Column(DateTime, onupdate=func.now())


class ScholarReview(Base):
    """Reviews of scholar contributions by other scholars"""
    __tablename__ = "scholar_reviews"
    
    id = Column(Integer, primary_key=True, index=True)
    
    reviewer_id = Column(Integer, ForeignKey("verified_scholars.id"), nullable=False)
    scholar = relationship("VerifiedScholar", back_populates="reviews")
    
    # What is being reviewed
    contribution_id = Column(Integer, ForeignKey("scholar_contributions.id"))
    hadith_id = Column(Integer, ForeignKey("hadiths.id"))
    
    # Review Content
    rating = Column(Integer)  # 1-5
    review_text = Column(Text)
    
    # Technical Review
    accuracy_score = Column(Integer)  # 0-100
    authenticity_verified = Column(Boolean)
    sources_checked = Column(Boolean)
    
    created_at = Column(DateTime, server_default=func.now())


class CredentialVerification(Base):
    """Verification records for scholar credentials"""
    __tablename__ = "credential_verifications"
    
    id = Column(Integer, primary_key=True, index=True)
    
    application_id = Column(Integer, ForeignKey("scholar_applications.id"))
    
    # Credential Details
    credential_type = Column(String(100))  # degree, certificate, ijaza
    institution_name = Column(String(200))
    institution_country = Column(String(100))
    program_name = Column(String(200))
    year_completed = Column(Integer)
    
    # Verification Status
    verification_status = Column(Enum(VerificationStatus), default=VerificationStatus.PENDING)
    
    # Verification Method
    verification_method = Column(String(100))  # email, phone, document_check, database
    verified_by = Column(String(200))
    verification_date = Column(DateTime)
    
    # Notes
    notes = Column(Text)
    
    created_at = Column(DateTime, server_default=func.now())
    updated_at = Column(DateTime, onupdate=func.now())


class ReferenceCheck(Base):
    """Reference checks for scholar applications"""
    __tablename__ = "reference_checks"
    
    id = Column(Integer, primary_key=True, index=True)
    
    application_id = Column(Integer, ForeignKey("scholar_applications.id"))
    
    # Reference Information
    reference_name = Column(String(200))
    reference_institution = Column(String(200))
    reference_email = Column(String(200))
    reference_phone = Column(String(50))
    
    # Check Status
    contact_attempts = Column(Integer, default=0)
    last_contact_date = Column(DateTime)
    
    # Response
    responded = Column(Boolean, default=False)
    response_date = Column(DateTime)
    
    # Feedback
    knows_applicant = Column(Boolean)
    relationship_duration = Column(String(100))
    recommends_applicant = Column(Boolean)
    comments = Column(Text)
    
    # Verification
    identity_verified = Column(Boolean, default=False)
    
    created_at = Column(DateTime, server_default=func.now())
    updated_at = Column(DateTime, onupdate=func.now())
