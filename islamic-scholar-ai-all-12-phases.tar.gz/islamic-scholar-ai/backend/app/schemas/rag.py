"""
Islamic Scholar AI - RAG Schemas
"""
from pydantic import BaseModel
from typing import Optional, List, Dict, Any


class RAGQueryRequest(BaseModel):
    """RAG query request"""
    query: str
    user_madhab: Optional[str] = None
    authenticity_filter: Optional[str] = "sahih_only"  # sahih_only, sahih_hasan, all
    top_k: Optional[int] = 10


class RAGSource(BaseModel):
    """Source citation for RAG response"""
    type: str  # 'hadith', 'quran', 'narrator'
    id: int
    reference: str
    text: str
    grade: Optional[str]
    relevance_score: float


class RAGResponse(BaseModel):
    """RAG query response"""
    query: str
    answer: str
    confidence_score: float
    sources: List[RAGSource]
    requires_scholar_review: bool
    review_reason: Optional[str]


class EmbeddingRequest(BaseModel):
    """Request to create embeddings"""
    hadith_ids: Optional[List[int]] = None  # If None, embed all
    batch_size: Optional[int] = 100


class EmbeddingResponse(BaseModel):
    """Embedding creation response"""
    processed: int
    failed: int
    errors: List[str]


class SemanticSearchRequest(BaseModel):
    """Semantic search request"""
    query: str
    collection: Optional[str] = None
    grade_filter: Optional[List[str]] = None
    top_k: int = 10


class SemanticSearchResult(BaseModel):
    """Semantic search result"""
    hadith_id: int
    collection: str
    hadith_number: int
    arabic_text: str
    english_text: Optional[str]
    overall_grade: Optional[str]
    similarity_score: float
