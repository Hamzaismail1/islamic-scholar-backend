"""
Islamic Scholar AI - Hadith Schemas
"""
from pydantic import BaseModel
from typing import Optional, List
from datetime import datetime


class NarratorSummary(BaseModel):
    """Simplified narrator info for chain display"""
    id: int
    name_arabic: str
    name_english: Optional[str]
    consensus_grade: Optional[str]
    generation: Optional[str]
    
    class Config:
        from_attributes = True


class HadithChainResponse(BaseModel):
    """Hadith chain response"""
    id: int
    chain_sequence: List[int]
    chain_grade: Optional[str]
    chain_grade_reason: Optional[str]
    has_weak_narrator: bool
    weak_narrator_name: Optional[str]
    weakness_type: Optional[str]
    has_missing_link: bool
    bukhari_included: Optional[bool]
    muslim_included: Optional[bool]
    
    class Config:
        from_attributes = True


class HadithBase(BaseModel):
    """Base hadith schema"""
    collection: str
    book_number: Optional[int]
    book_name_en: Optional[str]
    chapter_number: Optional[int]
    chapter_name_en: Optional[str]
    hadith_number: int
    arabic_text: str
    english_text: Optional[str]
    overall_grade: Optional[str]
    theme: Optional[str]
    keywords: Optional[List[str]]


class HadithCreate(HadithBase):
    pass


class HadithResponse(HadithBase):
    """Full hadith response"""
    id: int
    has_multiple_chains: bool
    chain_count: int
    created_at: datetime
    
    class Config:
        from_attributes = True


class HadithDetailResponse(HadithResponse):
    """Hadith with chains"""
    chains: List[HadithChainResponse]


class HadithAuthenticationResponse(BaseModel):
    """Authentication details for a hadith"""
    hadith_id: int
    overall_grade: Optional[str]
    chains: List[HadithChainResponse]
    authentication_explanation: str
    scholarly_opinions: Optional[dict]


class HadithSearchResult(BaseModel):
    """Search result with relevance score"""
    hadith: HadithResponse
    relevance_score: float
    matched_keywords: List[str]


class HadithListResponse(BaseModel):
    """Paginated list response"""
    items: List[HadithResponse]
    total: int
    page: int
    page_size: int
    pages: int
