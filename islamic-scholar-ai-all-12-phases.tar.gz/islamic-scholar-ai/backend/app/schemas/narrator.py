"""
Islamic Scholar AI - Narrator Schemas
"""
from pydantic import BaseModel
from typing import Optional, List
from datetime import datetime


class NarratorBase(BaseModel):
    """Base narrator schema"""
    name_arabic: str
    name_english: Optional[str]
    kunyah: Optional[str]
    full_name_arabic: Optional[str]
    full_name_english: Optional[str]
    birth_year_hijri: Optional[int]
    death_year_hijri: Optional[int]
    generation: Optional[str]
    consensus_grade: Optional[str]
    biography_english: Optional[str]
    birthplace: Optional[str]
    madhab: Optional[str]


class NarratorCreate(NarratorBase):
    pass


class NarratorResponse(NarratorBase):
    """Full narrator response"""
    id: int
    total_hadiths_narrated: int
    hadiths_in_bukhari: int
    hadiths_in_muslim: int
    created_at: datetime
    
    class Config:
        from_attributes = True


class NarratorDetailResponse(NarratorResponse):
    """Detailed narrator with grades"""
    bukhari_grade: Optional[str]
    muslim_grade: Optional[str]
    ibn_hajar_grade: Optional[str]
    dhahabi_grade: Optional[str]
    age_at_death: Optional[int]
    residence: Optional[str]
    reference_books: Optional[List[str]]


class NarratorListResponse(BaseModel):
    """Paginated list response"""
    items: List[NarratorResponse]
    total: int
    page: int
    page_size: int
    pages: int


class NarratorFilter(BaseModel):
    """Filter options for narrators"""
    generation: Optional[str]
    grade: Optional[str]
    madhab: Optional[str]
    search: Optional[str]
