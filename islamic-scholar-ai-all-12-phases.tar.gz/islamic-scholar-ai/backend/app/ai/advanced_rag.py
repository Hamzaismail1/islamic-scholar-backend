"""
ISLAMIC SCHOLAR AI - ADVANCED RAG SYSTEM
Enhanced AI Features with Multi-Modal Search & Reasoning
Phase 6: Advanced AI Features
"""

import os
import json
import hashlib
from typing import List, Dict, Optional, Any, Tuple
from dataclasses import dataclass
from datetime import datetime
import asyncio

import openai
import numpy as np
from pinecone import Pinecone
from sqlalchemy.orm import Session
from sqlalchemy import func

from app.db.models import Hadith, Narrator, HadithChain, ChainNarrator
from app.madhab.models import MadhabRuling


@dataclass
class SearchResult:
    """Structured search result"""
    content: str
    content_arabic: Optional[str]
    source: str
    source_type: str  # hadith, fiqh, tafsir, etc.
    relevance_score: float
    metadata: Dict[str, Any]
    chain_authenticity: Optional[str] = None


@dataclass
class AIResponse:
    """Structured AI response"""
    answer: str
    answer_arabic: Optional[str]
    confidence: float
    sources: List[SearchResult]
    reasoning_chain: List[str]
    related_questions: List[str]
    scholarly_disclaimer: str
    processing_time_ms: int


class AdvancedRAGSystem:
    """
    Advanced Retrieval-Augmented Generation System for Islamic Knowledge
    
    Features:
    - Multi-modal search (semantic + keyword + metadata)
    - Chain-of-thought reasoning
    - Scholarly verification
    - Multi-language support
    - Confidence scoring
    """
    
    def __init__(self):
        self.openai_client = openai.AsyncOpenAI(api_key=os.getenv("OPENAI_API_KEY"))
        self.pinecone = Pinecone(api_key=os.getenv("PINECONE_API_KEY"))
        self.index = self.pinecone.Index("islamic-scholar-ai")
        
        # System prompt for Islamic Q&A
        self.system_prompt = """You are Islamic Scholar AI, an advanced assistant trained to provide accurate, well-sourced answers about Islamic knowledge based on the Quran, authentic Hadith, and classical scholarship.

CORE PRINCIPLES:
1. AUTHENTICITY FIRST: Only cite authentic (Sahih/Hasan) sources. Clearly indicate the grade of each hadith.
2. SCHOLARLY APPROACH: Present the views of the 4 major madhabs (Hanafi, Maliki, Shafi'i, Hanbali) when relevant.
3. TRANSPARENCY: Acknowledge when there is scholarly difference (ikhtilaf) and present the evidence for each view.
4. HUMILITY: Say "I don't know" or "There is no clear evidence" when appropriate. Never invent sources.
5. RESPECT: Maintain respectful tone toward all scholars and schools of thought.

RESPONSE STRUCTURE:
1. Direct Answer: Clear, concise answer to the question
2. Evidence: Primary evidence from Quran and authentic Sunnah
3. Scholarly Views: Opinions of major scholars/madhabs with their reasoning
4. Chain of Narration: When citing hadith, mention key narrators and authenticity
5. Conclusion: Summary and practical guidance

CONFIDENCE LEVELS:
- HIGH: Clear evidence from Quran/Mutawatir Sunnah or scholarly consensus (ijma)
- MEDIUM: Strong evidence from authentic Ahad hadith with majority view
- LOW: Weak evidence or significant scholarly difference

DISCLAIMER: Always include: "This is for educational purposes. For personal religious matters, consult qualified scholars."

ARABIC INTEGRATION: When relevant, provide Arabic terms with transliteration and translation."""

    async def search_multi_modal(
        self,
        query: str,
        query_arabic: Optional[str] = None,
        search_types: List[str] = ["semantic", "keyword", "metadata"],
        filters: Optional[Dict] = None,
        top_k: int = 10
    ) -> List[SearchResult]:
        """
        Perform multi-modal search across all knowledge bases
        
        Args:
            query: English query
            query_arabic: Arabic query (optional)
            search_types: Types of search to perform
            filters: Metadata filters (collection, grade, etc.)
            top_k: Number of results to return
        """
        all_results = []
        
        # 1. Semantic Search (Pinecone)
        if "semantic" in search_types:
            semantic_results = await self._semantic_search(query, filters, top_k)
            all_results.extend(semantic_results)
        
        # 2. Keyword Search (PostgreSQL Full-Text)
        if "keyword" in search_types:
            keyword_results = await self._keyword_search(query, filters, top_k)
            all_results.extend(keyword_results)
        
        # 3. Metadata Search
        if "metadata" in search_types:
            metadata_results = await self._metadata_search(query, filters, top_k)
            all_results.extend(metadata_results)
        
        # 4. Arabic Search (if provided)
        if query_arabic:
            arabic_results = await self._arabic_search(query_arabic, filters, top_k)
            all_results.extend(arabic_results)
        
        # Deduplicate and rank results
        unique_results = self._deduplicate_results(all_results)
        ranked_results = self._rank_results(unique_results, query)
        
        return ranked_results[:top_k]

    async def _semantic_search(
        self,
        query: str,
        filters: Optional[Dict],
        top_k: int
    ) -> List[SearchResult]:
        """Vector similarity search using Pinecone"""
        # Generate embedding
        embedding_response = await self.openai_client.embeddings.create(
            model="text-embedding-3-large",
            input=query
        )
        query_embedding = embedding_response.data[0].embedding
        
        # Search Pinecone
        filter_dict = {}
        if filters:
            if "collection" in filters:
                filter_dict["collection"] = filters["collection"]
            if "grade" in filters:
                filter_dict["authenticity_grade"] = filters["grade"]
        
        results = self.index.query(
            vector=query_embedding,
            top_k=top_k,
            filter=filter_dict if filter_dict else None,
            include_metadata=True
        )
        
        search_results = []
        for match in results.matches:
            metadata = match.metadata
            search_results.append(SearchResult(
                content=metadata.get("text_english", ""),
                content_arabic=metadata.get("text_arabic"),
                source=f"{metadata.get('collection', 'Unknown')} #{metadata.get('hadith_number', 'N/A')}",
                source_type="hadith",
                relevance_score=match.score,
                metadata=metadata,
                chain_authenticity=metadata.get("authenticity_grade")
            ))
        
        return search_results

    async def _keyword_search(
        self,
        query: str,
        filters: Optional[Dict],
        top_k: int,
        db: Session = None
    ) -> List[SearchResult]:
        """Full-text keyword search using PostgreSQL"""
        # This would be implemented with PostgreSQL full-text search
        # For now, return empty list
        return []

    async def _metadata_search(
        self,
        query: str,
        filters: Optional[Dict],
        top_k: int
    ) -> List[SearchResult]:
        """Search based on metadata (topic, narrator, etc.)"""
        # Extract entities from query
        entities = await self._extract_entities(query)
        
        results = []
        
        # Search by narrator
        if entities.get("narrators"):
            for narrator in entities["narrators"]:
                # Query Pinecone with narrator filter
                narrator_results = self.index.query(
                    vector=[0] * 3072,  # Dummy vector
                    top_k=5,
                    filter={"narrator": narrator},
                    include_metadata=True
                )
                for match in narrator_results.matches:
                    metadata = match.metadata
                    results.append(SearchResult(
                        content=metadata.get("text_english", ""),
                        content_arabic=metadata.get("text_arabic"),
                        source=f"{metadata.get('collection', 'Unknown')}",
                        source_type="hadith",
                        relevance_score=0.8,
                        metadata=metadata,
                        chain_authenticity=metadata.get("authenticity_grade")
                    ))
        
        return results

    async def _arabic_search(
        self,
        query_arabic: str,
        filters: Optional[Dict],
        top_k: int
    ) -> List[SearchResult]:
        """Search in Arabic text"""
        # Generate Arabic embedding
        embedding_response = await self.openai_client.embeddings.create(
            model="text-embedding-3-large",
            input=query_arabic
        )
        query_embedding = embedding_response.data[0].embedding
        
        # Search with Arabic emphasis
        results = self.index.query(
            vector=query_embedding,
            top_k=top_k,
            include_metadata=True
        )
        
        search_results = []
        for match in results.matches:
            metadata = match.metadata
            if metadata.get("text_arabic"):  # Prioritize results with Arabic
                search_results.append(SearchResult(
                    content=metadata.get("text_english", ""),
                    content_arabic=metadata.get("text_arabic"),
                    source=f"{metadata.get('collection', 'Unknown')}",
                    source_type="hadith",
                    relevance_score=match.score * 1.1,  # Boost Arabic matches
                    metadata=metadata,
                    chain_authenticity=metadata.get("authenticity_grade")
                ))
        
        return search_results

    async def _extract_entities(self, query: str) -> Dict[str, List[str]]:
        """Extract key entities from query using LLM"""
        prompt = f"""Extract key Islamic entities from this query. Return JSON with:
- narrators: list of narrator names mentioned
- topics: list of fiqh topics
- books: list of hadith books
- terms: list of Islamic technical terms

Query: {query}"""
        
        response = await self.openai_client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {"role": "system", "content": "You are an entity extraction specialist for Islamic texts."},
                {"role": "user", "content": prompt}
            ],
            response_format={"type": "json_object"}
        )
        
        return json.loads(response.choices[0].message.content)

    def _deduplicate_results(self, results: List[SearchResult]) -> List[SearchResult]:
        """Remove duplicate results based on content hash"""
        seen = set()
        unique = []
        
        for result in results:
            content_hash = hashlib.md5(result.content.encode()).hexdigest()
            if content_hash not in seen:
                seen.add(content_hash)
                unique.append(result)
        
        return unique

    def _rank_results(
        self,
        results: List[SearchResult],
        query: str
    ) -> List[SearchResult]:
        """Rank results by relevance, authenticity, and diversity"""
        scored_results = []
        
        for result in results:
            score = result.relevance_score
            
            # Boost by authenticity grade
            authenticity_boost = {
                "Sahih": 1.3,
                "Hasan": 1.1,
                "Dhaif": 0.7,
                "Mawdu": 0.3
            }
            grade = result.chain_authenticity or "Unknown"
            score *= authenticity_boost.get(grade, 1.0)
            
            # Boost by source diversity
            # (would track sources and boost underrepresented ones)
            
            scored_results.append((score, result))
        
        # Sort by score
        scored_results.sort(key=lambda x: x[0], reverse=True)
        
        return [r[1] for r in scored_results]

    async def generate_answer(
        self,
        query: str,
        query_arabic: Optional[str] = None,
        search_results: List[SearchResult] = None,
        include_reasoning: bool = True
    ) -> AIResponse:
        """
        Generate comprehensive answer with chain-of-thought reasoning
        
        Args:
            query: User question
            query_arabic: Arabic version of question
            search_results: Pre-fetched search results
            include_reasoning: Whether to include reasoning steps
        """
        start_time = datetime.now()
        
        # Search if results not provided
        if search_results is None:
            search_results = await self.search_multi_modal(query, query_arabic)
        
        # Build context from search results
        context = self._build_context(search_results)
        
        # Generate answer with chain-of-thought
        messages = [
            {"role": "system", "content": self.system_prompt},
            {"role": "user", "content": f"""Question: {query}

Context from authentic sources:
{context}

Please provide a comprehensive answer following the principles outlined in your instructions. Include:
1. Direct answer
2. Evidence from Quran and Sunnah (with authenticity grades)
3. Views of major scholars/madhabs (if applicable)
4. Chain of reasoning
5. Confidence level
6. Related questions for further study"""}
        ]
        
        response = await self.openai_client.chat.completions.create(
            model="gpt-4o",
            messages=messages,
            temperature=0.3,
            max_tokens=2000
        )
        
        answer_text = response.choices[0].message.content
        
        # Parse structured response
        parsed = self._parse_answer(answer_text)
        
        # Calculate processing time
        processing_time = int((datetime.now() - start_time).total_seconds() * 1000)
        
        return AIResponse(
            answer=parsed.get("answer", answer_text),
            answer_arabic=parsed.get("answer_arabic"),
            confidence=parsed.get("confidence", 0.8),
            sources=search_results[:5],
            reasoning_chain=parsed.get("reasoning", []),
            related_questions=parsed.get("related_questions", []),
            scholarly_disclaimer="This is for educational purposes. For personal religious matters, consult qualified scholars.",
            processing_time_ms=processing_time
        )

    def _build_context(self, results: List[SearchResult]) -> str:
        """Build context string from search results"""
        context_parts = []
        
        for i, result in enumerate(results[:10], 1):
            part = f"""[{i}] Source: {result.source}
Grade: {result.chain_authenticity or 'Unknown'}
Text: {result.content[:500]}..."""
            
            if result.content_arabic:
                part += f"\nArabic: {result.content_arabic[:200]}..."
            
            context_parts.append(part)
        
        return "\n\n".join(context_parts)

    def _parse_answer(self, answer_text: str) -> Dict[str, Any]:
        """Parse structured answer from LLM response"""
        parsed = {
            "answer": answer_text,
            "answer_arabic": None,
            "confidence": 0.8,
            "reasoning": [],
            "related_questions": []
        }
        
        # Extract confidence if mentioned
        if "Confidence:" in answer_text:
            try:
                conf_line = [l for l in answer_text.split('\n') if 'Confidence:' in l][0]
                if 'HIGH' in conf_line:
                    parsed["confidence"] = 0.95
                elif 'MEDIUM' in conf_line:
                    parsed["confidence"] = 0.75
                elif 'LOW' in conf_line:
                    parsed["confidence"] = 0.5
            except:
                pass
        
        # Extract related questions
        if "Related Questions:" in answer_text:
            try:
                rel_section = answer_text.split("Related Questions:")[1]
                questions = [q.strip() for q in rel_section.split('\n') if q.strip().startswith('-')]
                parsed["related_questions"] = questions[:5]
            except:
                pass
        
        return parsed

    async def verify_authenticity(
        self,
        hadith_text: str,
        claimed_source: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Verify the authenticity of a hadith
        
        Returns:
            Dict with verification results
        """
        # Search for the hadith
        results = await self.search_multi_modal(
            query=hadith_text,
            search_types=["semantic"],
            top_k=5
        )
        
        if not results:
            return {
                "found": False,
                "message": "Hadith not found in major collections",
                "recommendation": "This hadith may be weak, fabricated, or not found in the major collections."
            }
        
        # Check for exact or near-exact matches
        best_match = results[0]
        
        return {
            "found": True,
            "exact_match": best_match.relevance_score > 0.95,
            "authenticity_grade": best_match.chain_authenticity,
            "source": best_match.source,
            "narrator_chain": best_match.metadata.get("narrator_chain"),
            "full_text": best_match.content,
            "scholarly_grading": self._get_scholarly_grading(best_match.metadata)
        }

    def _get_scholarly_grading(self, metadata: Dict) -> List[Dict]:
        """Get scholarly gradings for a hadith"""
        # This would query the database for scholar opinions
        return [
            {
                "scholar": "Imam al-Bukhari",
                "grade": metadata.get("authenticity_grade", "Unknown"),
                "explanation": "Included in Sahih al-Bukhari"
            }
        ]

    async def compare_madhabs(
        self,
        topic: str,
        specific_question: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Compare rulings across the 4 madhabs on a specific topic
        
        Args:
            topic: Fiqh topic to compare
            specific_question: Specific question within the topic
        """
        # Search for madhab rulings
        query = f"{topic} {specific_question or ''} madhab ruling fiqh"
        
        results = await self.search_multi_modal(
            query=query,
            search_types=["semantic", "metadata"],
            top_k=20
        )
        
        # Group by madhab
        madhab_views = {
            "hanafi": [],
            "maliki": [],
            "shafii": [],
            "hanbali": []
        }
        
        for result in results:
            madhab = result.metadata.get("madhab")
            if madhab in madhab_views:
                madhab_views[madhab].append(result)
        
        # Generate comparison
        comparison_prompt = f"""Compare the views of the 4 madhabs on: {topic}
Specific question: {specific_question or 'General ruling'}

Hanafi sources:
{self._format_madhab_sources(madhab_views['hanafi'])}

Maliki sources:
{self._format_madhab_sources(madhab_views['maliki'])}

Shafi'i sources:
{self._format_madhab_sources(madhab_views['shafii'])}

Hanbali sources:
{self._format_madhab_sources(madhab_views['hanbali'])}

Provide:
1. Summary of each madhab's view
2. Evidence each uses
3. Points of agreement
4. Points of difference
5. Reasons for difference
6. Contemporary application"""
        
        response = await self.openai_client.chat.completions.create(
            model="gpt-4o",
            messages=[
                {"role": "system", "content": self.system_prompt},
                {"role": "user", "content": comparison_prompt}
            ]
        )
        
        return {
            "topic": topic,
            "question": specific_question,
            "comparison": response.choices[0].message.content,
            "sources_by_madhab": madhab_views
        }

    def _format_madhab_sources(self, results: List[SearchResult]) -> str:
        """Format sources for a specific madhab"""
        if not results:
            return "No sources found"
        
        return "\n".join([
            f"- {r.source}: {r.content[:200]}..."
            for r in results[:3]
        ])


# Singleton instance
advanced_rag = AdvancedRAGSystem()
