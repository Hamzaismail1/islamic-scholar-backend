#!/bin/bash
# Islamic Scholar AI - Quick Start Script

echo "🕌 Islamic Scholar AI - Quick Start"
echo "===================================="
echo ""

# Check if Docker is installed
if ! command -v docker &> /dev/null; then
    echo "❌ Docker is not installed. Please install Docker first."
    exit 1
fi

if ! command -v docker-compose &> /dev/null; then
    echo "❌ Docker Compose is not installed. Please install Docker Compose first."
    exit 1
fi

# Check if .env file exists
if [ ! -f "backend/.env" ]; then
    echo "⚠️  Environment file not found. Creating from example..."
    cp backend/.env.example backend/.env
    echo "✅ Created backend/.env"
    echo "⚠️  Please edit backend/.env and add your API keys before continuing."
    echo ""
    echo "Required API Keys:"
    echo "  - OPENAI_API_KEY (get from https://platform.openai.com)"
    echo "  - PINECONE_API_KEY (optional, get from https://pinecone.io)"
    echo ""
    exit 1
fi

echo "🚀 Starting Islamic Scholar AI..."
echo ""

# Start services
cd docker
docker-compose up -d

echo ""
echo "✅ Services started successfully!"
echo ""
echo "📍 Access Points:"
echo "  - API: http://localhost:8000"
echo "  - API Docs: http://localhost:8000/docs"
echo "  - Health Check: http://localhost:8000/health"
echo ""
echo "🗄️  Database:"
echo "  - PostgreSQL: localhost:5432"
echo "  - Redis: localhost:6379"
echo ""
echo "📱 Mobile App:"
echo "  - cd mobile && flutter run"
echo ""
echo "🛑 To stop: cd docker && docker-compose down"
echo ""
